#define MCAP_IMPLEMENTATION
#include <mcap/mcap.hpp>

#define CATCH_CONFIG_MAIN
#include <catch2/catch.hpp>

#include <array>
#include <cstdio>
#include <numeric>

#if defined _WIN32 || defined __CYGWIN__
#  include <io.h>
#  include <ioapiset.h>
#  include <winioctl.h>
#endif

std::string_view StringView(const std::byte* data, size_t size) {
  return std::string_view{reinterpret_cast<const char*>(data), size};
}

struct Buffer : mcap::IReadable, mcap::IWritable {
  std::vector<std::byte> buffer;

  virtual uint64_t size() const {
    return buffer.size();
  }

  // IWritable
  virtual void end() {}
  virtual void handleWrite(const std::byte* data, uint64_t size) {
    buffer.insert(buffer.end(), data, data + size);
  }

  // IReadable
  virtual uint64_t read(std::byte** output, uint64_t offset, uint64_t size) {
    if (offset + size > buffer.size()) {
      return 0;
    }
    *output = buffer.data() + offset;
    return size;
  }
};

void requireOk(const mcap::Status& status) {
  CAPTURE(status.code);
  CAPTURE(status.message);
  REQUIRE(status.ok());
}

static void WriteMsg(mcap::McapWriter& writer, mcap::ChannelId channelId, uint32_t sequence,
                     mcap::Timestamp logTime, mcap::Timestamp publishTime,
                     const std::vector<std::byte>& data) {
  mcap::Message msg;
  msg.channelId = channelId;
  msg.sequence = sequence;
  msg.logTime = logTime;
  msg.publishTime = publishTime;
  msg.data = data.data();
  msg.dataSize = data.size();
  requireOk(writer.write(msg));
}

TEST_CASE("internal::crc32", "[writer]") {
  const auto crc32 = [](const uint8_t* data, size_t len) {
    return mcap::internal::crc32Final(mcap::internal::crc32Update(
      mcap::internal::CRC32_INIT, reinterpret_cast<const std::byte*>(data), len));
  };

  std::array<uint8_t, 32> data;
  std::iota(data.begin(), data.end(), (uint8_t)(1));

  REQUIRE(crc32(data.data(), 0) == 0);
  REQUIRE(crc32(data.data(), 1) == 2768625435);

  for (size_t split = 0; split <= data.size(); split++) {
    CAPTURE(split);
    uint32_t crc = mcap::internal::CRC32_INIT;
    crc = mcap::internal::crc32Update(crc, reinterpret_cast<const std::byte*>(data.data()), split);
    crc = mcap::internal::crc32Update(crc, reinterpret_cast<const std::byte*>(data.data() + split),
                                      data.size() - split);
    REQUIRE(mcap::internal::crc32Final(crc) == 2280057893);
  }
}

#if defined(__linux__)
TEST_CASE("FileWriter reports filesystem write errors", "[writer]") {
  mcap::FileWriter writer;
  requireOk(writer.open("/dev/full"));

  // Use a payload larger than the stdio buffer so fwrite reaches the device immediately.
  const std::vector<std::byte> data(1024 * 1024);
  try {
    writer.write(data.data(), data.size());
    FAIL("Expected writing to /dev/full to fail");
  } catch (const std::system_error& error) {
    REQUIRE(error.code() == std::errc::no_space_on_device);
  }
}
#endif

TEST_CASE("internal::Parse*()", "[reader]") {
  SECTION("uint64_t") {
    const std::array<std::byte, 8> input = {std::byte(0xef), std::byte(0xcd), std::byte(0xab),
                                            std::byte(0x90), std::byte(0x78), std::byte(0x56),
                                            std::byte(0x34), std::byte(0x12)};
    REQUIRE(mcap::internal::ParseUint64(input.data()) == 0x1234567890abcdefull);
  }
}

TEST_CASE("McapReader::ParseChunk()", "[reader]") {
  // Builds the body of a Chunk record (the bytes after opcode + record length).
  const auto makeUncompressedChunk = [](uint64_t uncompressedSize,
                                        const std::vector<std::byte>& records) {
    std::vector<std::byte> data;
    const auto putU32 = [&](uint32_t v) {
      for (int i = 0; i < 4; ++i) {
        data.push_back(std::byte((v >> (8 * i)) & 0xff));
      }
    };
    const auto putU64 = [&](uint64_t v) {
      for (int i = 0; i < 8; ++i) {
        data.push_back(std::byte((v >> (8 * i)) & 0xff));
      }
    };
    putU64(0);                         // messageStartTime
    putU64(0);                         // messageEndTime
    putU64(uncompressedSize);          // uncompressedSize
    putU32(0);                         // uncompressedCrc
    putU32(0);                         // compression string length (empty == uncompressed)
    putU64(uint64_t(records.size()));  // compressedSize
    data.insert(data.end(), records.begin(), records.end());
    return data;
  };
  const std::vector<std::byte> records = {std::byte(1), std::byte(2), std::byte(3)};

  SECTION("rejects an uncompressed chunk whose declared sizes disagree") {
    auto data = makeUncompressedChunk(999, records);
    mcap::Record record{mcap::OpCode::Chunk, data.size(), data.data()};
    mcap::Chunk chunk;
    const auto status = mcap::McapReader::ParseChunk(record, &chunk);
    REQUIRE(status.code == mcap::StatusCode::DecompressionSizeMismatch);
  }

  SECTION("accepts an uncompressed chunk whose declared sizes agree") {
    auto data = makeUncompressedChunk(records.size(), records);
    mcap::Record record{mcap::OpCode::Chunk, data.size(), data.data()};
    mcap::Chunk chunk;
    const auto status = mcap::McapReader::ParseChunk(record, &chunk);
    REQUIRE(status.ok());
    REQUIRE(chunk.uncompressedSize == records.size());
    REQUIRE(chunk.compressedSize == records.size());
  }
}

TEST_CASE("McapWriter::write()", "[writer]") {
  SECTION("uint8_t") {
    mcap::BufferWriter output;
    mcap::McapWriter::write(output, mcap::OpCode::DataEnd);
    REQUIRE(output.size() == 1);
    REQUIRE(uint8_t(output.data()[0]) == uint8_t(mcap::OpCode::DataEnd));
  }

  SECTION("uint16_t") {
    mcap::BufferWriter output;
    mcap::McapWriter::write(output, uint16_t(0x1234));
    REQUIRE(output.size() == 2);
    REQUIRE(uint8_t(output.data()[0]) == 0x34);
    REQUIRE(uint8_t(output.data()[1]) == 0x12);
  }

  SECTION("uint32_t") {
    mcap::BufferWriter output;
    mcap::McapWriter::write(output, uint32_t(0x12345678));
    REQUIRE(output.size() == 4);
    REQUIRE(uint8_t(output.data()[0]) == 0x78);
    REQUIRE(uint8_t(output.data()[1]) == 0x56);
    REQUIRE(uint8_t(output.data()[2]) == 0x34);
    REQUIRE(uint8_t(output.data()[3]) == 0x12);
  }

  SECTION("uint64_t") {
    mcap::BufferWriter output;
    mcap::McapWriter::write(output, uint64_t(0x1234567890abcdef));
    REQUIRE(output.size() == 8);
    REQUIRE(uint8_t(output.data()[0]) == 0xef);
    REQUIRE(uint8_t(output.data()[1]) == 0xcd);
    REQUIRE(uint8_t(output.data()[2]) == 0xab);
    REQUIRE(uint8_t(output.data()[3]) == 0x90);
    REQUIRE(uint8_t(output.data()[4]) == 0x78);
    REQUIRE(uint8_t(output.data()[5]) == 0x56);
    REQUIRE(uint8_t(output.data()[6]) == 0x34);
    REQUIRE(uint8_t(output.data()[7]) == 0x12);
  }

  SECTION("byte*") {
    std::array<std::byte, 5> input = {std::byte(0x12), std::byte(0x34), std::byte(0x56),
                                      std::byte(0x78), std::byte(0x9a)};
    mcap::BufferWriter output;
    mcap::McapWriter::write(output, input.data(), input.size());
    REQUIRE(output.size() == 5);
    REQUIRE(uint8_t(output.data()[0]) == 0x12);
    REQUIRE(uint8_t(output.data()[1]) == 0x34);
    REQUIRE(uint8_t(output.data()[2]) == 0x56);
    REQUIRE(uint8_t(output.data()[3]) == 0x78);
    REQUIRE(uint8_t(output.data()[4]) == 0x9a);
  }

  SECTION("string_view") {
    std::string_view input = "Hello, world!";
    mcap::BufferWriter output;
    mcap::McapWriter::write(output, input);
    REQUIRE(output.size() == 17);
    REQUIRE(uint8_t(output.data()[0]) == 0x0d);
    REQUIRE(uint8_t(output.data()[1]) == 0x00);
    REQUIRE(uint8_t(output.data()[2]) == 0x00);
    REQUIRE(uint8_t(output.data()[3]) == 0x00);

    const std::string_view outputString =
      std::string_view{reinterpret_cast<const char*>(output.data() + 4), 13};
    REQUIRE(outputString.size() == input.size());
    REQUIRE(outputString == input);
  }

  SECTION("ByteArray") {
    mcap::ByteArray input = {std::byte(0x12), std::byte(0x34), std::byte(0x56), std::byte(0x78),
                             std::byte(0x9a)};
    mcap::BufferWriter output;
    mcap::McapWriter::write(output, input);
    REQUIRE(output.size() == 9);
    REQUIRE(uint8_t(output.data()[0]) == 0x05);
    REQUIRE(uint8_t(output.data()[1]) == 0x00);
    REQUIRE(uint8_t(output.data()[2]) == 0x00);
    REQUIRE(uint8_t(output.data()[3]) == 0x00);
    REQUIRE(uint8_t(output.data()[4]) == 0x12);
    REQUIRE(uint8_t(output.data()[5]) == 0x34);
    REQUIRE(uint8_t(output.data()[6]) == 0x56);
    REQUIRE(uint8_t(output.data()[7]) == 0x78);
    REQUIRE(uint8_t(output.data()[8]) == 0x9a);
  }

  SECTION("KeyValueMap") {
    mcap::KeyValueMap input = {{"key", "value"}, {"key2", "value2"}};
    mcap::BufferWriter output;
    mcap::McapWriter::write(output, input);
    REQUIRE(output.size() == 4 + 4 + 3 + 4 + 5 + 4 + 4 + 4 + 6);
    // Total byte length of the map
    REQUIRE(uint8_t(output.data()[0]) == 34);
    REQUIRE(uint8_t(output.data()[1]) == 0x00);
    REQUIRE(uint8_t(output.data()[2]) == 0x00);
    REQUIRE(uint8_t(output.data()[3]) == 0x00);
    // Length of "key"
    REQUIRE(uint8_t(output.data()[4]) == 0x03);
    REQUIRE(uint8_t(output.data()[5]) == 0x00);
    REQUIRE(uint8_t(output.data()[6]) == 0x00);
    REQUIRE(uint8_t(output.data()[7]) == 0x00);
    // "key"
    REQUIRE(StringView(output.data() + 8, 3) == "key");
    // Length of "value"
    REQUIRE(uint8_t(output.data()[11]) == 0x05);
    REQUIRE(uint8_t(output.data()[12]) == 0x00);
    REQUIRE(uint8_t(output.data()[13]) == 0x00);
    REQUIRE(uint8_t(output.data()[14]) == 0x00);
    // "value"
    REQUIRE(StringView(output.data() + 15, 5) == "value");
    // Length of "key2"
    REQUIRE(uint8_t(output.data()[20]) == 0x04);
    REQUIRE(uint8_t(output.data()[21]) == 0x00);
    REQUIRE(uint8_t(output.data()[22]) == 0x00);
    REQUIRE(uint8_t(output.data()[23]) == 0x00);
    // "key2"
    REQUIRE(StringView(output.data() + 24, 4) == "key2");
    // Length of "value2"
    REQUIRE(uint8_t(output.data()[28]) == 0x06);
    REQUIRE(uint8_t(output.data()[29]) == 0x00);
    REQUIRE(uint8_t(output.data()[30]) == 0x00);
    REQUIRE(uint8_t(output.data()[31]) == 0x00);
    // "value2"
    REQUIRE(StringView(output.data() + 32, 6) == "value2");
  }
}

TEST_CASE("McapReader::readMessages()", "[reader]") {
  SECTION("Empty file") {
    Buffer buffer;

    mcap::McapWriter writer;
    writer.open(buffer, mcap::McapWriterOptions("test"));
    mcap::Schema schema("schema", "schemaEncoding", "ab");
    writer.addSchema(schema);
    mcap::Channel channel("topic", "messageEncoding", schema.id);
    writer.addChannel(channel);
    writer.close();

    mcap::McapReader reader;
    requireOk(reader.open(buffer));

    for (const auto& msg : reader.readMessages()) {
      FAIL("Shouldn't have gotten a message: topic " + msg.channel->topic + ", schema " +
           msg.schema->name);
    }

    reader.close();
  }

  SECTION("MovableIterators") {
    Buffer buffer;

    mcap::McapWriter writer;
    writer.open(buffer, mcap::McapWriterOptions("test"));
    mcap::Schema schema("schema", "schemaEncoding", "ab");
    writer.addSchema(schema);
    mcap::Channel channel("topic", "messageEncoding", schema.id);
    writer.addChannel(channel);
    std::vector<std::byte> data = {std::byte(1), std::byte(2), std::byte(3)};
    WriteMsg(writer, channel.id, 0, 2, 1, data);
    WriteMsg(writer, channel.id, 1, 4, 3, data);
    writer.close();

    mcap::McapReader reader;
    requireOk(reader.open(buffer));

    auto view = reader.readMessages();
    {
      auto it = view.begin();
      REQUIRE(it != view.end());
      auto* originalMsg = &it->message;
      REQUIRE(it->message.sequence == 0);
      REQUIRE(it->message.channelId == channel.id);
      REQUIRE(it->message.logTime == 2);
      REQUIRE(it->message.publishTime == 1);
      REQUIRE(it->message.dataSize == data.size());
      REQUIRE(std::vector(it->message.data, it->message.data + it->message.dataSize) == data);

      // ensure iterator still works after move
      mcap::LinearMessageView::Iterator other = std::move(it);
      REQUIRE(&other->message == originalMsg);

      REQUIRE(other->message.sequence == 0);
      REQUIRE(other->message.channelId == channel.id);
      REQUIRE(other->message.logTime == 2);
      REQUIRE(other->message.publishTime == 1);
      REQUIRE(other->message.dataSize == data.size());
      REQUIRE(std::vector(other->message.data, other->message.data + other->message.dataSize) ==
              data);
    }

    {
      auto it = view.begin();
      ++it;
      REQUIRE(it->message.sequence == 1);
      REQUIRE(it->message.channelId == channel.id);
      REQUIRE(it->message.logTime == 4);
      REQUIRE(it->message.publishTime == 3);
      REQUIRE(it->message.dataSize == data.size());
      REQUIRE(std::vector(it->message.data, it->message.data + it->message.dataSize) == data);
    }

    for (const auto& msg : view) {
      REQUIRE((msg.message.sequence == 0 || msg.message.sequence == 1));
      REQUIRE(msg.message.channelId == channel.id);
      REQUIRE((msg.message.logTime == 2 || msg.message.logTime == 4));
      REQUIRE((msg.message.publishTime == 1 || msg.message.publishTime == 3));
      REQUIRE(msg.message.dataSize == msg.message.dataSize);
      REQUIRE(std::vector(msg.message.data, msg.message.data + msg.message.dataSize) == data);
    }

    reader.close();
  }

  SECTION("IteratorComparison") {
    Buffer buffer;

    mcap::McapWriter writer;
    writer.open(buffer, mcap::McapWriterOptions("test"));
    mcap::Schema schema("schema", "schemaEncoding", "ab");
    writer.addSchema(schema);
    mcap::Channel channel("topic", "messageEncoding", schema.id);
    writer.addChannel(channel);
    std::vector<std::byte> data = {std::byte(1), std::byte(2), std::byte(3)};
    WriteMsg(writer, channel.id, 0, 2, 1, data);
    WriteMsg(writer, channel.id, 1, 4, 3, data);
    writer.close();

    mcap::McapReader reader;
    requireOk(reader.open(buffer));

    auto view = reader.readMessages();
    auto it = view.begin();
    REQUIRE(it != view.end());
    REQUIRE(it == view.begin());
    REQUIRE(it == it);
    ++it;
    REQUIRE(it != view.end());
    REQUIRE(it != view.begin());
    REQUIRE(it == it);
    ++it;
    REQUIRE(it == view.end());
    REQUIRE(it != view.begin());
    REQUIRE(it == it);

    reader.close();
  }
  SECTION("IteratorComparisonEmpty") {
    Buffer buffer;

    mcap::McapWriter writer;
    writer.open(buffer, mcap::McapWriterOptions("test"));
    writer.close();

    mcap::McapReader reader;
    requireOk(reader.open(buffer));

    auto view = reader.readMessages();
    auto it = view.begin();
    REQUIRE(it == view.begin());
    REQUIRE(it == view.end());
    reader.close();
  }
}

/**
 * @brief ensures that message index records are only written for the channels present in the
 * previous chunk. This test writes two chunks with one message each in separate channels, with
 * each message being large enough to meet the chunk size threshold and close its chunk.
 * If the writer is working correctly, there will be one message index record after each chunk,
 * one for each message.
 */
TEST_CASE("Message index records", "[writer]") {
  Buffer buffer;

  mcap::McapWriter writer;
  mcap::McapWriterOptions opts("test");
  opts.chunkSize = 200;
  opts.compression = mcap::Compression::None;

  writer.open(buffer, opts);

  mcap::Schema schema("schema", "schemaEncoding", "ab");
  writer.addSchema(schema);
  mcap::Channel channel1("topic", "messageEncoding", schema.id);
  writer.addChannel(channel1);
  mcap::Channel channel2("topic", "messageEncoding", schema.id);
  writer.addChannel(channel2);

  mcap::Message msg;
  // Each message meets the chunk size threshold, closing its chunk once written.
  WriteMsg(writer, channel1.id, 0, 100, 100, std::vector<std::byte>(400));
  WriteMsg(writer, channel2.id, 0, 200, 200, std::vector<std::byte>(400));

  writer.close();

  // read the records after the starting magic, stopping before the end magic.
  mcap::RecordReader reader(buffer, sizeof(mcap::Magic), buffer.size() - sizeof(mcap::Magic));

  std::vector<uint16_t> messageIndexChannelIds;
  uint32_t chunkCount = 0;

  for (std::optional<mcap::Record> rec = reader.next(); rec != std::nullopt; rec = reader.next()) {
    requireOk(reader.status());
    if (rec->opcode == mcap::OpCode::MessageIndex) {
      mcap::MessageIndex index;
      requireOk(mcap::McapReader::ParseMessageIndex(*rec, &index));
      REQUIRE(index.records.size() == 1);
      messageIndexChannelIds.push_back(index.channelId);
    }
    if (rec->opcode == mcap::OpCode::Chunk) {
      chunkCount++;
    }
  }
  requireOk(reader.status());

  REQUIRE(chunkCount == 2);
  REQUIRE(messageIndexChannelIds.size() == 2);
  REQUIRE(messageIndexChannelIds[0] == channel1.id);
  REQUIRE(messageIndexChannelIds[1] == channel2.id);
}

#ifndef MCAP_COMPRESSION_NO_LZ4
TEST_CASE("LZ4 compression", "[reader][writer]") {
  SECTION("Roundtrip") {
    Buffer buffer;

    mcap::McapWriter writer;
    mcap::McapWriterOptions opts("test");
    opts.compression = mcap::Compression::Lz4;
    opts.forceCompression = true;
    writer.open(buffer, opts);
    mcap::Schema schema("schema", "schemaEncoding", "ab");
    writer.addSchema(schema);
    mcap::Channel channel("topic", "messageEncoding", schema.id);
    writer.addChannel(channel);

    mcap::Message msg;
    std::vector<std::byte> data = {std::byte(1), std::byte(2), std::byte(3)};
    WriteMsg(writer, channel.id, 0, 2, 1, data);

    writer.close();

    mcap::McapReader reader;
    requireOk(reader.open(buffer));

    size_t messageCount = 0;
    const auto onProblem = [](const mcap::Status& status) {
      FAIL("Status " + std::to_string((int)status.code) + ": " + status.message);
    };
    for (const auto& msgView : reader.readMessages(onProblem)) {
      ++messageCount;
      REQUIRE(msgView.message.sequence == 0);
      REQUIRE(msgView.message.channelId == channel.id);
      REQUIRE(msgView.message.logTime == 2);
      REQUIRE(msgView.message.publishTime == 1);
      REQUIRE(msgView.message.dataSize == data.size());
      REQUIRE(std::vector(msgView.message.data, msgView.message.data + msgView.message.dataSize) ==
              data);
    }
    REQUIRE(messageCount == 1);

    reader.close();
  }
}
#endif

#ifndef MCAP_COMPRESSION_NO_LZ4
TEST_CASE("zstd compression", "[reader][writer]") {
  SECTION("Roundtrip") {
    Buffer buffer;

    mcap::McapWriter writer;
    mcap::McapWriterOptions opts("test");
    opts.compression = mcap::Compression::Zstd;
    opts.forceCompression = true;
    writer.open(buffer, opts);
    mcap::Schema schema("schema", "schemaEncoding", "ab");
    writer.addSchema(schema);
    mcap::Channel channel("topic", "messageEncoding", schema.id);
    writer.addChannel(channel);

    mcap::Message msg;
    std::vector<std::byte> data = {std::byte(1), std::byte(2), std::byte(3)};
    WriteMsg(writer, channel.id, 0, 2, 1, data);

    writer.close();

    mcap::McapReader reader;
    requireOk(reader.open(buffer));

    size_t messageCount = 0;
    const auto onProblem = [](const mcap::Status& status) {
      FAIL("Status " + std::to_string((int)status.code) + ": " + status.message);
    };
    for (const auto& msgView : reader.readMessages(onProblem)) {
      ++messageCount;
      REQUIRE(msgView.message.sequence == 0);
      REQUIRE(msgView.message.channelId == channel.id);
      REQUIRE(msgView.message.logTime == 2);
      REQUIRE(msgView.message.publishTime == 1);
      REQUIRE(msgView.message.dataSize == data.size());
      REQUIRE(std::vector(msgView.message.data, msgView.message.data + msgView.message.dataSize) ==
              data);
    }
    REQUIRE(messageCount == 1);

    reader.close();
  }
}
#endif

TEST_CASE("RecordOffset equality operators", "[reader]") {
  SECTION("non-equal records outside chunk") {
    mcap::RecordOffset a(10);
    mcap::RecordOffset b(20);

    REQUIRE(a != b);
    REQUIRE(b != a);

    REQUIRE(a < b);
    REQUIRE(!(b < a));

    REQUIRE(a <= b);
    REQUIRE(!(b <= a));

    REQUIRE(!(a > b));
    REQUIRE(b > a);

    REQUIRE(!(a >= b));
    REQUIRE(b >= a);
  }

  SECTION("equal records outside chunk") {
    mcap::RecordOffset a(10);
    mcap::RecordOffset b(10);

    REQUIRE(a == b);
    REQUIRE(b == a);

    REQUIRE(!(a < b));
    REQUIRE(!(b < a));

    REQUIRE(a <= b);
    REQUIRE(b <= a);

    REQUIRE(!(a > b));
    REQUIRE(!(b > a));

    REQUIRE(a >= b);
    REQUIRE(b >= a);
  }

  SECTION("non-equal records in same chunk") {
    mcap::RecordOffset a(10, 30);
    mcap::RecordOffset b(20, 30);

    REQUIRE(a != b);
    REQUIRE(b != a);

    REQUIRE(a < b);
    REQUIRE(!(b < a));

    REQUIRE(a <= b);
    REQUIRE(!(b <= a));

    REQUIRE(!(a > b));
    REQUIRE(b > a);

    REQUIRE(!(a >= b));
    REQUIRE(b >= a);
  }

  SECTION("equal records inside chunk") {
    mcap::RecordOffset a(10, 30);
    mcap::RecordOffset b(10, 30);

    REQUIRE(a == b);
    REQUIRE(b == a);

    REQUIRE(!(a < b));
    REQUIRE(!(b < a));

    REQUIRE(a <= b);
    REQUIRE(b <= a);

    REQUIRE(!(a > b));
    REQUIRE(!(b > a));

    REQUIRE(a >= b);
    REQUIRE(b >= a);
  }

  SECTION("non-equal records in same chunk") {
    mcap::RecordOffset a(10, 30);
    mcap::RecordOffset b(20, 30);

    REQUIRE(a != b);
    REQUIRE(b != a);

    REQUIRE(a < b);
    REQUIRE(!(b < a));

    REQUIRE(a <= b);
    REQUIRE(!(b <= a));

    REQUIRE(!(a > b));
    REQUIRE(b > a);

    REQUIRE(!(a >= b));
    REQUIRE(b >= a);
  }

  SECTION("equally-offset records in different chunks") {
    mcap::RecordOffset a(10, 30);
    mcap::RecordOffset b(10, 40);

    REQUIRE(a != b);
    REQUIRE(b != a);

    REQUIRE(a < b);
    REQUIRE(!(b < a));

    REQUIRE(a <= b);
    REQUIRE(!(b <= a));

    REQUIRE(!(a > b));
    REQUIRE(b > a);

    REQUIRE(!(a >= b));
    REQUIRE(b >= a);
  }

  SECTION("oppositely-offset records in different chunks") {
    mcap::RecordOffset a(20, 30);
    mcap::RecordOffset b(10, 40);

    REQUIRE(a != b);
    REQUIRE(b != a);

    REQUIRE(a < b);
    REQUIRE(!(b < a));

    REQUIRE(a <= b);
    REQUIRE(!(b <= a));

    REQUIRE(!(a > b));
    REQUIRE(b > a);

    REQUIRE(!(a >= b));
    REQUIRE(b >= a);
  }
}

TEST_CASE("parsing", "header") {
  SECTION("default library") {
    Buffer buffer;
    mcap::McapWriter writer;
    writer.open(buffer, mcap::McapWriterOptions("my-profile"));
    writer.close();

    mcap::McapReader reader;
    auto status = reader.open(buffer);
    requireOk(status);

    auto header = reader.header();
    REQUIRE(header != std::nullopt);

    REQUIRE(header->library == "mcap-cpp/" MCAP_LIBRARY_VERSION);
    REQUIRE(header->profile == "my-profile");
  }

  SECTION("custom library") {
    Buffer buffer;
    mcap::McapWriter writer;
    mcap::McapWriterOptions opts("my-profile");
    opts.library = "my-library";
    writer.open(buffer, opts);
    writer.close();

    mcap::McapReader reader;
    auto status = reader.open(buffer);
    requireOk(status);

    auto header = reader.header();
    REQUIRE(header != std::nullopt);

    REQUIRE(header->library == "my-library");
    REQUIRE(header->profile == "my-profile");
  }
}

TEST_CASE("FileReader works on files larger than 2GiB") {
  std::FILE* file = std::tmpfile();
#if defined _WIN32 || defined __CYGWIN__
  // Seeking past the end automatically makes sparse files on POSIX platforms if the filesystem
  // supports it, but Windows needs an ioctl. Without this, the test runs much slower.
  {
    HANDLE hFile = (HANDLE)_get_osfhandle(_fileno(file));
    REQUIRE(hFile != INVALID_HANDLE_VALUE);
    REQUIRE(DeviceIoControl(hFile, FSCTL_SET_SPARSE, nullptr, 0, nullptr, 0, nullptr, nullptr) ==
            TRUE);
  }
#endif
  // 2^30 + 2^30 = 2^31 > 2^31 - 1
  REQUIRE(std::fseek(file, 1L << 30L, SEEK_CUR) == 0);
  REQUIRE(std::fseek(file, 1L << 30L, SEEK_CUR) == 0);
  REQUIRE(std::fwrite("X", 1, 1, file) == 1);
  REQUIRE(std::ferror(file) == 0);
  std::rewind(file);
  auto reader = mcap::FileReader(file);
  REQUIRE(reader.size() == (1LL << 31LL) + 1);
  std::byte* output;
  REQUIRE(reader.read(&output, 1LL << 31LL, 1) == 1);
  REQUIRE((char)*output == 'X');
  REQUIRE(std::ferror(file) == 0);
  std::fclose(file);
}
