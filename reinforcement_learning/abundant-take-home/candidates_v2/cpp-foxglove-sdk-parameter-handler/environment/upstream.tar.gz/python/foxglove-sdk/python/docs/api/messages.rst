.. automodule:: foxglove.messages
   :members:
