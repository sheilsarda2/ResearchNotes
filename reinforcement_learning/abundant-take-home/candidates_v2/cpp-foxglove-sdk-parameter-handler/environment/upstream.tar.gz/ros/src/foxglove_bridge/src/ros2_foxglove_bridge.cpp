#include <filesystem>
#include <fstream>
#include <unordered_set>

#include <rclcpp/version.h>
#include <resource_retriever/retriever.hpp>

#include <foxglove_bridge/ros2_foxglove_bridge.hpp>
#include <foxglove_bridge/version.hpp>

namespace foxglove_bridge {
namespace {
inline bool isHiddenTopicOrService(const std::string& name) {
  if (name.empty()) {
    throw std::invalid_argument("Topic or service name can't be empty");
  }
  return name.front() == '_' || name.find("/_") != std::string::npos;
}

inline foxglove::WebSocketServerCapabilities processCapabilities(
  const std::vector<std::string>& capabilities) {
  const std::unordered_map<std::string, foxglove::WebSocketServerCapabilities>
    STRING_TO_CAPABILITY = {
      {"clientPublish", foxglove::WebSocketServerCapabilities::ClientPublish},
      {"parameters", foxglove::WebSocketServerCapabilities::Parameters},
      {"parametersSubscribe", foxglove::WebSocketServerCapabilities::Parameters},
      {"services", foxglove::WebSocketServerCapabilities::Services},
      {"connectionGraph", foxglove::WebSocketServerCapabilities::ConnectionGraph},
      {"assets", foxglove::WebSocketServerCapabilities::Assets},
    };
  foxglove::WebSocketServerCapabilities out = foxglove::WebSocketServerCapabilities::None;
  for (const auto& capability : capabilities) {
    if (STRING_TO_CAPABILITY.find(capability) != STRING_TO_CAPABILITY.end()) {
      out = out | STRING_TO_CAPABILITY.at(capability);
    }
  }
  return out;
}

inline bool hasCapability(const foxglove::WebSocketServerCapabilities& capabilities,
                          foxglove::WebSocketServerCapabilities capability) {
  return (capabilities & capability) == capability;
}

inline std::vector<std::byte> readFile(const std::string& filepath) {
  std::ifstream file(filepath, std::ios::binary | std::ios::ate);
  if (!file.is_open()) {
    throw std::runtime_error("Failed to open file: " + filepath);
  }

  std::streamsize length = file.tellg();
  file.seekg(0, std::ios::beg);

  std::vector<std::byte> buffer(length);
  if (!file.read(reinterpret_cast<char*>(buffer.data()), length)) {
    throw std::runtime_error("Failed to read file: " + filepath);
  }

  return buffer;
}

#if !RCLCPP_VERSION_GTE(28, 0, 0)
// Prior to Jazzy, GenericSubscription drops MessageInfo from the callback.
// This subclass overrides handle_serialized_message to forward it.
class GenericSubscriptionWithMessageInfo : public rclcpp::GenericSubscription {
public:
  using CallbackWithInfoT =
    std::function<void(std::shared_ptr<rclcpp::SerializedMessage>, const rclcpp::MessageInfo&)>;

  template <typename AllocatorT = std::allocator<void>>
  GenericSubscriptionWithMessageInfo(
    rclcpp::node_interfaces::NodeBaseInterface* node_base,
    const std::shared_ptr<rcpputils::SharedLibrary> ts_lib, const std::string& topic_name,
    const std::string& topic_type, const rclcpp::QoS& qos, CallbackWithInfoT callback,
    const rclcpp::SubscriptionOptionsWithAllocator<AllocatorT>& options)
      // The base class callback is never invoked because we override
      // handle_serialized_message below. A no-op is passed to satisfy
      // the constructor signature.
      : GenericSubscription(
          node_base, ts_lib, topic_name, topic_type, qos,
          [](std::shared_ptr<rclcpp::SerializedMessage>) {}, options)
      , callback_with_info_(std::move(callback)) {}

  void handle_serialized_message(const std::shared_ptr<rclcpp::SerializedMessage>& message,
                                 const rclcpp::MessageInfo& message_info) override {
    callback_with_info_(message, message_info);
  }

private:
  CallbackWithInfoT callback_with_info_;
};
#endif

}  // namespace

using namespace std::chrono_literals;
using namespace std::placeholders;

FoxgloveBridge::FoxgloveBridge(const rclcpp::NodeOptions& options)
    : Node("foxglove_bridge", options) {
  const char* rosDistro = std::getenv("ROS_DISTRO");
  RCLCPP_INFO(this->get_logger(), "Starting foxglove_bridge (%s, %s@%s)", rosDistro,
              foxglove_bridge::FOXGLOVE_BRIDGE_VERSION, foxglove_bridge::FOXGLOVE_BRIDGE_GIT_HASH);

  std::optional<std::map<std::string, std::string>> rosServerInfo;
  if (rosDistro && strlen(rosDistro) > 0) {
    rosServerInfo = std::map<std::string, std::string>{{"ROS_DISTRO", rosDistro}};
  }

  declareParameters(this);

  const auto port = static_cast<uint16_t>(this->get_parameter(PARAM_PORT).as_int());
  const auto address = this->get_parameter(PARAM_ADDRESS).as_string();
  _minQosDepth = static_cast<size_t>(this->get_parameter(PARAM_MIN_QOS_DEPTH).as_int());
  _maxQosDepth = static_cast<size_t>(this->get_parameter(PARAM_MAX_QOS_DEPTH).as_int());
  const bool useTls = this->get_parameter(PARAM_USETLS).as_bool();
  const std::string certfile = this->get_parameter(PARAM_CERTFILE).as_string();
  const std::string keyfile = this->get_parameter(PARAM_KEYFILE).as_string();
  const auto bestEffortQosTopicWhiteList =
    this->get_parameter(PARAM_BEST_EFFORT_QOS_TOPIC_WHITELIST).as_string_array();
  _bestEffortQosTopicWhiteListPatterns = parseRegexStrings(this, bestEffortQosTopicWhiteList);
  const auto topicWhiteList = this->get_parameter(PARAM_TOPIC_WHITELIST).as_string_array();
  _topicWhitelistPatterns = parseRegexStrings(this, topicWhiteList);
  const auto serviceWhiteList = this->get_parameter(PARAM_SERVICE_WHITELIST).as_string_array();
  _serviceWhitelistPatterns = parseRegexStrings(this, serviceWhiteList);
  const auto paramWhiteList = this->get_parameter(PARAM_PARAMETER_WHITELIST).as_string_array();
  const auto paramWhitelistPatterns = parseRegexStrings(this, paramWhiteList);
  _useSimTime = this->get_parameter("use_sim_time").as_bool();
  const auto capabilities = this->get_parameter(PARAM_CAPABILITIES).as_string_array();
  const auto clientTopicWhiteList =
    this->get_parameter(PARAM_CLIENT_TOPIC_WHITELIST).as_string_array();
  const auto clientTopicWhiteListPatterns = parseRegexStrings(this, clientTopicWhiteList);
  _includeHidden = this->get_parameter(PARAM_INCLUDE_HIDDEN).as_bool();
  const auto assetUriAllowlist = this->get_parameter(PARAM_ASSET_URI_ALLOWLIST).as_string_array();
  _assetUriAllowlistPatterns = parseRegexStrings(this, assetUriAllowlist);
  _disableLoanMessage = this->get_parameter(PARAM_DISABLE_LOAN_MESSAGE).as_bool();
  const auto ignoreUnresponsiveParamNodes =
    this->get_parameter(PARAM_IGN_UNRESPONSIVE_PARAM_NODES).as_bool();
  const bool publishClientCount = this->get_parameter(PARAM_PUBLISH_CLIENT_COUNT).as_bool();

  const bool debug = this->get_parameter(PARAM_DEBUG).as_bool();
  if (debug) {
    foxglove::setLogLevel(foxglove::LogLevel::Debug);
    this->get_logger().set_level(rclcpp::Logger::Level::Debug);
  }

  _serverContext = foxglove::Context::create();

  foxglove::WebSocketServerOptions sdkServerOptions;
  _capabilities = processCapabilities(capabilities);
  sdkServerOptions.host = address;
  sdkServerOptions.port = port;
  sdkServerOptions.supported_encodings = {"cdr", "json"};
  sdkServerOptions.capabilities = _capabilities;
  sdkServerOptions.context = _serverContext;

  sdkServerOptions.server_info = rosServerInfo;

  if (_useSimTime) {
    sdkServerOptions.capabilities =
      sdkServerOptions.capabilities | foxglove::WebSocketServerCapabilities::Time;
  }

  // If TLS is enabled, load the certificate and key files from disk
  if (useTls) {
    if (certfile.empty() || !std::filesystem::exists(certfile)) {
      throw std::invalid_argument("certfile must be provided when TLS is enabled and must exist");
    }

    if (keyfile.empty() || !std::filesystem::exists(keyfile)) {
      throw std::invalid_argument("keyfile must be provided when TLS is enabled and must exist");
    }

    sdkServerOptions.tls_identity = foxglove::TlsIdentity{};
    sdkServerOptions.tls_identity->cert = readFile(certfile);
    sdkServerOptions.tls_identity->key = readFile(keyfile);
  }

  // Setup callbacks
  sdkServerOptions.callbacks.onConnectionGraphSubscribe =
    std::bind(&FoxgloveBridge::subscribeConnectionGraph, this, true);
  sdkServerOptions.callbacks.onConnectionGraphUnsubscribe =
    std::bind(&FoxgloveBridge::subscribeConnectionGraph, this, false);
  sdkServerOptions.callbacks.onSubscribe = std::bind(&FoxgloveBridge::subscribe, this, _1, _2);
  sdkServerOptions.callbacks.onUnsubscribe = std::bind(&FoxgloveBridge::unsubscribe, this, _1, _2);

  if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::ClientPublish)) {
    sdkServerOptions.callbacks.onClientAdvertise =
      std::bind(&FoxgloveBridge::clientAdvertise, this, _1, _2);
    sdkServerOptions.callbacks.onClientUnadvertise =
      std::bind(&FoxgloveBridge::clientUnadvertise, this, _1, _2);
    sdkServerOptions.callbacks.onMessageData =
      std::bind(&FoxgloveBridge::clientMessage, this, _1, _2, _3, _4);
  }

  if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::Assets)) {
    sdkServerOptions.fetch_asset = std::bind(&FoxgloveBridge::fetchAsset, this, _1, _2);
  }

  if (hasCapability(sdkServerOptions.capabilities,
                    foxglove::WebSocketServerCapabilities::Parameters)) {
    sdkServerOptions.callbacks.onParametersSubscribe =
      std::bind(&FoxgloveBridge::subscribeParameters, this, _1);
    sdkServerOptions.callbacks.onParametersUnsubscribe =
      std::bind(&FoxgloveBridge::unsubscribeParameters, this, _1);
    sdkServerOptions.callbacks.onGetParameters =
      std::bind(&FoxgloveBridge::getParameters, this, _1, _2, _3);
    sdkServerOptions.callbacks.onSetParameters =
      std::bind(&FoxgloveBridge::setParameters, this, _1, _2, _3);

    _paramInterface = std::make_shared<ParameterInterface>(this, paramWhitelistPatterns,
                                                           ignoreUnresponsiveParamNodes
                                                             ? UnresponsiveNodePolicy::Ignore
                                                             : UnresponsiveNodePolicy::Retry);
    _paramInterface->setParamUpdateCallback(std::bind(&FoxgloveBridge::parameterUpdates, this, _1));
  }

  if (publishClientCount) {
    sdkServerOptions.callbacks.onClientConnect = std::bind(&FoxgloveBridge::onClientConnect, this);
    sdkServerOptions.callbacks.onClientDisconnect =
      std::bind(&FoxgloveBridge::onClientDisconnect, this);
  }

  auto maybeSdkServer = foxglove::WebSocketServer::create(std::move(sdkServerOptions));

  if (!maybeSdkServer.has_value()) {
    throw std::runtime_error(std::string("Couldn't initialize websocket server: ") +
                             foxglove::strerror(maybeSdkServer.error()));
  }

  // Constructing an SDK server also starts it listening automatically
  _server = std::make_unique<foxglove::WebSocketServer>(std::move(maybeSdkServer.value()));
  this->set_parameter(rclcpp::Parameter{PARAM_PORT, _server->port()});
  RCLCPP_INFO(this->get_logger(), "Server listening on port %d", _server->port());

  if (this->get_parameter(PARAM_SYSINFO).as_bool()) {
    foxglove::SystemInfoOptions sysinfoOptions;
    sysinfoOptions.context = _serverContext;
    sysinfoOptions.topic = this->get_parameter(PARAM_SYSINFO_TOPIC).as_string();
    sysinfoOptions.refresh_interval =
      std::chrono::milliseconds(this->get_parameter(PARAM_SYSINFO_REFRESH_INTERVAL).as_int());
    auto maybeSysinfo = foxglove::SystemInfoPublisher::create(std::move(sysinfoOptions));
    if (!maybeSysinfo.has_value()) {
      RCLCPP_WARN(this->get_logger(), "Couldn't start system info publisher: %s",
                  foxglove::strerror(maybeSysinfo.error()));
    } else {
      _sysinfoPublisher =
        std::make_unique<foxglove::SystemInfoPublisher>(std::move(maybeSysinfo.value()));
    }
  }

  if (publishClientCount) {
    static const std::string CLIENT_COUNT_TOPIC = "/foxglove_bridge/client_count";
    _clientCountPublisher = this->create_publisher<std_msgs::msg::UInt32>(
      CLIENT_COUNT_TOPIC, rclcpp::QoS{rclcpp::KeepLast(1)}.transient_local());
    auto init_msg = std_msgs::msg::UInt32();
    init_msg.data = _server->clientCount();
    _clientCountPublisher->publish(
      init_msg);  // Initialize transient local topic to current connection count
  }

  // Start the thread polling for rosgraph changes
  _rosgraphPollThread =
    std::make_unique<std::thread>(std::bind(&FoxgloveBridge::rosgraphPollThread, this));

  _subscriptionCallbackGroup = this->create_callback_group(rclcpp::CallbackGroupType::Reentrant);
  _clientPublishCallbackGroup =
    this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
  _servicesCallbackGroup = this->create_callback_group(rclcpp::CallbackGroupType::Reentrant);

  if (_useSimTime) {
    _clockSubscription = this->create_subscription<rosgraph_msgs::msg::Clock>(
      "/clock", rclcpp::QoS{rclcpp::KeepLast(1)}.best_effort(),
      [&](std::shared_ptr<const rosgraph_msgs::msg::Clock> msg) {
        const auto timestamp = rclcpp::Time{msg->clock}.nanoseconds();
        assert(timestamp >= 0 && "Timestamp is negative");
        _server->broadcastTime(static_cast<uint64_t>(timestamp));
      });
  }

#ifndef FOXGLOVE_REMOTE_ACCESS
  if (this->get_parameter(PARAM_REMOTE_ACCESS).as_bool()) {
    throw std::runtime_error(
      "remote_access is set to true but the bridge was not built with "
      "FOXGLOVE_BRIDGE_REMOTE_ACCESS=ON. Remote access is not available.");
  }
#else
  const bool enableRemoteAccess = this->get_parameter(PARAM_REMOTE_ACCESS).as_bool();
  if (enableRemoteAccess) {
    auto deviceToken = this->get_parameter(PARAM_DEVICE_TOKEN).as_string();
    if (deviceToken.empty()) {
      const char* envToken = std::getenv("FOXGLOVE_DEVICE_TOKEN");
      if (envToken != nullptr) {
        deviceToken = envToken;
      }
    }
    if (deviceToken.empty()) {
      RCLCPP_FATAL(this->get_logger(),
                   "remote_access is enabled but no device_token was provided. "
                   "Set FOXGLOVE_DEVICE_TOKEN or pass the device_token parameter.");
      throw std::runtime_error("missing device_token for remote_access");
    }

    foxglove::RemoteAccessGatewayOptions gatewayOptions;
    gatewayOptions.context = _serverContext;
    gatewayOptions.device_token = deviceToken;
    gatewayOptions.supported_encodings = {"cdr", "json"};
    gatewayOptions.server_info = std::move(rosServerInfo);

    const auto foxgloveApiUrl = this->get_parameter(PARAM_FOXGLOVE_API_URL).as_string();
    if (!foxgloveApiUrl.empty()) {
      gatewayOptions.foxglove_api_url = foxgloveApiUrl;
    }

    // Map WebSocket server capabilities to gateway capabilities
    gatewayOptions.capabilities = foxglove::RemoteAccessGatewayCapabilities::None;
    if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::ClientPublish)) {
      gatewayOptions.capabilities =
        gatewayOptions.capabilities | foxglove::RemoteAccessGatewayCapabilities::ClientPublish;
    }
    if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::Parameters)) {
      gatewayOptions.capabilities =
        gatewayOptions.capabilities | foxglove::RemoteAccessGatewayCapabilities::Parameters;
    }
    if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::Services)) {
      gatewayOptions.capabilities =
        gatewayOptions.capabilities | foxglove::RemoteAccessGatewayCapabilities::Services;
    }
    if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::Assets)) {
      gatewayOptions.capabilities =
        gatewayOptions.capabilities | foxglove::RemoteAccessGatewayCapabilities::Assets;
    }
    if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::ConnectionGraph)) {
      gatewayOptions.capabilities =
        gatewayOptions.capabilities | foxglove::RemoteAccessGatewayCapabilities::ConnectionGraph;
    }

    // Wire up gateway callbacks
    gatewayOptions.callbacks.onConnectionStatusChanged =
      std::bind(&FoxgloveBridge::gatewayConnectionStatusChanged, this, _1);
    gatewayOptions.callbacks.onSubscribe =
      std::bind(&FoxgloveBridge::gatewaySubscribe, this, _1, _2);
    gatewayOptions.callbacks.onUnsubscribe =
      std::bind(&FoxgloveBridge::gatewayUnsubscribe, this, _1, _2);
    gatewayOptions.qos_classifier = std::bind(&FoxgloveBridge::classifyRemoteAccessQos, this, _1);

    if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::ClientPublish)) {
      gatewayOptions.callbacks.onClientAdvertise =
        std::bind(&FoxgloveBridge::gatewayClientAdvertise, this, _1, _2);
      gatewayOptions.callbacks.onClientUnadvertise =
        std::bind(&FoxgloveBridge::gatewayClientUnadvertise, this, _1, _2);
      gatewayOptions.callbacks.onMessageData =
        std::bind(&FoxgloveBridge::gatewayClientMessage, this, _1, _2, _3, _4);
    }

    if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::Assets)) {
      gatewayOptions.fetch_asset = std::bind(&FoxgloveBridge::fetchAsset, this, _1, _2);
    }

    if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::Parameters)) {
      gatewayOptions.callbacks.onParametersSubscribe =
        std::bind(&FoxgloveBridge::subscribeParameters, this, _1);
      gatewayOptions.callbacks.onParametersUnsubscribe =
        std::bind(&FoxgloveBridge::unsubscribeParameters, this, _1);
      gatewayOptions.callbacks.onGetParameters =
        std::bind(&FoxgloveBridge::getParameters, this, _1, _2, _3);
      gatewayOptions.callbacks.onSetParameters =
        std::bind(&FoxgloveBridge::setParameters, this, _1, _2, _3);
    }

    if (hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::ConnectionGraph)) {
      gatewayOptions.callbacks.onConnectionGraphSubscribe =
        std::bind(&FoxgloveBridge::subscribeConnectionGraph, this, true);
      gatewayOptions.callbacks.onConnectionGraphUnsubscribe =
        std::bind(&FoxgloveBridge::subscribeConnectionGraph, this, false);
    }

    auto maybeGateway = foxglove::RemoteAccessGateway::create(std::move(gatewayOptions));
    if (!maybeGateway.has_value()) {
      throw std::runtime_error(std::string("Failed to create remote access gateway: ") +
                               foxglove::strerror(maybeGateway.error()));
    }
    _gateway = std::make_unique<foxglove::RemoteAccessGateway>(std::move(maybeGateway.value()));
    RCLCPP_INFO(this->get_logger(), "Remote access gateway started");
  }
#endif
}

FoxgloveBridge::~FoxgloveBridge() {
  _shuttingDown = true;
  RCLCPP_INFO(this->get_logger(), "Shutting down %s", this->get_name());
  if (_rosgraphPollThread) {
    _rosgraphPollThread->join();
  }
  if (_sysinfoPublisher) {
    _sysinfoPublisher->stop();
  }
#ifdef FOXGLOVE_REMOTE_ACCESS
  if (_gateway) {
    _gateway->stop();
  }
#endif
  _server->stop();
  RCLCPP_INFO(this->get_logger(), "Shutdown complete");
}

void FoxgloveBridge::rosgraphPollThread() {
  updateAdvertisedTopics(get_topic_names_and_types());
  updateAdvertisedServices();

  auto graphEvent = this->get_graph_event();
  while (!_shuttingDown && rclcpp::ok()) {
    try {
      this->wait_for_graph_change(graphEvent, 200ms);
      bool triggered = graphEvent->check_and_clear();
      if (triggered) {
        RCLCPP_DEBUG(this->get_logger(), "rosgraph change detected");
        const auto topicNamesAndTypes = get_topic_names_and_types();
        updateAdvertisedTopics(topicNamesAndTypes);
        updateAdvertisedServices();
        if (_graphSubscriptionCount > 0) {
          updateConnectionGraph(topicNamesAndTypes);
        }
        // Graph changes tend to come in batches, so wait a bit before checking again
        std::this_thread::sleep_for(500ms);
      }
    } catch (const std::exception& ex) {
      RCLCPP_ERROR(this->get_logger(), "Exception thrown in rosgraphPollThread: %s", ex.what());
    }
  }

  RCLCPP_DEBUG(this->get_logger(), "rosgraph polling thread exiting");
}

void FoxgloveBridge::updateAdvertisedTopics(
  const std::map<std::string, std::vector<std::string>>& topicNamesAndTypes) {
  if (!rclcpp::ok()) {
    return;
  }

  std::unordered_set<TopicAndDatatype, PairHash> latestTopics;
  latestTopics.reserve(topicNamesAndTypes.size());
  for (const auto& topicNamesAndType : topicNamesAndTypes) {
    const auto& topicName = topicNamesAndType.first;
    const auto& datatypes = topicNamesAndType.second;

    // Ignore hidden topics if not explicitly included
    if (!_includeHidden && isHiddenTopicOrService(topicName)) {
      continue;
    }

    // Ignore the topic if it is not on the topic whitelist
    if (isWhitelisted(topicName, _topicWhitelistPatterns)) {
      for (const auto& datatype : datatypes) {
        latestTopics.emplace(topicName, datatype);
      }
    }
  }

  if (const auto numIgnoredTopics = topicNamesAndTypes.size() - latestTopics.size()) {
    RCLCPP_DEBUG(
      this->get_logger(),
      "%zu topics have been ignored as they do not match any pattern on the topic whitelist",
      numIgnoredTopics);
  }

  // Collect channels to close outside the lock to avoid deadlock:
  // channel.close() can fire onUnsubscribe callbacks that re-acquire _subscriptionsMutex.
  std::vector<foxglove::RawChannel> channelsToClose;

  {
    std::lock_guard<std::mutex> lock(_subscriptionsMutex);

    // Remove channels for which the topic does not exist anymore
    for (auto channelIt = _channels.begin(); channelIt != _channels.end();) {
      auto& channel = channelIt->second;
      std::string schemaName = channel.schema().value().name;
      std::string topic(channel.topic());
      const TopicAndDatatype topicAndSchemaName = {topic, schemaName};
      if (latestTopics.find(topicAndSchemaName) == latestTopics.end()) {
        const auto channelId = channel.id();
        RCLCPP_INFO(this->get_logger(), "Removing channel %lu for topic \"%s\" (%s)", channelId,
                    topic.c_str(), schemaName.c_str());
        // Remove any active subscriptions for this channel
        _subscriptions.erase(channelId);
        channelsToClose.push_back(std::move(channel));
        channelIt = _channels.erase(channelIt);
      } else {
        channelIt++;
      }
    }

    // Advertise new topics
    for (const auto& topicAndDatatype : latestTopics) {
      const auto& topic = topicAndDatatype.first;
      const auto& schemaName = topicAndDatatype.second;

      if (std::find_if(_channels.begin(), _channels.end(), [&topic, &schemaName](const auto& kvp) {
            const auto& [channelId, channel] = kvp;
            return channel.topic() == topic && channel.schema().value().name == schemaName;
          }) != _channels.end()) {
        continue;
      }

      // Load actual schema and encoding from disk
      // TODO: (FG-10638): Add support for reading schemas from the wire if available
      std::optional<foxglove::Schema> schema = foxglove::Schema();
      schema->name = schemaName;
      std::string messageEncoding;

      try {
        auto [format, msgDefinition] = _messageDefinitionCache.get_full_text(schemaName);
        schema->data_len = msgDefinition.size();
        schema->data = reinterpret_cast<const std::byte*>(msgDefinition.data());

        switch (format) {
          case foxglove_bridge::MessageDefinitionFormat::MSG:
            messageEncoding = "cdr";
            schema->encoding = "ros2msg";
            break;
          case foxglove_bridge::MessageDefinitionFormat::IDL:
            messageEncoding = "cdr";
            schema->encoding = "ros2idl";
            break;
          default:
            RCLCPP_WARN(this->get_logger(), "Unsupported message definition format for type %s",
                        schemaName.c_str());
            continue;
        }
      } catch (const foxglove_bridge::DefinitionNotFoundError& err) {
        // If the definition isn't found, advertise the channel with an empty schema as a fallback
        RCLCPP_WARN(this->get_logger(), "Could not find definition for type %s: %s",
                    schemaName.c_str(), err.what());
        schema = std::nullopt;
      } catch (const std::exception& err) {
        RCLCPP_ERROR(this->get_logger(),
                     "Failed to load schemaDefinition for topic \"%s\" (%s): %s", topic.c_str(),
                     schemaName.c_str(), err.what());
        continue;
      }

      // Create the new SDK channel
      auto channelResult =
        foxglove::RawChannel::create(topic, messageEncoding, schema, _serverContext);
      if (!channelResult.has_value()) {
        RCLCPP_ERROR(this->get_logger(), "Failed to create channel for topic \"%s\" (%s)",
                     topic.c_str(), foxglove::strerror(channelResult.error()));
        continue;
      }

      const ChannelId channelId = channelResult.value().id();
      RCLCPP_INFO(this->get_logger(), "Advertising new channel %lu for topic \"%s\"", channelId,
                  topic.c_str());
      _channels.insert({channelId, std::move(channelResult.value())});
    }
  }

  // Close channels after releasing _subscriptionsMutex, since close() may fire
  // onUnsubscribe callbacks that need to acquire _subscriptionsMutex.
  //
  // This is safe to do outside of the lock because this function is only called
  // single-threaded from rosgraphPollThread, and the removal of the channel
  // from _channels mean both createOrIncrementSubscriptionLocked and
  // rosMessageHandler gracefully ignore channels they can't find.
  for (auto& channel : channelsToClose) {
    channel.close();
  }
}

void FoxgloveBridge::updateAdvertisedServices() {
  if (!rclcpp::ok()) {
    return;
  } else if (!hasCapability(_capabilities, foxglove::WebSocketServerCapabilities::Services)) {
    return;
  }

  // Get the current list of visible services and datatypes from the ROS graph
  const auto serviceNamesAndTypes = this->get_node_graph_interface()->get_service_names_and_types();

  std::lock_guard<std::mutex> lock(_servicesMutex);

  // Remove advertisements for services that have been removed
  std::vector<std::string> servicesToRemove;
  for (const auto& [serviceName, _] : _advertisedServices) {
    if (serviceNamesAndTypes.find(serviceName) == serviceNamesAndTypes.end()) {
      servicesToRemove.push_back(serviceName);
    }
  }
  for (const auto& serviceName : servicesToRemove) {
    _advertisedServices.erase(serviceName);
    _serviceClients.erase(serviceName);
    _serviceHandlers.erase(serviceName);
    auto error = _server->removeService(serviceName);
    if (error != foxglove::FoxgloveError::Ok) {
      RCLCPP_ERROR(this->get_logger(), "Failed to remove service %s: %s", serviceName.c_str(),
                   foxglove::strerror(error));
    }
#ifdef FOXGLOVE_REMOTE_ACCESS
    if (_gateway) {
      auto gatewayError = _gateway->removeService(serviceName);
      if (gatewayError != foxglove::FoxgloveError::Ok) {
        RCLCPP_ERROR(this->get_logger(), "Failed to remove service %s from gateway: %s",
                     serviceName.c_str(), foxglove::strerror(gatewayError));
      }
    }
#endif
  }

  // Advertise new services
  for (const auto& serviceNamesAndType : serviceNamesAndTypes) {
    const auto& serviceName = serviceNamesAndType.first;
    const auto& datatypes = serviceNamesAndType.second;
    const auto& serviceType = datatypes.front();

    // Ignore the service if it's already advertised
    if (_advertisedServices.find(serviceName) != _advertisedServices.end()) {
      continue;
    }

    // Ignore hidden services if not explicitly included
    if (!_includeHidden && isHiddenTopicOrService(serviceName)) {
      continue;
    }

    // Ignore the service if it is not on the service whitelist
    if (!isWhitelisted(serviceName, _serviceWhitelistPatterns)) {
      continue;
    }

    foxglove::ServiceSchema serviceSchema;
    serviceSchema.name = serviceType;

    // Read and initialize the service schema
    try {
      const auto requestTypeName = serviceType + foxglove_bridge::SERVICE_REQUEST_MESSAGE_SUFFIX;
      const auto responseTypeName = serviceType + foxglove_bridge::SERVICE_RESPONSE_MESSAGE_SUFFIX;
      const auto& [format, reqSchema] = _messageDefinitionCache.get_full_text(requestTypeName);
      const auto& resSchema = _messageDefinitionCache.get_full_text(responseTypeName).second;
      std::string schemaEncoding = "";
      std::string messageEncoding = "";
      switch (format) {
        case foxglove_bridge::MessageDefinitionFormat::MSG:
          schemaEncoding = "ros2msg";
          messageEncoding = "cdr";
          break;
        case foxglove_bridge::MessageDefinitionFormat::IDL:
          // REVIEW: Is this still true in the SDK?
          RCLCPP_WARN(this->get_logger(),
                      "IDL message definition format cannot be communicated over ws-protocol. "
                      "Service \"%s\" (%s) may not decode correctly in clients",
                      serviceName.c_str(), serviceType.c_str());
          schemaEncoding = "ros2idl";
          messageEncoding = "cdr";
          break;
        default:
          RCLCPP_ERROR(this->get_logger(), "Unsupported message definition format for type %s",
                       requestTypeName.c_str());
          continue;
      }
      serviceSchema.request = std::make_optional<foxglove::ServiceMessageSchema>();
      serviceSchema.request->encoding = messageEncoding;
      serviceSchema.request->schema = foxglove::Schema{
        requestTypeName,
        schemaEncoding,
        reinterpret_cast<const std::byte*>(reqSchema.data()),
        reqSchema.size(),
      };

      serviceSchema.response = std::make_optional<foxglove::ServiceMessageSchema>();
      serviceSchema.response->encoding = messageEncoding;
      serviceSchema.response->schema = foxglove::Schema{
        responseTypeName,
        schemaEncoding,
        reinterpret_cast<const std::byte*>(resSchema.data()),
        resSchema.size(),
      };
    } catch (const foxglove_bridge::DefinitionNotFoundError& err) {
      RCLCPP_WARN(this->get_logger(), "Could not find definition for type %s: %s",
                  serviceType.c_str(), err.what());
      // We still advertise the service, but with an empty schema
      serviceSchema.request = std::nullopt;
      serviceSchema.response = std::nullopt;
    } catch (const std::exception& err) {
      RCLCPP_WARN(this->get_logger(), "Failed to add service \"%s\" (%s): %s", serviceName.c_str(),
                  serviceType.c_str(), err.what());
      continue;
    }

    // Set up ROS service client
    try {
      auto clientOptions = rcl_client_get_default_options();
      auto [it, _] = _serviceClients.insert(
        {serviceName, std::make_shared<GenericClient>(this->get_node_base_interface().get(),
                                                      this->get_node_graph_interface(), serviceName,
                                                      serviceType, clientOptions)});
      this->get_node_services_interface()->add_client(it->second, _servicesCallbackGroup);
    } catch (const std::exception& ex) {
      RCLCPP_ERROR(this->get_logger(), "Failed to create service client for service %s: %s",
                   serviceName.c_str(), ex.what());
      continue;
    }

    auto handler = std::make_unique<foxglove::ServiceHandler>(
      [this](const foxglove::ServiceRequest& req, foxglove::ServiceResponder&& res) {
        this->handleServiceRequest(req, std::move(res));
      });

    _serviceHandlers.insert({serviceName, std::move(handler)});

    auto serviceResult =
      foxglove::Service::create(serviceName, serviceSchema, *_serviceHandlers.at(serviceName));
    if (!serviceResult.has_value()) {
      RCLCPP_ERROR(this->get_logger(), "Failed to create service %s: %s", serviceName.c_str(),
                   foxglove::strerror(serviceResult.error()));
      continue;
    }

    auto addServiceError = _server->addService(std::move(serviceResult.value()));
    if (addServiceError != foxglove::FoxgloveError::Ok) {
      RCLCPP_ERROR(this->get_logger(), "Failed to add service %s to server: %s",
                   serviceName.c_str(), foxglove::strerror(addServiceError));
      continue;
    }

#ifdef FOXGLOVE_REMOTE_ACCESS
    if (_gateway) {
      auto gatewayServiceResult =
        foxglove::Service::create(serviceName, serviceSchema, *_serviceHandlers.at(serviceName));
      if (gatewayServiceResult.has_value()) {
        auto gatewayAddError = _gateway->addService(std::move(gatewayServiceResult.value()));
        if (gatewayAddError != foxglove::FoxgloveError::Ok) {
          RCLCPP_ERROR(this->get_logger(), "Failed to add service %s to gateway: %s",
                       serviceName.c_str(), foxglove::strerror(gatewayAddError));
        }
      } else {
        RCLCPP_ERROR(this->get_logger(), "Failed to create gateway service %s: %s",
                     serviceName.c_str(), foxglove::strerror(gatewayServiceResult.error()));
      }
    }
#endif

    _advertisedServices.insert({serviceName, serviceType});
  }
}

void FoxgloveBridge::updateConnectionGraph(
  const std::map<std::string, std::vector<std::string>>& topicNamesAndTypes) {
  MapOfSets publishers, subscribers;
  foxglove::ConnectionGraph connectionGraph;

  for (const auto& topicNameAndType : topicNamesAndTypes) {
    const auto& topicName = topicNameAndType.first;
    if (!isWhitelisted(topicName, _topicWhitelistPatterns)) {
      continue;
    }

    const auto publishersInfo = get_publishers_info_by_topic(topicName);
    const auto subscribersInfo = get_subscriptions_info_by_topic(topicName);
    std::unordered_set<std::string> publisherIds, subscriberIds;
    for (const auto& publisher : publishersInfo) {
      const auto& ns = publisher.node_namespace();
      const auto sep = (!ns.empty() && ns.back() == '/') ? "" : "/";
      publisherIds.insert(ns + sep + publisher.node_name());
    }
    for (const auto& subscriber : subscribersInfo) {
      const auto& ns = subscriber.node_namespace();
      const auto sep = (!ns.empty() && ns.back() == '/') ? "" : "/";
      subscriberIds.insert(ns + sep + subscriber.node_name());
    }
    publishers.emplace(topicName, publisherIds);
    subscribers.emplace(topicName, subscriberIds);

    std::vector<std::string> publisherIdsVec(publisherIds.begin(), publisherIds.end());
    std::vector<std::string> subscriberIdsVec(subscriberIds.begin(), subscriberIds.end());
    connectionGraph.setPublishedTopic(topicName, publisherIdsVec);
    connectionGraph.setSubscribedTopic(topicName, subscriberIdsVec);
  }

  MapOfSets services;
  for (const auto& fqnNodeName : get_node_names()) {
    const auto [nodeNs, nodeName] = getNodeAndNodeNamespace(fqnNodeName);
    const auto serviceNamesAndTypes = get_service_names_and_types_by_node(nodeName, nodeNs);

    for (const auto& [serviceName, serviceTypes] : serviceNamesAndTypes) {
      (void)serviceTypes;
      if (isWhitelisted(serviceName, _serviceWhitelistPatterns)) {
        services[serviceName].insert(fqnNodeName);
      }
    }
  }
  for (const auto& [serviceName, providerIds] : services) {
    connectionGraph.setAdvertisedService(serviceName,
                                         std::vector(providerIds.begin(), providerIds.end()));
  }

  RCLCPP_INFO(this->get_logger(), "publishing connection graph");
  _server->publishConnectionGraph(connectionGraph);
#ifdef FOXGLOVE_REMOTE_ACCESS
  if (_gateway) {
    (void)_gateway->publishConnectionGraph(connectionGraph);
  }
#endif
}

void FoxgloveBridge::subscribeConnectionGraph(bool subscribe) {
  RCLCPP_INFO(this->get_logger(), "received connection graph subscribe request");
  if (subscribe) {
    ++_graphSubscriptionCount;
    // TODO: This causes a deadlock in the SDK implementation
    // updateConnectionGraph(get_topic_names_and_types());
  } else if (_graphSubscriptionCount.fetch_sub(1) <= 0) {
    _graphSubscriptionCount.fetch_add(1);
  }
}

void FoxgloveBridge::subscribe(ChannelId channelId, const foxglove::ClientMetadata& client) {
  RCLCPP_INFO(this->get_logger(), "received subscribe request for channel %lu from client %u",
              channelId, client.id);
  createOrIncrementSubscription(channelId, client.id, false, client.sink_id);
}

Subscription FoxgloveBridge::createRosSubscription(ChannelId channelId, const std::string& topic,
                                                   const std::string& datatype,
                                                   const rclcpp::QoS& qos) {
  rclcpp::SubscriptionEventCallbacks eventCallbacks;
  eventCallbacks.incompatible_qos_callback =
    [this, topic, datatype](const rclcpp::QOSRequestedIncompatibleQoSInfo&) {
      RCLCPP_ERROR(this->get_logger(), "Incompatible subscriber QoS settings for topic \"%s\" (%s)",
                   topic.c_str(), datatype.c_str());
    };

  rclcpp::SubscriptionOptions subscriptionOptions;
  subscriptionOptions.event_callbacks = eventCallbacks;
  subscriptionOptions.callback_group = _subscriptionCallbackGroup;

#if RCLCPP_VERSION_GTE(28, 0, 0)
  return this->create_generic_subscription(
    topic, datatype, qos,
    [this, channelId](std::shared_ptr<const rclcpp::SerializedMessage> msg,
                      const rclcpp::MessageInfo& messageInfo) {
      this->rosMessageHandler(channelId, msg, messageInfo);
    },
    subscriptionOptions);
#else
  auto ts_lib = rclcpp::get_typesupport_library(datatype, "rosidl_typesupport_cpp");
  auto subscription = std::make_shared<GenericSubscriptionWithMessageInfo>(
    this->get_node_base_interface().get(), std::move(ts_lib), topic, datatype, qos,
    [this, channelId](std::shared_ptr<rclcpp::SerializedMessage> msg,
                      const rclcpp::MessageInfo& messageInfo) {
      this->rosMessageHandler(channelId, msg, messageInfo);
    },
    subscriptionOptions);
  this->get_node_topics_interface()->add_subscription(subscription,
                                                      subscriptionOptions.callback_group);
  return subscription;
#endif
}

void FoxgloveBridge::createOrIncrementSubscription(ChannelId channelId, ClientId clientId,
                                                   bool isGateway, std::optional<SinkId> sinkId) {
  std::lock_guard<std::mutex> lock(_subscriptionsMutex);
  createOrIncrementSubscriptionLocked(channelId, clientId, isGateway, sinkId);
}

void FoxgloveBridge::createOrIncrementSubscriptionLocked(ChannelId channelId, ClientId clientId,
                                                         bool isGateway,
                                                         std::optional<SinkId> sinkId) {
  auto channelIt = _channels.find(channelId);
  if (channelIt == _channels.end()) {
    RCLCPP_ERROR(this->get_logger(), "received subscribe request for unknown channel: %lu",
                 channelId);
    return;
  }

  auto& channel = channelIt->second;

  auto subIt = _subscriptions.find(channelId);
  bool isNewSubscription = (subIt == _subscriptions.end());

  if (isNewSubscription) {
    // First subscriber for this channel -- create the ROS subscription
    const std::string topic(channel.topic());
    const std::string datatype = channel.schema().value().name;
    const rclcpp::QoS qos = determineQoS(topic);

    ChannelSubscription channelSub;
    channelSub.rosSubscription = createRosSubscription(channelId, topic, datatype, qos);
    channelSub.qos = qos;

    if (qos.durability() == rclcpp::DurabilityPolicy::TransientLocal) {
      for (const auto& pub : this->get_publishers_info_by_topic(topic)) {
        Gid gid = pub.endpoint_gid();
        channelSub.publisherCaches[gid].maxMessages =
          std::max(static_cast<size_t>(1), pub.qos_profile().depth());
      }
    }

    auto [it, inserted] = _subscriptions.emplace(channelId, std::move(channelSub));
    subIt = it;

    RCLCPP_INFO(this->get_logger(), "Created ROS subscription on %s (%s) for channel %lu",
                topic.c_str(), datatype.c_str(), channelId);
  }

  // For transient_local topics, replay cached messages to the new client before adding
  // them to the broadcast set, so they don't miss latched values.
  if (!isNewSubscription && sinkId.has_value()) {
    for (const auto& [gid, cache] : subIt->second.publisherCaches) {
      for (const auto& cached : cache.messages) {
        channel.log(reinterpret_cast<const std::byte*>(cached.data.data()), cached.data.size(),
                    cached.timestamp, sinkId.value());
      }
    }
  }

  // Add client to the appropriate set
  if (isGateway) {
    subIt->second.gatewayClientIds.insert(clientId);
  } else {
    subIt->second.wsClientIds.insert(clientId);
  }
}

void FoxgloveBridge::unsubscribe(ChannelId channelId, const foxglove::ClientMetadata& client) {
  RCLCPP_INFO(this->get_logger(), "received unsubscribe request for channel %lu from client %u",
              channelId, client.id);
  removeOrDecrementSubscription(channelId, client.id, false);
}

void FoxgloveBridge::removeOrDecrementSubscription(ChannelId channelId, ClientId clientId,
                                                   bool isGateway) {
  std::lock_guard<std::mutex> lock(_subscriptionsMutex);
  removeOrDecrementSubscriptionLocked(channelId, clientId, isGateway);
}

void FoxgloveBridge::removeOrDecrementSubscriptionLocked(ChannelId channelId, ClientId clientId,
                                                         bool isGateway) {
  auto subIt = _subscriptions.find(channelId);
  if (subIt == _subscriptions.end()) {
    RCLCPP_ERROR(this->get_logger(),
                 "Client %u tried unsubscribing from channel %lu but no subscription exists",
                 clientId, channelId);
    return;
  }

  // Remove client from the appropriate set
  if (isGateway) {
    subIt->second.gatewayClientIds.erase(clientId);
  } else {
    subIt->second.wsClientIds.erase(clientId);
  }

  // If no more subscribers, destroy the ROS subscription
  if (subIt->second.wsClientIds.empty() && subIt->second.gatewayClientIds.empty()) {
    RCLCPP_INFO(this->get_logger(),
                "Cleaned up ROS subscription for channel %lu (no more subscribers)", channelId);
    _subscriptions.erase(subIt);
  }
}

ClientAdvertisement FoxgloveBridge::createClientPublisher(const std::string& topicName,
                                                          const std::string& topicType,
                                                          const std::string& encoding,
                                                          const std::byte* schemaData,
                                                          size_t schemaLen) {
  // Create a JSON parser for this schema if needed
  std::shared_ptr<RosMsgParser::Parser> jsonParser;
  if (encoding == "json") {
    auto parserIt = _jsonParsers.find(topicType);
    if (parserIt != _jsonParsers.end()) {
      jsonParser = parserIt->second;
    } else {
      std::string schema;
      if (schemaLen > 0) {
        schema = std::string(reinterpret_cast<const char*>(schemaData), schemaLen);
      } else {
        auto [format, msgDefinition] = _messageDefinitionCache.get_full_text(topicType);
        if (format != foxglove_bridge::MessageDefinitionFormat::MSG) {
          throw std::runtime_error("Message definition (.msg) for schema " + topicType +
                                   " not found");
        }
        schema = msgDefinition;
      }
      jsonParser =
        std::make_shared<RosMsgParser::Parser>(topicName, RosMsgParser::ROSType(topicType), schema);
      _jsonParsers.insert({topicType, jsonParser});
    }
  }

  // Lookup if there are publishers from other nodes for that topic. If that's the case, we
  // use a matching QoS profile.
  const auto otherPublishers = get_publishers_info_by_topic(topicName);
  const auto otherPublisherIt =
    std::find_if(otherPublishers.begin(), otherPublishers.end(),
                 [this](const rclcpp::TopicEndpointInfo& endpoint) {
                   return endpoint.node_name() != this->get_name() ||
                          endpoint.node_namespace() != this->get_namespace();
                 });
  rclcpp::QoS qos = otherPublisherIt == otherPublishers.end() ? rclcpp::SystemDefaultsQoS()
                                                              : otherPublisherIt->qos_profile();

  // When the QoS profile is copied from another existing publisher, it can happen that the
  // history policy is Unknown, leading to an error when subsequently trying to create a
  // publisher with that QoS profile. As a fix, we explicitly set the history policy to the
  // system default.
  if (qos.history() == rclcpp::HistoryPolicy::Unknown) {
    qos.history(rclcpp::HistoryPolicy::SystemDefault);
  }
  rclcpp::PublisherOptions publisherOptions{};
  publisherOptions.callback_group = _clientPublishCallbackGroup;
  auto publisher = this->create_generic_publisher(topicName, topicType, qos, publisherOptions);

  return ClientAdvertisement{std::move(publisher), topicName, topicType, encoding, jsonParser};
}

void FoxgloveBridge::publishClientData(const ClientAdvertisement& ad, const std::byte* data,
                                       size_t dataLen) {
  auto publishMessage = [&ad, this](const void* msgData, size_t size) {
    // Copy the message payload into a SerializedMessage object
    rclcpp::SerializedMessage serializedMessage{size};
    auto& rclSerializedMsg = serializedMessage.get_rcl_serialized_message();
    std::memcpy(rclSerializedMsg.buffer, msgData, size);
    rclSerializedMsg.buffer_length = size;
    // Publish the message
    if (_disableLoanMessage || !ad.publisher->can_loan_messages()) {
      ad.publisher->publish(serializedMessage);
    } else {
      ad.publisher->publish_as_loaned_msg(serializedMessage);
    }
  };

  if (ad.encoding == "cdr") {
    publishMessage(data, dataLen);
  } else if (ad.encoding == "json") {
    if (!ad.jsonParser) {
      throw std::runtime_error("no JSON parser found for schema \"" + ad.topicType + "\"");
    }
    thread_local RosMsgParser::ROS2_Serializer serializer;
    serializer.reset();
    const std::string jsonMessage(reinterpret_cast<const char*>(data), dataLen);
    ad.jsonParser->serializeFromJson(jsonMessage, &serializer);
    publishMessage(serializer.getBufferData(), serializer.getBufferSize());
  } else {
    throw std::runtime_error("unknown encoding \"" + ad.encoding + "\"");
  }
}

void FoxgloveBridge::clientAdvertise(ClientId clientId, const foxglove::ClientChannel& channel) {
  std::lock_guard<std::mutex> lock(_clientAdvertisementsMutex);

  ChannelAndClientId key = {channel.id, clientId};
  const std::string topicName(channel.topic);
  const std::string topicType(channel.schema_name);
  const std::string encoding(channel.encoding);

  if (_clientAdvertisedTopics.find(key) != _clientAdvertisedTopics.end()) {
    throw ClientChannelError("Received client advertisement from client ID " +
                             std::to_string(clientId) + " for channel " +
                             std::to_string(channel.id) + " it had already advertised");
  }

  if (topicType.empty()) {
    throw ClientChannelError("Received client advertisement from client ID " +
                             std::to_string(clientId) + " for channel " +
                             std::to_string(channel.id) + " with empty schema name");
  }

  try {
    auto ad =
      createClientPublisher(topicName, topicType, encoding, channel.schema, channel.schema_len);
    RCLCPP_INFO(this->get_logger(),
                "Client ID %d is advertising \"%s\" (%s) on channel %d with encoding \"%s\"",
                clientId, topicName.c_str(), topicType.c_str(), channel.id, encoding.c_str());
    _clientAdvertisedTopics.emplace(key, std::move(ad));
  } catch (const std::exception& ex) {
    throw ClientChannelError("Failed to create publisher for client channel " +
                             std::to_string(channel.id) + ": " + ex.what());
  }
}

void FoxgloveBridge::clientUnadvertise(ClientId clientId, ChannelId clientChannelId) {
  std::lock_guard<std::mutex> lock(_clientAdvertisementsMutex);

  ChannelAndClientId key = {clientChannelId, clientId};

  auto it = _clientAdvertisedTopics.find(key);
  if (it == _clientAdvertisedTopics.end()) {
    throw ClientChannelError("Ignoring client unadvertisement from client ID " +
                             std::to_string(clientId) + " for unknown channel " +
                             std::to_string(clientChannelId));
  }

  const auto& publisher = it->second.publisher;
  RCLCPP_INFO(this->get_logger(),
              "Client ID %u is no longer advertising %s (%zu subscribers) on channel %lu", clientId,
              publisher->get_topic_name(), publisher->get_subscription_count(), clientChannelId);

  _clientAdvertisedTopics.erase(it);

  if (!_shuttingDown && rclcpp::ok()) {
    // Create a timer that immediately goes out of scope (so it never fires) which will trigger
    // the previously destroyed publisher to be cleaned up. This is a workaround for
    // https://github.com/ros2/rclcpp/issues/2146
    this->create_wall_timer(1s, []() {});
  }
}

void FoxgloveBridge::clientMessage(ClientId clientId, ChannelId clientChannelId,
                                   const std::byte* data, size_t dataLen) {
  ClientAdvertisement ad;
  {
    const ChannelAndClientId key = {clientChannelId, clientId};
    std::lock_guard<std::mutex> lock(_clientAdvertisementsMutex);

    auto it = _clientAdvertisedTopics.find(key);
    if (it == _clientAdvertisedTopics.end()) {
      throw ClientChannelError("Dropping client message from client ID " +
                               std::to_string(clientId) + " for unknown channel " +
                               std::to_string(clientChannelId) +
                               ", client has no advertised topics");
    }

    ad = it->second;
  }

  try {
    publishClientData(ad, data, dataLen);
  } catch (const std::exception& ex) {
    throw ClientChannelError("Dropping client message on client channel " +
                             std::to_string(clientChannelId) + " from client ID " +
                             std::to_string(clientId) + ": " + ex.what());
  }
}

std::vector<foxglove::Parameter> FoxgloveBridge::setParameters(
  const ClientId clientId [[maybe_unused]], const std::optional<std::string_view>& requestId,
  const std::vector<foxglove::ParameterView>& parameterViews) {
  // Copy parameters to a vector
  std::vector<foxglove::Parameter> parameters;
  std::transform(parameterViews.cbegin(), parameterViews.cend(), std::back_inserter(parameters),
                 [](const foxglove::ParameterView& pv) {
                   return pv.clone();
                 });

  _paramInterface->setParams(parameters, std::chrono::seconds(5));

  // REVIEW: The previous implementation would publish updated parameters to the client only if a
  // request ID was passed. Since the SDK server publishes any parameters returned from this
  // function, to maintain the same behavior, we only return a non-empty vector if a request ID was
  // passed. If feels like too much of a kludge, we can remove this check but will need to either:
  //
  // (1) Update tests/client implementations to be robust to multiple parameter updates being
  // received if they are subscribed to parameter updates AND set a parameter, or (2) Update the SDK
  // server to avoid double-publishing parameters to a client that's setting a param and is
  // subscribed to parameter updates.
  if (requestId.has_value()) {
    // Get parameters again and publish them to the SDK server
    std::vector<std::string_view> parameterNames;
    parameterNames.reserve(parameters.size());
    for (const auto& param : parameters) {
      parameterNames.push_back(param.name());
    }

    auto updatedParameters = _paramInterface->getParams(parameterNames, std::chrono::seconds(5));
    return updatedParameters;
  }

  return {};
}

std::vector<foxglove::Parameter> FoxgloveBridge::getParameters(
  const ClientId clientId [[maybe_unused]],
  const std::optional<std::string_view>& requestId [[maybe_unused]],
  const std::vector<std::string_view>& parameterNames) {
  return _paramInterface->getParams(parameterNames, std::chrono::seconds(5));
}

void FoxgloveBridge::subscribeParameters(const std::vector<std::string_view>& parameterNames) {
  _paramInterface->subscribeParams(parameterNames);
}

void FoxgloveBridge::unsubscribeParameters(const std::vector<std::string_view>& parameterNames) {
  _paramInterface->unsubscribeParams(parameterNames);
}

void FoxgloveBridge::parameterUpdates(const std::vector<foxglove::Parameter>& parameters) {
  _server->publishParameterValues(ParameterInterface::cloneParameterList(parameters));
#ifdef FOXGLOVE_REMOTE_ACCESS
  if (_gateway) {
    _gateway->publishParameterValues(ParameterInterface::cloneParameterList(parameters));
  }
#endif
}

void FoxgloveBridge::rosMessageHandler(ChannelId channelId,
                                       std::shared_ptr<const rclcpp::SerializedMessage> msg,
                                       const rclcpp::MessageInfo& messageInfo) {
  // NOTE: Do not call any RCLCPP_* logging functions from this function. Otherwise, subscribing
  // to `/rosout` will cause a feedback loop
  const auto timestamp = this->now().nanoseconds();
  assert(timestamp >= 0 && "Timestamp is negative");
  const auto rclSerializedMsg = msg->get_rcl_serialized_message();

  std::lock_guard<std::mutex> lock(_subscriptionsMutex);
  auto channelIt = _channels.find(channelId);
  if (channelIt == _channels.end()) {
    return;
  }

  // Cache messages per-publisher for transient_local subscriptions so late subscribers receive
  // them.
  auto subIt = _subscriptions.find(channelId);
  if (subIt != _subscriptions.end() &&
      subIt->second.qos.durability() == rclcpp::DurabilityPolicy::TransientLocal) {
    Gid gid;
    const auto& rawGid = messageInfo.get_rmw_message_info().publisher_gid;
    std::copy(rawGid.data, rawGid.data + RMW_GID_STORAGE_SIZE, gid.begin());

    auto& pubCache = subIt->second.publisherCaches[gid];
    if (pubCache.messages.size() >= pubCache.maxMessages) {
      pubCache.messages.pop_front();
    }
    pubCache.messages.push_back(CachedMessage{
      {rclSerializedMsg.buffer, rclSerializedMsg.buffer + rclSerializedMsg.buffer_length},
      static_cast<uint64_t>(timestamp),
    });
  }

  // Log without sink_id to broadcast to all sinks (WebSocket server + Gateway).
  // Each sink internally handles routing to its subscribed clients.
  channelIt->second.log(reinterpret_cast<const std::byte*>(rclSerializedMsg.buffer),
                        rclSerializedMsg.buffer_length, timestamp);
}

void FoxgloveBridge::handleServiceRequest(const foxglove::ServiceRequest& request,
                                          foxglove::ServiceResponder&& responder) {
  RCLCPP_DEBUG(this->get_logger(), "Received a request for service %s",
               request.service_name.c_str());

  std::lock_guard<std::mutex> lock(_servicesMutex);
  auto serviceIt = _advertisedServices.find(request.service_name);
  if (serviceIt == _advertisedServices.end()) {
    std::string errorMessage = "Service " + request.service_name + " does not exist";
    RCLCPP_ERROR(this->get_logger(), "%s", errorMessage.c_str());
    std::move(responder).respondError(errorMessage);
    return;
  }

  const auto& [serviceName, serviceType] = *serviceIt;

  if (_serviceClients.find(serviceName) == _serviceClients.end()) {
    std::string errorMessage =
      "Service " + request.service_name + " is advertised but no client exists for it";
    RCLCPP_ERROR(this->get_logger(), "%s", errorMessage.c_str());
    std::move(responder).respondError(errorMessage);
    return;
  }

  auto client = _serviceClients.at(serviceName);
  if (!client->wait_for_service(1s)) {
    std::string errorMessage = "Service " + serviceName + " is not available";
    RCLCPP_ERROR(this->get_logger(), "%s", errorMessage.c_str());
    std::move(responder).respondError(errorMessage);
    return;
  }

  if (request.encoding != "cdr") {
    std::string errorMessage = "Service " + serviceName +
                               " received a request with an unsupported encoding " +
                               request.encoding;
    RCLCPP_ERROR(this->get_logger(), "%s", errorMessage.c_str());
    std::move(responder).respondError(errorMessage);
    return;
  }

  auto reqMessage = std::make_shared<rclcpp::SerializedMessage>(request.payload.size());
  std::memcpy(reqMessage->get_rcl_serialized_message().buffer, request.payload.data(),
              request.payload.size());
  reqMessage->get_rcl_serialized_message().buffer_length = request.payload.size();

  client->async_send_request(reqMessage, std::move(responder));
}

void FoxgloveBridge::fetchAsset(const std::string_view uriView,
                                foxglove::FetchAssetResponder&& responder) {
  std::string uri(uriView);
  try {
    // We reject URIs that are not on the allowlist or that contain two consecutive dots. The
    // latter can be utilized to construct URIs for retrieving confidential files that should
    // not be accessible over the WebSocket connection. Example:
    // `package://<pkg_name>/../../../secret.txt`. This is an extra security measure and should
    // not be necessary if the allowlist is strict enough.
    if (uri.find("..") != std::string::npos || !isWhitelisted(uri, _assetUriAllowlistPatterns)) {
      throw std::runtime_error("Asset URI not allowed: " + uri);
    }

    resource_retriever::Retriever resource_retriever;

    // The resource_retriever API has changed from 3.7 onwards.
#if RESOURCE_RETRIEVER_VERSION_MAJOR > 3 || \
  (RESOURCE_RETRIEVER_VERSION_MAJOR == 3 && RESOURCE_RETRIEVER_VERSION_MINOR > 6)
    const auto memoryResource = resource_retriever.get_shared(uri);
    std::vector<std::byte> data(memoryResource->data.size());
    std::memcpy(data.data(), memoryResource->data.data(), memoryResource->data.size());
    std::move(responder).respondOk(data);
#else
    const resource_retriever::MemoryResource memoryResource = resource_retriever.get(uri);
    std::vector<std::byte> data(memoryResource.size);
    std::memcpy(data.data(), memoryResource.data.get(), memoryResource.size);
    std::move(responder).respondOk(data);
#endif
  } catch (const std::exception& ex) {
    RCLCPP_WARN(this->get_logger(), "Failed to retrieve asset '%s': %s", uri.c_str(), ex.what());
    std::move(responder).respondError("Failed to retrieve asset " + uri);
  }
}

FoxgloveBridge::TopicQosInfo FoxgloveBridge::collectTopicQosInfo(const std::string& topic) {
  TopicQosInfo info;
  info.bestEffortForced = isWhitelisted(topic, _bestEffortQosTopicWhiteListPatterns);

  const auto publisherInfo = this->get_publishers_info_by_topic(topic);
  info.publisherCount = publisherInfo.size();
  for (const auto& publisher : publisherInfo) {
    const auto& qos = publisher.qos_profile();
    if (qos.reliability() == rclcpp::ReliabilityPolicy::Reliable) {
      ++info.reliableCount;
    }
    if (qos.durability() == rclcpp::DurabilityPolicy::TransientLocal) {
      ++info.transientLocalCount;
    }
    // Some RMWs do not retrieve history information of the publisher endpoint in which case the
    // history depth is 0. We use a lower limit of 1 here, so that the history depth is at least
    // equal to the number of publishers. This covers the case where there are multiple
    // transient_local publishers with a depth of 1 (e.g. multiple tf_static transform
    // broadcasters). See also
    // https://github.com/foxglove/ros-foxglove-bridge/issues/238 and
    // https://github.com/foxglove/ros-foxglove-bridge/issues/208
    info.totalHistoryDepth += std::max(static_cast<size_t>(1), qos.depth());
  }

  return info;
}

rclcpp::QoS FoxgloveBridge::determineQoS(const std::string& topic) {
  // Select an appropriate subscription QOS profile. This is similar to how ros2 topic echo
  // does it:
  // https://github.com/ros2/ros2cli/blob/619b3d1c9/ros2topic/ros2topic/verb/echo.py#L137-L194
  const auto info = collectTopicQosInfo(topic);

  size_t depth = std::max(info.totalHistoryDepth, _minQosDepth);
  if (depth > _maxQosDepth) {
    RCLCPP_WARN(this->get_logger(),
                "Limiting history depth for topic '%s' to %zu (was %zu). You may want to increase "
                "the max_qos_depth parameter value.",
                topic.c_str(), _maxQosDepth, depth);
    depth = _maxQosDepth;
  }

  rclcpp::QoS qos{rclcpp::KeepLast(depth)};

  // Force the QoS to be "best_effort" if in the whitelist
  if (info.bestEffortForced) {
    qos.best_effort();
  } else if (info.publisherCount > 0 && info.reliableCount == info.publisherCount) {
    // If all endpoints are reliable, ask for reliable
    qos.reliable();
  } else {
    if (info.reliableCount > 0) {
      RCLCPP_WARN(
        this->get_logger(),
        "Some, but not all, publishers on topic '%s' are offering "
        "QoSReliabilityPolicy.RELIABLE. "
        "Falling back to QoSReliabilityPolicy.BEST_EFFORT as it will connect to all publishers",
        topic.c_str());
    }
    qos.best_effort();
  }

  // If all endpoints are transient_local, ask for transient_local
  if (info.publisherCount > 0 && info.transientLocalCount == info.publisherCount) {
    qos.transient_local();
  } else {
    if (info.transientLocalCount > 0) {
      RCLCPP_WARN(this->get_logger(),
                  "Some, but not all, publishers on topic '%s' are offering "
                  "QoSDurabilityPolicy.TRANSIENT_LOCAL. Falling back to "
                  "QoSDurabilityPolicy.VOLATILE as it will connect to all publishers",
                  topic.c_str());
    }
    qos.durability_volatile();
  }

  return qos;
}

#ifdef FOXGLOVE_REMOTE_ACCESS
foxglove::QosProfile FoxgloveBridge::classifyRemoteAccessQos(
  const foxglove::ChannelDescriptor& channel) {
  // Mirror the reliability/durability decisions made by determineQoS: a topic qualifies for a
  // Reliable remote access profile only when it is not forced to best_effort by the whitelist
  // and every publisher offers both Reliable and TransientLocal. Anything else falls back to
  // the default (lossy data-track) profile.
  foxglove::QosProfile profile;
  const auto info = collectTopicQosInfo(std::string(channel.topic()));

  if (info.bestEffortForced || info.publisherCount == 0) {
    return profile;
  }

  const bool allReliable = info.reliableCount == info.publisherCount;
  const bool allTransientLocal = info.transientLocalCount == info.publisherCount;
  if (allReliable && allTransientLocal) {
    profile.reliability = foxglove::Reliability::Reliable;
  }
  return profile;
}
#endif

void FoxgloveBridge::onClientConnect() {
  publishClientCount();
}

void FoxgloveBridge::onClientDisconnect() {
  publishClientCount();
}

void FoxgloveBridge::publishClientCount() {
  if (!_clientCountPublisher) {
    return;
  }
  const auto currentCount = _server->clientCount();
  auto msg = std_msgs::msg::UInt32{};
  msg.data = currentCount;
  _clientCountPublisher->publish(msg);
}

#ifdef FOXGLOVE_REMOTE_ACCESS
void FoxgloveBridge::gatewayConnectionStatusChanged(foxglove::RemoteAccessConnectionStatus status) {
  const char* label = "unknown";
  switch (status) {
    case foxglove::RemoteAccessConnectionStatus::Connecting:
      label = "connecting";
      break;
    case foxglove::RemoteAccessConnectionStatus::Connected:
      label = "connected";
      break;
    case foxglove::RemoteAccessConnectionStatus::ShuttingDown:
      label = "shutting down";
      break;
    case foxglove::RemoteAccessConnectionStatus::Shutdown:
      label = "shutdown";
      break;
  }
  RCLCPP_INFO(this->get_logger(), "Remote access gateway status: %s", label);
}

void FoxgloveBridge::gatewaySubscribe(uint32_t clientId,
                                      const foxglove::ChannelDescriptor& channel) {
  auto sinkId = _gateway->sinkId();
  if (!sinkId.has_value()) {
    RCLCPP_WARN(this->get_logger(),
                "Gateway: subscribe request for channel %lu (\"%s\") from client %u "
                "but gateway session has no sink ID (reconnecting?); "
                "cached transient_local messages will not be replayed",
                channel.id(), std::string(channel.topic()).c_str(), clientId);
  }
  RCLCPP_INFO(this->get_logger(),
              "Gateway: received subscribe request for channel %lu (\"%s\") from client %u",
              channel.id(), std::string(channel.topic()).c_str(), clientId);
  createOrIncrementSubscription(channel.id(), clientId, true, sinkId);
}

void FoxgloveBridge::gatewayUnsubscribe(uint32_t clientId,
                                        const foxglove::ChannelDescriptor& channel) {
  RCLCPP_INFO(this->get_logger(),
              "Gateway: received unsubscribe request for channel %lu (\"%s\") from client %u",
              channel.id(), std::string(channel.topic()).c_str(), clientId);
  removeOrDecrementSubscription(channel.id(), clientId, true);
}

void FoxgloveBridge::gatewayClientAdvertise(uint32_t clientId,
                                            const foxglove::ChannelDescriptor& channel) {
  std::lock_guard<std::mutex> lock(_clientAdvertisementsMutex);

  const ChannelId channelId = channel.id();
  const std::string topicName(channel.topic());
  const std::string encoding(channel.messageEncoding());

  ChannelAndClientId key = {channelId, clientId};
  if (_gatewayClientAdvertisedTopics.find(key) != _gatewayClientAdvertisedTopics.end()) {
    RCLCPP_WARN(this->get_logger(), "Gateway: client %u already advertised channel %lu (\"%s\")",
                clientId, channelId, topicName.c_str());
    return;
  }

  std::string topicType;
  const std::byte* schemaData = nullptr;
  size_t schemaLen = 0;
  auto schema = channel.schema();
  if (schema.has_value()) {
    topicType = schema->name;
    schemaData = schema->data;
    schemaLen = schema->data_len;
  }

  if (topicType.empty()) {
    RCLCPP_ERROR(this->get_logger(),
                 "Gateway: client %u advertised channel %lu (\"%s\") with empty schema name",
                 clientId, channelId, topicName.c_str());
    return;
  }

  try {
    auto ad = createClientPublisher(topicName, topicType, encoding, schemaData, schemaLen);
    RCLCPP_INFO(this->get_logger(),
                "Gateway: client %u is advertising channel %lu \"%s\" (%s) with encoding \"%s\"",
                clientId, channelId, topicName.c_str(), topicType.c_str(), encoding.c_str());
    _gatewayClientAdvertisedTopics.emplace(key, std::move(ad));
  } catch (const std::exception& ex) {
    RCLCPP_ERROR(this->get_logger(),
                 "Gateway: failed to create publisher for client %u channel %lu (\"%s\"): %s",
                 clientId, channelId, topicName.c_str(), ex.what());
  }
}

void FoxgloveBridge::gatewayClientUnadvertise(uint32_t clientId,
                                              const foxglove::ChannelDescriptor& channel) {
  std::lock_guard<std::mutex> lock(_clientAdvertisementsMutex);

  const ChannelId channelId = channel.id();
  ChannelAndClientId key = {channelId, clientId};

  auto it = _gatewayClientAdvertisedTopics.find(key);
  if (it == _gatewayClientAdvertisedTopics.end()) {
    RCLCPP_WARN(this->get_logger(), "Gateway: client %u unadvertised unknown channel %lu (\"%s\")",
                clientId, channelId, std::string(channel.topic()).c_str());
    return;
  }

  RCLCPP_INFO(this->get_logger(),
              "Gateway: client %u is no longer advertising channel %lu (\"%s\")", clientId,
              channelId, it->second.topicName.c_str());
  _gatewayClientAdvertisedTopics.erase(it);

  if (!_shuttingDown && rclcpp::ok()) {
    // Create a timer that immediately goes out of scope (so it never fires) which will trigger
    // the previously destroyed publisher to be cleaned up. This is a workaround for
    // https://github.com/ros2/rclcpp/issues/2146
    this->create_wall_timer(1s, []() {});
  }
}

void FoxgloveBridge::gatewayClientMessage(uint32_t clientId,
                                          const foxglove::ChannelDescriptor& channel,
                                          const std::byte* data, size_t dataLen) {
  const ChannelId channelId = channel.id();
  ClientAdvertisement ad;
  {
    ChannelAndClientId key = {channelId, clientId};
    std::lock_guard<std::mutex> lock(_clientAdvertisementsMutex);

    auto it = _gatewayClientAdvertisedTopics.find(key);
    if (it == _gatewayClientAdvertisedTopics.end()) {
      RCLCPP_ERROR(this->get_logger(),
                   "Gateway: dropping message from client %u for unknown channel %lu", clientId,
                   channelId);
      return;
    }

    ad = it->second;
  }

  try {
    publishClientData(ad, data, dataLen);
  } catch (const std::exception& ex) {
    RCLCPP_ERROR(this->get_logger(), "Gateway: dropping message from client %u for channel %lu: %s",
                 clientId, channelId, ex.what());
  }
}
#endif

}  // namespace foxglove_bridge

#include <rclcpp_components/register_node_macro.hpp>

// Register the component with class_loader.
// This acts as a sort of entry point, allowing the component to be discoverable when its library
// is being loaded into a running process.
RCLCPP_COMPONENTS_REGISTER_NODE(foxglove_bridge::FoxgloveBridge)
