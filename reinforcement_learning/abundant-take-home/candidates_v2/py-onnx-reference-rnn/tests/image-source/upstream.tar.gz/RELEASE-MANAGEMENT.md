<!--
Copyright (c) ONNX Project Contributors

SPDX-License-Identifier: Apache-2.0
-->

# ONNX release management

This describes the process by which versions of ONNX are officially released to the public.

Release Cadence
---------------

Branch cuts for a new release are planned every 3 months. However, the times can be changed as required.

| Minor Version | Release branch cut | Release date | First patch release date |
| --- | --- | --- | --- |
| 1.17.0 | XYZ | XYZ | Not planned |
| 1.18.0 | Mar 2025 | May 2025 | Not planned |
| 1.19.0 | 31. July 2025 | 27. August 2025 | 9. October 2025 |
| 1.20.0  | 31. October 2025 | November 2025 | January 2026 |
| 1.21.0  | 25. February 2026 | 28. March 2026 | - |
| 1.22.0 | 1. June 2026 | 15. June 2026 | - |
| 1.23.0 (tbd) | 1. September 2026 | 14. September 2026 | tbd |
| 1.24.0 (tbd) | 1. December 2026 | 14. December 2026 | tbd |
| 1.25.0 (tbd) | 1. February 2027 | 28. February 2027 | tbd |

## Long-Term Support (LTS)

ONNX does not currently maintain LTS branches. Each minor release is superseded by the next; only the latest release receives ongoing attention. If your environment cannot upgrade and you need a backported security or bug fix, please
[open an issue](https://github.com/onnx/onnx/issues/new) describing your situation — we will assess feasibility on a case-by-case basis. Community contributions for backport PRs are welcome and will be reviewed.

Release Compatibility Matrix
----------------------------

*Support for a Python version that went eol will be discontinued in the following ONNX release.*
*ONNX does NOT follow https://scientific-python.org/specs/spec-0000/ or https://protobuf.dev/support/version-support/*

Changes are discussed in the community. Please do not hesitate to contact us if you have any requests.
Planned changes for future releases as listed in the table below are subject to change.

|ONNX version	| Python wheels | C++ | Min CMake Version | Min Protobuf | manylinux |
| --- | --- | --- | --- | --- | --- |
| 1.10 | 3.6-3.9 | 11 | 3.1 | --- | manylinux2010 |
| 1.11 | 3.6-3.9 | 11 | 3.1 | 3.12.2 | manylinux2010 |
| 1.12 | 3.7-3.10 | 11 | 3.1 | 3.12.2 | manylinux2014 |
| 1.13 | 3.7-3.11 | 11 | 3.1 | 3.20.2 | manylinux2014 |
| 1.14 | 3.7-3.11 | 11 | 3.1 | 3.20.2 | manylinux2014 |
| 1.15 | 3.8-3.11 | 14 | 3.1 | 3.20.2 | manylinux2014 |
| 1.16 | 3.8-3.12 | 17 | 3.1 | 3.20.2 | manylinux2014 |
| 1.17 | 3.8-3.12 | 17 | 3.14 | 3.20.2 | manylinux2014 |
| 1.18 | 3.9-3.13, 3.13t (win, mac) | 17 | 3.18 | v25.1 | manylinux2014 |
| 1.19 | 3.9-3.13, 3.13t (win, mac, linux) | 17 | 3.24 | v25.1 | manylinux2014 |
| 1.19.1 | 3.9-3.13, 3.13t (win, mac, linux) | 17 | 3.24 | v25.1 | manylinux2014 |
| 1.20 | 3.10-3.13, 3.13t (win, mac, linux), 3.14 (mac) | 17 | 3.26 | v25.1 | manylinux_2_28 |
| 1.21 | 3.10-3.13, 3.13t, 3.14, 3.14t | 17 | 3.26 | v25.1 | manylinux_2_28 |
| 1.22 | 3.10, 3.11, 3.12-abi3, 3.14 (win, mac, linux), 3.14 pyodide | 17 | 3.24 | v25.1 | manylinux_2_28 |
| *1.23* | | | | | |


Releases
--------

Releases are versioned according to [ONNX Versioning](docs/Versioning.md). This describes IR and operator versioning policies, as well as propose how models themselves should be versioned.

On a regular basis, new versions of ONNX are published, representing the aggregate of changes in the IR and operator sets. Such releases use semantic versioning to describe the progression of the standard.

The GitHub repo for ONNX provides release branches where the project is stabilized as per the process described here. Release notes are used to communicate the stability and status of a release. The main branch will be used to continue work for subsequent releases.

Major, minor and patch releases will have branch names and version numbers reflecting the nature of the change as per semantic versioning definitions.

Workflow
--------

The following workflow describes the steps taken to release an update of ONNX,
and can be undertaken regardless of whether a major, minor or patch release is
to be produced.

- The trigger for the workflow will typically be a time-based trigger based on
  elapsed time (say every three months).

- The release manager will announce the intent of the process (to produce
  major, minor or patch update) and the overall timeline (documented in our
  wiki: [example](https://github.com/onnx/onnx/wiki/Logistics-for-ONNX-Release-1.19.0).
  A release branch is created with the name rel-major#.minor#(.patch#), and any version
  references in build scripts or version checks are updated.

- The release manager announces the initial commit for testing. The first
  period lasts two weeks; any regressions found should be fixed, typically via
  the main branch. Incomplete features should be done or excised during this
  period. A distribution can be made available with an -RC1 suffix.

- The release manager announces a second round of testing (unless it's only a
  patch update with no regressions found). Only critical bugs are fixed at
  this point, or those introduced by patches from the first week. A third
  week may be introduced at the release manager's discretion if significant
  fixes need to be taken. Distributions with -RCn suffixes can be made
  available if convenient.

- Release notes are updated with final changes, and a file with sources is
  provided along with a release on the GitHub project page.

Testing
-------

The release process really consists of communicating, testing to establish a
known state of the project, and distributing files. This section deals with
the second task.

At the very least, the tests that are part of the /test folder should be run
under a variety of configurations. Issues fixed should ensure coverage in this
suite to avoid regressions.

Send a Pull Request for updates to this section to include a configuration you
can help test if you care about one that's missing.

The community is encouraged to perform additional testing during the test
periods. Bugs and issues should be filed in the ONNX GitHub repo.

# ONNX Weekly Builds on PyPI

In addition to stable releases, we publish **weekly development builds** to a separate PyPI package: [`onnx-weekly`](https://pypi.org/project/onnx-weekly/).

## Why a Separate Package?

- **Avoid accidental installs:** Pre-release versions can be installed unintentionally; `onnx-weekly` ensures stable users are unaffected.
- **Enable safe testing:** Try upcoming features without impacting stable installs. Both packages can coexist.
- **Simplify automation:** Weekly builds are pushed automatically from `main` without polluting the main release history.

## Installation

```bash
pip install onnx-weekly
