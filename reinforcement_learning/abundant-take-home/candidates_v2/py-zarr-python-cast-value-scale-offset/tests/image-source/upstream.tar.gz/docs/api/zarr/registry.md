---
title: registry
---

::: zarr.registry