---
title: codecs
---

::: zarr.codecs
