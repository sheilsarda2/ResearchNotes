---
title: dtype
---

::: zarr.dtype
