## Stateful

::: zarr.testing.stateful
