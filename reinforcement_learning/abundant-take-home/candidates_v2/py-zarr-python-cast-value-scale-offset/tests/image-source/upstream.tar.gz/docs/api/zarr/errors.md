---
title: errors
---

::: zarr.errors