## Buffer

::: zarr.testing.buffer
