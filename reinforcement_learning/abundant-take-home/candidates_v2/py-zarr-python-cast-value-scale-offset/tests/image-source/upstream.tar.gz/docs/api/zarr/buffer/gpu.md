::: zarr.buffer.gpu
