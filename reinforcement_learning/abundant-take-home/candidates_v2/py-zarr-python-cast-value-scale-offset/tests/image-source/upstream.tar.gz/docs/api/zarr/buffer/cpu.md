::: zarr.buffer.cpu
