---
title: config
---

::: zarr.config
