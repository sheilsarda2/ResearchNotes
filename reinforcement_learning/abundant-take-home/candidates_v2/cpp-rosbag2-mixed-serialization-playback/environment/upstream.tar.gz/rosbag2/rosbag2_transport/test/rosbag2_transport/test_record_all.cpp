// Copyright 2018, Bosch Software Innovations GmbH.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <gmock/gmock.h>

#include <chrono>
#include <memory>
#include <string>
#include <utility>

#include "test_msgs/msg/arrays.hpp"
#include "test_msgs/msg/basic_types.hpp"
#include "test_msgs/message_fixtures.hpp"
#include "test_msgs/srv/basic_types.hpp"
#include "test_msgs/action/fibonacci.hpp"

#include "rosbag2_test_common/action_client_manager.hpp"
#include "rosbag2_test_common/client_manager.hpp"
#include "rosbag2_test_common/publication_manager.hpp"
#include "rosbag2_test_common/wait_for.hpp"

#include "rosbag2_transport/recorder.hpp"
#include "rosbag2_transport/recorder_event_notifier.hpp"

#include "mock_recorder.hpp"
#include "record_integration_fixture.hpp"

using namespace std::chrono_literals;  // NOLINT
using namespace rosbag2_transport;  // NOLINT

TEST_F(RecordIntegrationTestFixture, published_messages_from_multiple_topics_are_recorded)
{
  auto array_message = get_messages_arrays()[0];
  array_message->float32_values = {{40.0f, 2.0f, 0.0f}};
  array_message->bool_values = {{true, false, true}};
  std::string array_topic = "/array_topic";

  auto string_message = get_messages_strings()[0];
  string_message->string_value = "Hello World";
  std::string string_topic = "/string_topic";

  rosbag2_test_common::PublicationManager pub_manager;
  pub_manager.setup_publisher(array_topic, array_message, 2);
  pub_manager.setup_publisher(string_topic, string_message, 2);

  rosbag2_transport::RecordOptions record_options =
  {
    true, false, false, false, {}, {}, {}, {},
    {
      "/rosout",
      RecorderEventNotifier::get_default_write_split_topic_name(),
      RecorderEventNotifier::get_default_messages_lost_topic_name(),
    },
    {}, {}, {}, {}, {}, "rmw_format", 100ms
  };
  auto recorder = std::make_shared<rosbag2_transport::Recorder>(
    std::move(writer_), storage_options_, record_options);
  recorder->record();

  start_async_spin(recorder);
  auto cleanup_process_handle = rcpputils::make_scope_exit([&]() {stop_spinning();});

  ASSERT_TRUE(pub_manager.wait_for_matched(array_topic.c_str()));
  ASSERT_TRUE(pub_manager.wait_for_matched(string_topic.c_str()));

  pub_manager.run_publishers();

  auto & writer = recorder->get_writer_handle();
  auto & mock_writer = dynamic_cast<MockSequentialWriter &>(writer.get_implementation_handle());

  constexpr size_t expected_messages = 4;
  auto ret = rosbag2_test_common::wait_until_condition(
    [ =, &mock_writer]() {
      return mock_writer.get_number_of_recorded_messages() >= expected_messages;
    },
    std::chrono::seconds(5));
  EXPECT_TRUE(ret) << "failed to capture expected messages in time";
  auto recorded_messages = mock_writer.get_messages();
  EXPECT_EQ(recorded_messages.size(), expected_messages);

  auto string_messages = filter_messages<test_msgs::msg::Strings>(
    recorded_messages, string_topic);
  auto array_messages = filter_messages<test_msgs::msg::Arrays>(
    recorded_messages, array_topic);
  ASSERT_THAT(string_messages, SizeIs(2));
  ASSERT_THAT(array_messages, SizeIs(2));
  EXPECT_THAT(string_messages[0]->string_value, Eq("Hello World"));
  EXPECT_THAT(array_messages[0]->bool_values, ElementsAre(true, false, true));
  EXPECT_THAT(array_messages[0]->float32_values, ElementsAre(40.0f, 2.0f, 0.0f));
}

TEST_F(RecordIntegrationTestFixture, published_messages_from_multiple_services_are_recorded)
{
  auto client_manager_1 =
    std::make_shared<rosbag2_test_common::ClientManager<test_msgs::srv::BasicTypes>>(
    "test_service_1");

  auto client_manager_2 =
    std::make_shared<rosbag2_test_common::ClientManager<test_msgs::srv::BasicTypes>>(
    "test_service_2");

  rosbag2_transport::RecordOptions record_options =
  {false, true, false, false, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, "rmw_format", 100ms};
  auto recorder = std::make_shared<MockRecorder>(
    std::move(writer_), storage_options_, record_options);
  recorder->record();

  start_async_spin(recorder);
  auto cleanup_process_handle = rcpputils::make_scope_exit([&]() {stop_spinning();});

  ASSERT_TRUE(client_manager_1->wait_for_service_to_be_ready());
  ASSERT_TRUE(client_manager_2->wait_for_service_to_be_ready());

  // At this point, we expect that the services /test_service_1 and /test_service_2, along with
  // the event topics /test_service_1/_service_event and /test_service_2/_service_event are
  // available to be recorded.  However, wait_for_service_to_be_ready() only checks the services,
  // not the event topics, so ask the recorder to make sure it has successfully subscribed to all.
  ASSERT_TRUE(recorder->wait_for_topic_to_be_discovered("/test_service_1/_service_event"));
  ASSERT_TRUE(recorder->wait_for_topic_to_be_discovered("/test_service_2/_service_event"));

  // By default, only client introspection is enabled.
  // For one request, service event topic gets 2 messages.
  ASSERT_TRUE(client_manager_1->send_request());
  ASSERT_TRUE(client_manager_2->send_request());

  auto & writer = recorder->get_writer_handle();
  auto & mock_writer = dynamic_cast<MockSequentialWriter &>(writer.get_implementation_handle());

  constexpr size_t expected_messages = 4;
  auto ret = rosbag2_test_common::wait_until_condition(
    [ =, &mock_writer]() {
      return mock_writer.get_number_of_recorded_messages() >= expected_messages;
    },
    std::chrono::seconds(5));
  EXPECT_TRUE(ret) << "failed to capture expected messages in time";
  auto recorded_messages = mock_writer.get_messages();
  EXPECT_EQ(recorded_messages.size(), expected_messages);
}

TEST_F(RecordIntegrationTestFixture, published_messages_from_multiple_actions_are_recorded)
{
  auto action_client_manager_1 =
    std::make_shared<rosbag2_test_common::ActionClientManager<test_msgs::action::Fibonacci>>(
    "test_action_1");

  auto action_client_manager_2 =
    std::make_shared<rosbag2_test_common::ActionClientManager<test_msgs::action::Fibonacci>>(
    "test_action_2");

  rosbag2_transport::RecordOptions record_options =
  {false, false, true, false, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, "rmw_format", 100ms};
  auto recorder = std::make_shared<MockRecorder>(
    std::move(writer_), storage_options_, record_options);
  recorder->record();

  start_async_spin(recorder);
  auto cleanup_process_handle = rcpputils::make_scope_exit([&]() {stop_spinning();});

  ASSERT_TRUE(action_client_manager_1->wait_for_action_server_to_be_ready());
  ASSERT_TRUE(action_client_manager_2->wait_for_action_server_to_be_ready());

  // Ensure that the introspection service event topic already exists.
  ASSERT_TRUE(recorder->wait_for_topic_to_be_discovered(
    "/test_action_1/_action/get_result/_service_event"));
  ASSERT_TRUE(recorder->wait_for_topic_to_be_discovered(
    "/test_action_2/_action/get_result/_service_event"));

  ASSERT_TRUE(recorder->wait_for_topic_to_be_discovered(
    "/test_action_1/_action/send_goal/_service_event"));
  ASSERT_TRUE(recorder->wait_for_topic_to_be_discovered(
    "/test_action_2/_action/send_goal/_service_event"));

  ASSERT_TRUE(action_client_manager_1->send_goal());
  ASSERT_TRUE(action_client_manager_2->send_goal());

  auto & writer = recorder->get_writer_handle();
  auto & mock_writer = dynamic_cast<MockSequentialWriter &>(writer.get_implementation_handle());

  // For one action, 2 send_goal msgs, 2 feedback msgs, 2 status msgs, 2 get_result msgs
  constexpr size_t expected_messages = 16;
  auto ret = rosbag2_test_common::wait_until_condition(
    [ =, &mock_writer]() {
      return mock_writer.get_number_of_recorded_messages() >= expected_messages;
    },
    std::chrono::seconds(5));
  EXPECT_TRUE(ret) << "failed to capture expected messages in time";
  auto recorded_messages = mock_writer.get_messages();
  EXPECT_EQ(recorded_messages.size(), expected_messages);
  if (!ret) {
    std::cout << "Recorded messages: " << std::endl;
    for (const auto & message : recorded_messages) {
      std::cout << message->topic_name << std::endl;
    }
  }
}

TEST_F(RecordIntegrationTestFixture, published_messages_from_topic_service_action_are_recorded)
{
  auto client_manager_1 =
    std::make_shared<rosbag2_test_common::ClientManager<test_msgs::srv::BasicTypes>>(
    "test_service");

  auto action_manager_1 =
    std::make_shared<rosbag2_test_common::ActionClientManager<test_msgs::action::Fibonacci>>(
      "test_action_1");

  auto string_message = get_messages_strings()[0];
  string_message->string_value = "Hello World";
  std::string string_topic = "/string_topic";
  rosbag2_test_common::PublicationManager pub_manager;
  pub_manager.setup_publisher(string_topic, string_message, 1);

  rosbag2_transport::RecordOptions record_options =
  {
    true, true, true, false, {}, {}, {}, {},
    {
      "/rosout",
      RecorderEventNotifier::get_default_write_split_topic_name(),
      RecorderEventNotifier::get_default_messages_lost_topic_name(),
    },
    {}, {}, {}, {}, {}, "rmw_format", 100ms
  };
  auto recorder = std::make_shared<MockRecorder>(
    std::move(writer_), storage_options_, record_options);
  recorder->record();

  start_async_spin(recorder);
  auto cleanup_process_handle = rcpputils::make_scope_exit([&]() {stop_spinning();});

  ASSERT_TRUE(pub_manager.wait_for_matched(string_topic.c_str()));

  ASSERT_TRUE(client_manager_1->wait_for_service_to_be_ready());

  ASSERT_TRUE(action_manager_1->wait_for_action_server_to_be_ready());

  // At this point, we expect that the service /test_service_1, along with the topic /string_topic,
  // along with the event topic /test_service_1, along with the split topic /events/write_split are
  // available to be recorded.  However, wait_for_matched() and wait_for_service_to_be_ready() only
  // check on the service and the topic, not the event or the split topic, so ask the recorder to
  // make sure it has successfully subscribed to all.
  ASSERT_TRUE(recorder->wait_for_topic_to_be_discovered("/test_service/_service_event"));

  // Ensure that the introspection service event topic already exists.
  ASSERT_TRUE(recorder->wait_for_topic_to_be_discovered(
    "/test_action_1/_action/get_result/_service_event"));

  pub_manager.run_publishers();

  // By default, only client introspection is enabled.
  // For one request, service event topic get 2 messages.
  ASSERT_TRUE(client_manager_1->send_request());

  // For one action, 2 send_goal msgs, 2 feedback msgs, 2 status msgs, 2 get_result msgs
  ASSERT_TRUE(action_manager_1->send_goal());

  auto & writer = recorder->get_writer_handle();
  auto & mock_writer = dynamic_cast<MockSequentialWriter &>(writer.get_implementation_handle());

  constexpr size_t expected_messages = 1 + 2 + 8;
  auto ret = rosbag2_test_common::wait_until_condition(
    [ =, &mock_writer]() {
      return mock_writer.get_number_of_recorded_messages() >= expected_messages;
    },
    std::chrono::seconds(5));
  EXPECT_TRUE(ret) << "failed to capture expected messages in time";
  auto recorded_messages = mock_writer.get_messages();
  EXPECT_EQ(recorded_messages.size(), expected_messages);
}

TEST_F(RecordIntegrationTestFixture, cancel_event_messages_from_action_are_recorded)
{
  auto action_manager_1 =
    std::make_shared<rosbag2_test_common::ActionClientManager<test_msgs::action::Fibonacci>>(
      "test_action_1", 2s);

  rosbag2_transport::RecordOptions record_options =
  {
    false, false, true, false, {}, {}, {}, {},
    {
      "/rosout",
      RecorderEventNotifier::get_default_write_split_topic_name(),
      RecorderEventNotifier::get_default_messages_lost_topic_name(),
    },
    {}, {}, {}, {}, {}, "rmw_format", 100ms
  };
  auto recorder = std::make_shared<MockRecorder>(
    std::move(writer_), storage_options_, record_options);
  recorder->record();

  start_async_spin(recorder);
  auto cleanup_process_handle = rcpputils::make_scope_exit([&]() {stop_spinning();});

  ASSERT_TRUE(action_manager_1->wait_for_action_server_to_be_ready());

  // Ensure that the introspection service event topic already exists.
  ASSERT_TRUE(recorder->wait_for_topic_to_be_discovered(
    "/test_action_1/_action/cancel_goal/_service_event"));

  ASSERT_TRUE(action_manager_1->send_goal(true));

  auto & writer = recorder->get_writer_handle();
  auto & mock_writer = dynamic_cast<MockSequentialWriter &>(writer.get_implementation_handle());

  // 2 send_goal msgs, 2 cancel goal msgs , 2 status msgs, 2 get_result msgs
  // feedback msgs (Not sure)
  constexpr size_t expected_messages = 8;
  auto ret = rosbag2_test_common::wait_until_condition(
    [ =, &mock_writer]() {
      return mock_writer.get_number_of_recorded_messages() > expected_messages;
    },
    std::chrono::seconds(5));
  EXPECT_TRUE(ret) << "failed to capture expected messages in time";
  auto recorded_messages = mock_writer.get_messages();
  EXPECT_GT(recorded_messages.size(), expected_messages);

  // Confirm cancel goal messages are recorded
  size_t cancel_goal_msg_count = 0;
  for (auto & msg : recorded_messages) {
    if (msg->topic_name == "/test_action_1/_action/cancel_goal/_service_event") {
      cancel_goal_msg_count++;
    }
  }
  EXPECT_EQ(cancel_goal_msg_count, 2);
}
