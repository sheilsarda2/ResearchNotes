// Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <gmock/gmock.h>
#include <string>

#include "rosbag2_transport/record_options.hpp"

using namespace ::testing;  // NOLINT


TEST(record_options, test_yaml_serialization_deserialization)
{
 rosbag2_transport::RecordOptions original;
  original.all_topics = true;
  original.all_services = true;
  original.all_actions = true;
  original.is_discovery_disabled = true;
  original.topics = {"topic", "other_topic"};
  original.topic_types = {"type_a", "type_b"};
  original.services = {"service", "other_service"};
  original.actions = {"action", "other_action"};
  original.exclude_topics = {"exclude_topic1", "exclude_topic2"};
  original.exclude_topic_types = {"exclude_type1", "exclude_type2"};
  original.exclude_service_events = {"exclude_service1", "exclude_service2"};
  original.exclude_actions = {"exclude_action1", "exclude_action2"};
  original.rmw_serialization_format = "cdr";
  original.input_serialization_format = "cdr";
  original.output_serialization_format = "cdr";
  original.topic_polling_interval = std::chrono::milliseconds{200};
  original.regex = "[xyz]/topic";
  original.exclude_regex = "[x]/topic";
  original.node_prefix = "prefix";
  original.compression_mode = "stream";
  original.compression_format = "h264";
  original.compression_queue_size = 2;
  original.compression_threads = 123;
  original.compression_threads_priority = -10;
  original.topic_qos_profile_overrides.emplace("topic", rclcpp::QoS(10).transient_local());
  original.include_hidden_topics = true;
  original.include_unpublished_topics = true;
  original.ignore_leaf_topics = true;
  original.start_paused = true;
  original.use_sim_time = true;
  original.static_topics_uri = "/static/topics.yaml";
  original.disable_keyboard_controls = true;
  original.statistics_max_publishing_rate = 5.0f;
  original.repeat_transient_local_messages = {{"/map", 1}, {"/tf_static", 5}};
  original.repeat_all_transient_local_depth = 3;

  auto node = YAML::convert<rosbag2_transport::RecordOptions>::encode(original);

  std::stringstream serializer;
  serializer << node;
  auto reconstructed_node = YAML::Load(serializer.str());
  auto reconstructed = reconstructed_node.as<rosbag2_transport::RecordOptions>();

  #define CHECK(field) ASSERT_EQ(original.field, reconstructed.field)
  CHECK(all_topics);
  CHECK(all_services);
  CHECK(all_actions);
  CHECK(is_discovery_disabled);
  CHECK(topics);
  CHECK(topic_types);
  CHECK(services);
  CHECK(actions);
  CHECK(exclude_topics);
  CHECK(exclude_topic_types);
  CHECK(exclude_service_events);
  CHECK(exclude_actions);
  CHECK(rmw_serialization_format);
  CHECK(input_serialization_format);
  CHECK(output_serialization_format);
  CHECK(topic_polling_interval);
  CHECK(regex);
  CHECK(exclude_regex);
  CHECK(node_prefix);
  CHECK(compression_mode);
  CHECK(compression_format);
  CHECK(compression_queue_size);
  CHECK(compression_threads);
  CHECK(compression_threads_priority);
  CHECK(topic_qos_profile_overrides);
  CHECK(include_hidden_topics);
  CHECK(include_unpublished_topics);
  CHECK(ignore_leaf_topics);
  CHECK(start_paused);
  CHECK(use_sim_time);
  CHECK(static_topics_uri);
  CHECK(disable_keyboard_controls);
  CHECK(repeat_transient_local_messages);
  CHECK(repeat_all_transient_local_depth);
  #undef CHECK
  ASSERT_FLOAT_EQ(original.statistics_max_publishing_rate,
                  reconstructed.statistics_max_publishing_rate);
}

TEST(record_options, test_yaml_decode_for_all_and_exclude)
{
  std::string serialized_record_options =
    "  all: true\n"
    "  all_topics: false\n"
    "  topics: []\n"
    "  input_serialization_format: \"\"  # defaults to using the format of the input topic\n"
    "  output_serialization_format: \"\"  # defaults to using the format of the input topic\n"
    "  regex: \"[xyz]/topic\"\n"
    "  exclude: \"[x]/topic\"\n";

  YAML::Node loaded_node = YAML::Load(serialized_record_options);
  auto record_options = loaded_node.as<rosbag2_transport::RecordOptions>();
  ASSERT_EQ(record_options.all_topics, true);
  ASSERT_EQ(record_options.all_services, true);
  ASSERT_EQ(record_options.all_actions, true);
  ASSERT_EQ(record_options.regex, "[xyz]/topic");
  ASSERT_EQ(record_options.exclude_regex, "[x]/topic");
}

TEST(record_options, test_large_serialization)
{
  rosbag2_transport::RecordOptions options;
  options.topics = std::vector<std::string>(100000, "test_topic");
  options.services = std::vector<std::string>(100000, "test_service");

  ASSERT_NO_THROW({
    auto node = YAML::convert<rosbag2_transport::RecordOptions>().encode(options);
    std::stringstream serializer;
    serializer << node;
    auto recreated_node = YAML::Load(serializer.str()).as<rosbag2_transport::RecordOptions>();
    ASSERT_EQ(options.topics, recreated_node.topics);
    ASSERT_EQ(options.services, recreated_node.services);
  });
}
