use super::qtensor::*;
use super::*;
use burn_tensor::TensorData;
use burn_tensor::Tolerance;

#[test]
fn should_support_powf_ops() {
    let tensor = QTensor::<2>::int8([[0.0, 1.0, 2.0], [3.0, 4.0, 5.0]]);

    let output = tensor.powf_scalar(0.71);
    let expected = TensorData::from([[0.0, 1.0, 1.6358], [2.182, 2.6759, 3.1352]]);

    output
        .dequantize()
        .into_data()
        .assert_approx_eq::<FloatElem>(&expected, Tolerance::rel_abs(4e-2, 1e-2));
}

#[test]
fn should_support_neg_power() {
    let tensor = QTensor::<2>::int8([[1.0, 1.0, 2.0], [3.0, 4.0, 5.0]]);

    let output = tensor.powf_scalar(-0.33);
    let expected = TensorData::from([[1.0, 1.0, 0.79553646], [0.695905, 0.6328783, 0.58794934]]);

    output
        .dequantize()
        .into_data()
        .assert_approx_eq::<FloatElem>(&expected, Tolerance::rel_abs(4e-2, 1e-2));
}

#[test]
fn should_support_neg_values_with_even_power() {
    let tensor = QTensor::<2>::int8([[0.0, -1.0, -2.0], [-3.0, -4.0, -5.0]]);

    let output = tensor.powf_scalar(2.0);
    let expected = TensorData::from([[0., 1., 4.], [9., 16., 25.]]);

    output
        .dequantize()
        .into_data()
        .assert_approx_eq::<FloatElem>(&expected, Tolerance::rel_abs(4e-2, 1e-2));
}

#[test]
fn should_support_neg_values_with_odd_power() {
    let tensor = QTensor::<2>::int8([[0.0, -1.0, -2.0], [-3.0, -4.0, -4.0]]);

    let output = tensor.powf_scalar(3.0);
    let expected = TensorData::from([[0.0, -1.0, -8.0], [-27.0, -64.0, -64.0]]);

    output
        .dequantize()
        .into_data()
        .assert_approx_eq::<FloatElem>(&expected, Tolerance::rel_abs(4e-2, 1e-2));
}
