use super::*;
use burn_tensor::{DType, Distribution};

#[test]
fn test_full_precision() {
    let device = AutodiffDevice::new();
    let x1 = TestTensor::<2>::random([32, 32], Distribution::Default, &device).require_grad();
    let x2 = TestTensor::<2>::random([32, 32], Distribution::Default, &device).require_grad();
    let dtype = x1.dtype();

    let x3 = x1.clone().cast(DType::F32);
    let x4 = x2.clone().cast(DType::F32);

    let x5 = x3.matmul(x4);
    let x6 = x5.cast(dtype);
    let x7 = x6 * x1.clone() / x2.clone();

    let grads = x7.backward();

    let x1_grad = x1.grad(&grads);
    let x2_grad = x2.grad(&grads);

    assert!(x1_grad.is_some());
    assert!(x2_grad.is_some());
}

#[test]
fn one_hot_preserves_autodiff_device() {
    let device = AutodiffDevice::new();
    let targets = TestTensorInt::<1>::from_data([0, 1], &device);
    assert!(targets.device().is_autodiff());
    let one_hot = targets.one_hot::<2>(2).float();

    assert!(one_hot.device().is_autodiff());

    let logits = TestTensor::<2>::ones([2, 2], &device).require_grad();
    let loss = (logits.clone() * one_hot).sum();
    let grads = loss.backward();

    let logits_grad = logits.grad(&grads).expect("logits should have gradients");
    assert!(!logits_grad.device().is_autodiff());
}
