//
// Copyright (c) 2025 ZettaScale Technology
//
// This program and the accompanying materials are made available under the
// terms of the Eclipse Public License 2.0 which is available at
// http://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
// which is available at https://www.apache.org/licenses/LICENSE-2.0.
//
// SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
//
// Contributors:
//   ZettaScale Zenoh Team, <zenoh@zettascale.tech>
//

#[cfg(all(feature = "uring", target_os = "linux"))]
use std::os::fd::RawFd;
use std::{fmt, net::SocketAddr, sync::Arc, time::Duration};

use async_trait::async_trait;
use tokio_util::bytes::Bytes;
use zenoh_link_commons::{
    get_ip_interface_names,
    quic::{
        get_cert_chain_expiration, get_cert_common_name, get_quic_addr,
        unicast::{
            QuicAcceptorParams, QuicClient, QuicClientBuilder, QuicConnection, QuicLinkMaterial,
            QuicServer, QuicServerBuilder,
        },
    },
    tls::expiration::{LinkCertExpirationManager, LinkWithCertExpiration},
    LinkAuthId, LinkManagerUnicastTrait, LinkUnicast, LinkUnicastTrait, ListenersUnicastIP,
    NewLinkChannelSender,
};
use zenoh_protocol::{
    core::{EndPoint, Locator, Priority},
    transport::BatchSize,
};
#[cfg(all(feature = "uring", target_os = "linux"))]
use zenoh_result::bail;
use zenoh_result::{zerror, ZResult};

use super::{
    QUIC_DATAGRAM_ACCEPT_THROTTLE_TIME, QUIC_DATAGRAM_DEFAULT_MTU, QUIC_DATAGRAM_LOCATOR_PREFIX,
};

pub struct LinkUnicastQuicDatagram {
    connection: QuicConnection,
    src_addr: SocketAddr,
    src_locator: Locator,
    dst_locator: Locator,
    auth_identifier: LinkAuthId,
    mtu: BatchSize,
    expiration_manager: Option<LinkCertExpirationManager>,
}

impl LinkUnicastQuicDatagram {
    pub fn new(
        connection: QuicConnection,
        src_addr: SocketAddr,
        dst_locator: Locator,
        auth_identifier: LinkAuthId,
        locator_prefix: &str,
        expiration_manager: Option<LinkCertExpirationManager>,
    ) -> LinkUnicastQuicDatagram {
        // Zenoh Transport assumes calls to `LinkUnicastTrait::get_mtu` always yield the same
        // value. Therefore cache the initial MTU value (which is used in batch-size negotiation)
        let mtu = connection
            .max_datagram_size()
            .map(|mtu| mtu as BatchSize)
            .unwrap_or(*QUIC_DATAGRAM_DEFAULT_MTU);

        // Build the Quic object
        LinkUnicastQuicDatagram {
            connection,
            src_addr,
            src_locator: Locator::new(locator_prefix, src_addr.to_string(), "rel=0").unwrap(),
            dst_locator,
            auth_identifier,
            mtu,
            expiration_manager,
        }
    }

    async fn close(&self) -> ZResult<()> {
        tracing::trace!("Closing QUIC link: {}", self);
        self.connection.close();
        Ok(())
    }
}

#[async_trait]
impl LinkUnicastTrait for LinkUnicastQuicDatagram {
    async fn close(&self) -> ZResult<()> {
        if let Some(expiration_manager) = &self.expiration_manager {
            if !expiration_manager.set_closing() {
                // expiration_task is closing link, return its returned ZResult to Transport
                return expiration_manager.wait_for_expiration_task().await;
            }
            // cancel the expiration task and close link
            expiration_manager.cancel_expiration_task();
            let res = self.close().await;
            let _ = expiration_manager.wait_for_expiration_task().await;
            return res;
        }
        self.close().await
    }

    async fn write(&self, buffer: &[u8], _priority: Option<Priority>) -> ZResult<usize> {
        let amt = buffer.len();
        self.connection
            .send_datagram(Bytes::copy_from_slice(buffer))?;
        Ok(amt)
    }

    async fn write_all(&self, buffer: &[u8], _priority: Option<Priority>) -> ZResult<()> {
        self.connection
            .send_datagram(Bytes::copy_from_slice(buffer))?;
        Ok(())
    }

    async fn read(&self, buffer: &mut [u8], _priority: Option<Priority>) -> ZResult<usize> {
        let bytes = self.connection.read_datagram().await?;
        buffer
            .get_mut(..bytes.len())
            .map(|buffer| buffer.copy_from_slice(&bytes))
            .ok_or_else(|| {
                zerror!(
                    "QUIC datagram of len {} cannot fit in RX buffer of len {}",
                    bytes.len(),
                    buffer.len()
                )
            })?;
        Ok(bytes.len())
    }

    async fn read_exact(&self, _: &mut [u8], _priority: Option<Priority>) -> ZResult<()> {
        unreachable!()
    }

    #[inline(always)]
    fn get_src(&self) -> &Locator {
        &self.src_locator
    }

    #[inline(always)]
    fn get_dst(&self) -> &Locator {
        &self.dst_locator
    }

    #[inline(always)]
    fn get_mtu(&self) -> BatchSize {
        // Zenoh Transport assumes `LinkUnicastTrait::get_mtu` always yields the same value
        self.mtu
    }

    #[inline(always)]
    fn get_interface_names(&self) -> Vec<String> {
        get_ip_interface_names(&self.src_addr)
    }

    #[inline(always)]
    fn is_reliable(&self) -> bool {
        super::IS_RELIABLE
    }

    #[inline(always)]
    fn is_streamed(&self) -> bool {
        false
    }

    #[inline(always)]
    fn get_auth_id(&self) -> &LinkAuthId {
        &self.auth_identifier
    }

    #[cfg(all(feature = "uring", target_os = "linux"))]
    fn get_fd(&self) -> ZResult<RawFd> {
        //TODO: expose FD for quinn???
        bail!("Not supported");
    }
}

#[async_trait]
impl LinkWithCertExpiration for LinkUnicastQuicDatagram {
    async fn expire(&self) -> ZResult<()> {
        let expiration_manager = self
            .expiration_manager
            .as_ref()
            .expect("expiration_manager should be set");
        if expiration_manager.set_closing() {
            return self.close().await;
        }
        // Transport is already closing the link
        Ok(())
    }
}

impl Drop for LinkUnicastQuicDatagram {
    fn drop(&mut self) {
        self.connection.close();
    }
}

impl fmt::Display for LinkUnicastQuicDatagram {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{} => {}",
            self.src_addr,
            self.connection.remote_address()
        )?;
        Ok(())
    }
}

impl fmt::Debug for LinkUnicastQuicDatagram {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("QuicDatagram")
            .field("src", &self.src_addr)
            .field("dst", &self.connection.remote_address())
            .finish()
    }
}

#[derive(Debug)]
pub struct LinkManagerUnicastQuicDatagram {
    manager: NewLinkChannelSender,
    listeners: ListenersUnicastIP,
}

impl LinkManagerUnicastQuicDatagram {
    pub fn new(manager: NewLinkChannelSender) -> Self {
        Self {
            manager,
            listeners: ListenersUnicastIP::new(),
        }
    }
}

#[async_trait]
impl LinkManagerUnicastTrait for LinkManagerUnicastQuicDatagram {
    async fn new_link(&self, endpoint: EndPoint) -> ZResult<LinkUnicast> {
        let QuicClient {
            quic_conn,
            streams,
            src_addr,
            dst_addr,
            tls_close_link_on_expiration,
            is_mixed_rel: _,
        } = QuicClientBuilder::new(&endpoint).streamed(false).await?;

        debug_assert!(streams.is_none(), "Unreliable QUIC should not open streams");

        let auth_id = get_cert_common_name(&quic_conn)?;
        let certchain_expiration_time =
            get_cert_chain_expiration(&quic_conn)?.expect("server should have certificate chain");

        let link = Arc::<LinkUnicastQuicDatagram>::new_cyclic(|weak_link| {
            let mut expiration_manager = None;
            if tls_close_link_on_expiration {
                // setup expiration manager
                expiration_manager = Some(LinkCertExpirationManager::new(
                    weak_link.clone(),
                    src_addr,
                    dst_addr,
                    QUIC_DATAGRAM_LOCATOR_PREFIX,
                    certchain_expiration_time,
                ))
            }
            LinkUnicastQuicDatagram::new(
                quic_conn,
                src_addr,
                endpoint.into(),
                auth_id.into(),
                QUIC_DATAGRAM_LOCATOR_PREFIX,
                expiration_manager,
            )
        });

        Ok(LinkUnicast::from(link as Arc<dyn LinkUnicastTrait>))
    }

    async fn new_listener(&self, endpoint: EndPoint) -> ZResult<Locator> {
        let token = self.listeners.token.child_token();
        let acceptor_params = QuicAcceptorParams {
            token: token.clone(),
            manager: self.manager.clone(),
            throttle_time: Duration::from_micros(*QUIC_DATAGRAM_ACCEPT_THROTTLE_TIME),
            make_link: acceptor_callback,
        };

        let QuicServer {
            quic_acceptor,
            locator,
            local_addr,
        } = QuicServerBuilder::new(&endpoint, acceptor_params)
            .streamed(false)
            .await?;

        // Update the endpoint locator address
        let endpoint = EndPoint::new(
            locator.protocol(),
            locator.address(),
            locator.metadata(),
            endpoint.config(),
        )?;

        let task = async move { quic_acceptor.accept_task().await };
        // Initialize the QuicAcceptor
        self.listeners
            .add_listener(endpoint, local_addr, task, token)
            .await?;

        Ok(locator)
    }

    async fn del_listener(&self, endpoint: &EndPoint) -> ZResult<()> {
        let epaddr = endpoint.address();
        let addr = get_quic_addr(&epaddr).await?;
        self.listeners.del_listener(addr).await
    }

    async fn get_listeners(&self) -> Vec<EndPoint> {
        self.listeners.get_endpoints()
    }

    /// See [`zenoh_link_commons::ListenersUnicastIP::get_locators`].
    async fn get_locators(&self) -> Vec<Locator> {
        self.listeners.get_locators()
    }

    /// See [`zenoh_link_commons::ListenersUnicastIP::get_locators_noloopback`].
    async fn get_locators_noloopback(&self) -> Vec<Locator> {
        self.listeners.get_locators_noloopback()
    }
}

fn acceptor_callback(link_material: QuicLinkMaterial) -> ZResult<LinkUnicast> {
    let QuicLinkMaterial {
        quic_conn,
        src_addr,
        dst_addr,
        streams,
        tls_close_link_on_expiration,
        is_mixed_rel: _,
    } = link_material;

    debug_assert!(streams.is_none(), "Unreliable QUIC should not open streams");

    let dst_locator = Locator::new(QUIC_DATAGRAM_LOCATOR_PREFIX, dst_addr.to_string(), "")?;
    // Get Quic auth identifier
    let auth_id = get_cert_common_name(&quic_conn)?;

    // Get certificate chain expiration
    let mut maybe_expiration_time = None;
    if tls_close_link_on_expiration {
        match get_cert_chain_expiration(&quic_conn)? {
            exp @ Some(_) => maybe_expiration_time = exp,
            None => tracing::warn!(
                "Cannot monitor expiration for unreliable QUIC link {:?} => {:?} : client does not have certificates",
                src_addr,
                dst_addr,
            ),
        }
    }

    tracing::debug!(
        "Accepted unreliable QUIC connection on {:?}: {:?}. {:?}.",
        src_addr,
        dst_addr,
        auth_id
    );
    // Create the new link object
    let link = Arc::<LinkUnicastQuicDatagram>::new_cyclic(|weak_link| {
        let mut expiration_manager = None;
        if let Some(certchain_expiration_time) = maybe_expiration_time {
            // setup expiration manager
            expiration_manager = Some(LinkCertExpirationManager::new(
                weak_link.clone(),
                src_addr,
                dst_addr,
                QUIC_DATAGRAM_LOCATOR_PREFIX,
                certchain_expiration_time,
            ));
        }
        LinkUnicastQuicDatagram::new(
            quic_conn,
            src_addr,
            dst_locator,
            auth_id.into(),
            QUIC_DATAGRAM_LOCATOR_PREFIX,
            expiration_manager,
        )
    });
    Ok(LinkUnicast::from(link as Arc<dyn LinkUnicastTrait>))
}
