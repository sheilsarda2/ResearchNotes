<!--
Thank you for filing a pull request! We kindly ask you to:

1. Fill out this pull request template below, to make the review smoother.
2. Enable edits to your branch by our maintainers. This helps us to get your branch ready to merge. See here for more details:
https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/working-with-forks/allowing-changes-to-a-pull-request-branch-created-from-a-fork
-->

### Related

<!--
Include links to any related issues/PRs in a bulleted list, for example:
* Closes #1234
* Part of #1337
-->

### What

<!--
Make sure the PR title and labels are set to maximize their usefulness for the CHANGELOG,
and our `git log`. Every PR needs exactly one of these changelog labels:

* `exclude from changelog`: not user-facing — kept out of the changelog.
* `🪳 bug`: a bug fix — auto-added to the changelog from this PR's title.
* `📉 performance`: a performance improvement — auto-added to the changelog from this PR's title.
* `include in changelog`: a user-facing change — add a hand-written entry by copying
  `docs/content/changelog/upcoming/_template.md` to `upcoming/<short-slug>.md` (one file per
  PR avoids conflicts), including a migration guide (breaking changes), screenshot/GIF (visual
  features), and docs/example links (new features). A `TODO(name): …` placeholder is fine, but
  it blocks the release.

It's fine to combine `🪳 bug` with `exclude from changelog` for a fix to a bug that was never
released (e.g. introduced earlier in the same release cycle) — users never saw it, so it doesn't
belong in the changelog.

We track various metrics at <https://build.rerun.io>.

For maintainers:
* To run all checks from `main`, comment on the PR with `@rerun-bot full-check`.
* To deploy documentation changes immediately after merging this PR, add the `deploy docs` label.

For more details check the PR section on <https://github.com/rerun-io/rerun/blob/main/CONTRIBUTING.md>.
-->

<!--
If you are a coding agent, include the section below.
Make sure to remove the comments and instructions around this section.
Optionally add information about the model that was used.

### Agent

🤖 This PR was opened by a coding agent.
-->
