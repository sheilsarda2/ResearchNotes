use std::collections::{BTreeMap, BTreeSet};
use std::sync::Arc;

use ahash::HashMap;
use arrow::array::Array as _;
use itertools::Itertools as _;

use re_chunk::{Chunk, EntityPath, RowId};
use re_log::debug_assert;
use re_sdk_types::{Archetype as _, ArchetypeName, archetypes};

use crate::lineage::TrackedDirectChunkLineage;
use crate::lineage_dropping::LineageDroppingCtx;
use crate::store::ChunkIdSetPerTime;
use crate::{
    ChunkDeletionReason, ChunkDirectLineage, ChunkDirectLineageReport, ChunkId, ChunkStore,
    ChunkStoreChunkStats, ChunkStoreDiff, ChunkStoreDiffAddition, ChunkStoreError, ChunkStoreEvent,
    ChunkStoreResult,
};

/// Does this component belong to a transform archetype whose static data must be preserved in full?
///
/// [Sometime ago](https://github.com/rerun-io/rerun/pull/7518), we introduced a mechanism to auto-
/// delete static chunks that are "shadowed" by a newly inserted static chunk.
/// The reason for that is that in the basic data model, a latest-at query only ever returns the
/// most recent value for a given `(entity, component)`, so superseded static chunks can be safely
/// dropped, giving the benefit of "insta-GC" through logging with static data.
///
/// Named transform data is the exception: it is interpreted in full, not latest-at. A single entity
/// can carry many distinct frames across multiple static chunks (e.g. a `/tf_static` topic logging
/// transforms over its lifetime.
///
/// See RR-4887 for more info.
pub fn preserves_static_transforms(archetype_name: Option<ArchetypeName>) -> bool {
    // Note: these are "named transform" archetypes, aka those which have parent/child frame
    // references
    archetype_name.is_some_and(|archetype| {
        archetype == archetypes::Transform3D::name() || archetype == archetypes::Pinhole::name()
    })
}

// ---

impl ChunkStore {
    /// Inserts a [`Chunk`] in the store.
    ///
    /// Iff the store was modified, all registered subscribers will be notified and the
    /// resulting [`ChunkStoreEvent`] will be returned, or `None` otherwise.
    ///
    /// * Trying to insert an unsorted chunk ([`Chunk::is_sorted`]) will fail with an error.
    /// * Inserting a duplicated [`ChunkId`] will result in a no-op.
    /// * Inserting an empty [`Chunk`] will result in a no-op.
    pub fn insert_chunk(&mut self, chunk: &Arc<Chunk>) -> ChunkStoreResult<Vec<ChunkStoreEvent>> {
        if !self.is_root_chunk(&chunk.id()) {
            re_log::debug_warn_once!("Attempted to insert non-root chunk (this has no effect)");
            return Ok(vec![]);
        }

        let diffs = self.insert_chunk_impl(chunk, ChunkDirectLineageReport::Volatile)?;
        Ok(self.finalize_events(diffs))
    }

    fn insert_lineage_if_missing(&mut self, chunk_id: ChunkId, lineage: &ChunkDirectLineageReport) {
        let lineage: ChunkDirectLineage = lineage.into();

        let descends_from_manifest = match &lineage {
            ChunkDirectLineage::SplitFrom(chunk_id, _) => self.descends_from_manifest(chunk_id),
            ChunkDirectLineage::CompactedFrom(chunks) => {
                chunks.iter().any(|c| self.descends_from_manifest(c))
            }
            ChunkDirectLineage::RootFromManifest { .. } => true,
            ChunkDirectLineage::Volatile => false,
        };

        match self.chunks_lineage.entry(chunk_id) {
            std::collections::hash_map::Entry::Vacant(entry) => {
                entry.insert(TrackedDirectChunkLineage {
                    // Zero for now, add to this later.
                    ref_count: 0,
                    descends_from_manifest,
                    lineage: lineage.clone(),
                });

                for chunk_id in lineage.iter_referenced_chunks() {
                    let Some(l) = self.chunks_lineage.get_mut(chunk_id) else {
                        continue;
                    };

                    l.ref_count += 1;
                }
            }
            std::collections::hash_map::Entry::Occupied(entry) => {
                if cfg!(debug_assertions) {
                    if matches!(
                        entry.get().lineage,
                        ChunkDirectLineage::RootFromManifest { .. }
                    ) && matches!(lineage, ChunkDirectLineage::Volatile)
                    {
                        // If we've already indicated that this chunk is from the manifest, don't
                        // override with the default lineage `Volatile`.
                    } else {
                        re_log::debug_assert_eq!(
                            entry.get().lineage,
                            lineage,
                            "Lineage for a specific chunk id should never change ({chunk_id})",
                        );
                    }
                }
            }
        }
    }

    fn insert_chunk_impl(
        &mut self,
        chunk: &Arc<Chunk>,
        lineage: ChunkDirectLineageReport,
    ) -> ChunkStoreResult<Vec<ChunkStoreDiff>> {
        let mut all_diffs = Vec::new();

        if chunk.is_empty() {
            return Ok(all_diffs); // nothing to do
        }

        if chunk.components().is_empty() {
            // This can happen in 2 scenarios: A) a badly manually crafted chunk or B) an Indicator
            // chunk that went through the Sorbet migration process, and ended up with zero
            // component columns.
            //
            // When that happens, the election process in the compactor will get confused, and then not
            // only that weird empty Chunk will end up being stored, but it will also prevent the
            // election from making progress and therefore prevent Chunks that are in dire need of
            // compaction from being compacted.
            //
            // The solution is simple: just drop it.
            return Ok(all_diffs);
        }

        if let Some(prev_chunk) = self.physical_chunks_per_chunk_id.get(&chunk.id()) {
            if cfg!(debug_assertions) {
                if let Err(difference) = Chunk::ensure_similar(prev_chunk, chunk) {
                    re_log::error_once!(
                        "The chunk id {} was used twice for two _different_ chunks. Difference: {difference}",
                        chunk.id()
                    );
                } else {
                    re_log::warn_once!(
                        "[DEBUG] The same chunk was inserted twice (this has no effect)"
                    );
                }
            } else {
                re_log::debug_once!("The same chunk was inserted twice (this has no effect)");
            }

            // We assume that chunk IDs are unique, and so inserting the same chunk twice has no effect.
            return Ok(all_diffs);
        }

        if !chunk.is_row_ids_sorted() {
            return Err(ChunkStoreError::UnsortedChunk);
        }

        chunk.warn_if_out_of_order();

        re_tracing::profile_function!();

        {
            // Is there any chunk still actively loaded into the store that already contains the data
            // we're about to insert, by virtue of directly or indirectly descending from a compaction
            // that originally included that same data?
            // If so, we should not insert anything: the data is already there, in a more optimized form, even.

            let mut source_id = chunk.id();
            while let Some(chunk_id) = self.leaky_compactions.get(&source_id) {
                if self.physical_chunks_per_chunk_id.contains_key(chunk_id) {
                    return Ok(vec![]);
                }
                source_id = *chunk_id;
            }
        }

        if matches!(
            self.direct_lineage(&chunk.id()),
            Some(&ChunkDirectLineage::RootFromManifest { .. })
        ) {
            // If we reach here, then a chunk that was previously virtually inserted using `insert_rrd_manifest`
            // is about to be physically inserted for real.
            //
            // We don't know what's gonna to happen to this chunk during its insertion: it might be
            // added as-is, or be compacted into another existing chunk, or immediately be split into
            // smaller chunks.
            // If the chunk doesn't get inserted as-is, for whatever reason, then it will leave behind
            // it the ghost indexes from its original virtual insertion, which will lead downstream
            // systems to believe that some chunk is missing, forever, even though it's not: it just has
            // been inserted under a different name.
            //
            // The fix is simple: always unconditionally clean up the indexes when a virtual chunk
            // gets physically inserted.
            all_diffs.extend(
                self.remove_chunks_deep(
                    vec![chunk.clone()],
                    None,
                    ChunkDeletionReason::VirtualToPhysicalReplacement,
                )
                .into_iter()
                .map(Into::into),
            );
        }

        // If this chunk has already been inserted before, and yielded a bunch of smaller splits, then we
        // need to make sure that all these splits are now gone, so we don't end up with unnecessary
        // fragmented overlaps affecting performance for no good reason.
        if let Some(split_chunk_ids) = self.dangling_splits.remove(&chunk.id()) {
            all_diffs.extend(
                // There is no way for these splits to be ever useful again since their IDs are random
                // anyway. So deep removal it is.
                self.remove_chunks_deep(
                    split_chunk_ids
                        .into_iter()
                        .filter_map(|chunk_id| {
                            self.physical_chunks_per_chunk_id.get(&chunk_id).cloned()
                        })
                        .collect(),
                    None,
                    ChunkDeletionReason::DanglingSplitCleanup,
                )
                .into_iter()
                .map(Into::into),
            );
        }

        // "if missing" because we don't want to lose the RRD manifest lineage if there is one.
        self.insert_lineage_if_missing(chunk.id(), &lineage);

        // Splitting a static chunk just seems like a terrible idea in general.
        let chunk_is_static = chunk.is_static();

        // If we're coming in here from the recursive call caused by a split, then we shouldn't try splitting at all.
        //
        // Mathematically, this is not needed: since we already split as much as needed on the first-and-only
        // flattened split iteration, we will never split anything again.
        // On the other hand, the explicitness makes this much easier to understand, and prevents unfortunate
        // accidents when this code inevitably get refactored in the future.
        //
        // Also, splitting a static chunk just seems like a terrible idea in general.
        let chunk_descends_from_split = self.descends_from_a_split(&chunk.id());

        // We should never try and split a chunk issued from a compaction, it's just counter-productive.
        let chunk_descends_from_compaction = self.descends_from_a_compaction(&chunk.id());

        if !chunk_is_static && !chunk_descends_from_split && !chunk_descends_from_compaction {
            // Always perform the recursive splitting inline, so that we don't generate and send store
            // events that won't make any sense for downstream consumers, since these halfway chunks
            // never get exposed to the outside world in any way.
            let mut split_chunks: Vec<Arc<Chunk>> = Chunk::split_rows(
                chunk.clone(),
                &re_chunk::SplitRowsOptions {
                    chunk_max_bytes: self.config.chunk_max_bytes,
                    chunk_max_rows: self.config.chunk_max_rows,
                    chunk_max_rows_if_unsorted: self.config.chunk_max_rows_if_unsorted,
                },
            );
            loop {
                re_tracing::profile_scope!("compute-recursive-splits");

                let num_split_chunks = split_chunks.len();
                split_chunks = split_chunks
                    .into_iter()
                    .flat_map(|split_chunk| {
                        if self.descends_from_a_compaction(&split_chunk.id()) {
                            // Never split a chunk that descends from a direct or indirect compaction, ever.
                            vec![]
                        } else {
                            Chunk::split_rows(
                                split_chunk.clone(),
                                &re_chunk::SplitRowsOptions {
                                    chunk_max_bytes: self.config.chunk_max_bytes,
                                    chunk_max_rows: self.config.chunk_max_rows,
                                    chunk_max_rows_if_unsorted: self
                                        .config
                                        .chunk_max_rows_if_unsorted,
                                },
                            )
                        }
                    })
                    .collect_vec();

                if split_chunks.len() == num_split_chunks {
                    // There was nothing new to split, therefore: we're done.
                    break;
                }
            }
            if split_chunks.len() > 1 {
                re_tracing::profile_scope!("add-splits");

                // For a split, we keep track of our descendents so that we can accurately drop
                // dangling splits later on if the parent gets re-inserted.
                self.dangling_splits
                    .insert(chunk.id(), split_chunks.iter().map(|c| c.id()).collect());

                self.split_on_ingest.insert(chunk.id());

                for split_chunk in &split_chunks {
                    let siblings = split_chunks
                        .iter()
                        .filter(|c| c.id() != split_chunk.id())
                        .cloned()
                        .collect_vec();
                    let lineage = ChunkDirectLineageReport::SplitFrom(chunk.clone(), siblings);

                    let mut diffs = self.insert_chunk_impl(split_chunk, lineage)?;
                    for diff in &mut diffs {
                        // In case of a split, the unprocessed chunk should always match the parent
                        // chunk as specified in the `SplitFrom` lineage.
                        // By default this won't be the case due to how the recursion is implemented,
                        // so make sure to patch the data appropriately.
                        if let ChunkStoreDiff::Addition(add) = diff {
                            add.chunk_before_processing = chunk.clone();
                        }
                    }

                    all_diffs.extend(diffs);
                }

                return Ok(all_diffs);
            }
        }

        self.insert_id += 1;

        let chunk_before_processing = Arc::clone(chunk); // we'll need it to create the store event

        //TODO(RR-4887): we should NEVER delete chunks
        let (chunk_after_processing, diffs) = if chunk.is_static() {
            // Static data: make sure to keep the most recent chunk available for each component column.
            re_tracing::profile_scope!("static");

            let row_id_range_per_component = chunk.row_id_range_per_component();

            let mut overwritten_chunk_ids = HashMap::default();

            for (component, column) in chunk.components().iter() {
                let is_empty = column
                    .list_array
                    .nulls()
                    .is_some_and(|validity| validity.is_empty());
                if is_empty {
                    continue;
                }

                let Some((_row_id_min_for_component, row_id_max_for_component)) =
                    row_id_range_per_component.get(component)
                else {
                    continue;
                };

                let is_transform = preserves_static_transforms(column.descriptor.archetype);

                self.static_chunk_ids_per_entity
                    .entry(chunk.entity_path().clone())
                    .or_default()
                    .entry(*component)
                    .and_modify(|cur_chunk_id| {
                        // NOTE: When attempting to overwrite static data, the chunk with the most
                        // recent data within -- according to RowId -- wins.

                        let cur_row_id_max_for_component = self
                            .physical_chunks_per_chunk_id
                            .get(cur_chunk_id)
                            .map_or(RowId::ZERO, |chunk| {
                                chunk
                                    .row_id_range_per_component()
                                    .get(component)
                                    .map_or(RowId::ZERO, |(_, row_id_max)| *row_id_max)
                            });

                        if *row_id_max_for_component > cur_row_id_max_for_component {
                            // We are about to overwrite the existing chunk with the new one, at
                            // least for this one specific component.
                            // Keep track of the overwritten ChunkId: we'll need it further down in
                            // order to check whether that chunk is now dangling.

                            // NOTE: The chunks themselves are indexed using the smallest RowId in
                            // the chunk _as a whole_, as opposed to the smallest RowId of one
                            // specific component in that chunk.
                            let cur_row_id_min_for_chunk = self
                                .physical_chunks_per_chunk_id
                                .get(cur_chunk_id)
                                .and_then(|chunk| {
                                    chunk.row_id_range().map(|(row_id_min, _)| row_id_min)
                                });

                            if let Some(cur_row_id_min_for_chunk) = cur_row_id_min_for_chunk
                                && !is_transform
                            {
                                overwritten_chunk_ids
                                    .insert(*cur_chunk_id, cur_row_id_min_for_chunk);
                            }

                            *cur_chunk_id = chunk.id();
                        }
                    })
                    .or_insert_with(|| chunk.id());
            }

            self.static_chunks_stats += ChunkStoreChunkStats::from_chunk(chunk);

            let mut diffs = vec![ChunkStoreDiff::addition(
                chunk_before_processing, /* chunk_before_processing */
                chunk.clone(),           /* chunk_after_processing */
                lineage,                 /* lineage */
            )];

            // NOTE: Our chunks can only cover a single entity path at a time, therefore we know we
            // only have to check that one entity for complete overwrite.
            debug_assert!(
                self.static_chunk_ids_per_entity
                    .contains_key(chunk.entity_path()),
                "This condition cannot fail, we just want to avoid unwrapping",
            );
            if let Some(per_component) = self.static_chunk_ids_per_entity.get(chunk.entity_path()) {
                re_tracing::profile_scope!("static dangling checks");

                // At this point, we are in possession of a list of ChunkIds that were at least
                // _partially_ overwritten (i.e. some, but not necessarily all, of the components
                // that they used to provide the data for are now provided by another, newer chunk).
                //
                // To determine whether any of these chunks are actually fully overwritten, and
                // therefore dangling, we need to make sure there are no components left
                // referencing these ChunkIds whatsoever.
                //
                // Because our storage model guarantees that a single chunk cannot cover more than
                // one entity, this is actually pretty cheap to do, since we only have to loop over
                // all the components of a single entity.

                for (chunk_id, chunk_row_id_min) in overwritten_chunk_ids {
                    let has_been_fully_overwritten = !per_component
                        .values()
                        .any(|cur_chunk_id| *cur_chunk_id == chunk_id);

                    if has_been_fully_overwritten {
                        // The chunk is now dangling: remove it from all relevant indices, update
                        // the stats, and fire deletion events.

                        let chunk_id_removed = self
                            .physical_chunk_ids_per_min_row_id
                            .remove(&(chunk_row_id_min, chunk_id));
                        debug_assert!(chunk_id_removed);

                        let chunk_removed = self.physical_chunks_per_chunk_id.remove(&chunk_id);
                        debug_assert!(chunk_removed.is_some());

                        if let Some(chunk_removed) = chunk_removed {
                            Self::drop_lineage_reference(
                                &mut LineageDroppingCtx {
                                    chunks_lineage: &mut self.chunks_lineage,
                                    leaky_compactions: &mut self.leaky_compactions,
                                    split_on_ingest: &mut self.split_on_ingest,
                                    dangling_splits: &mut self.dangling_splits,
                                },
                                &chunk_id,
                            );

                            self.static_chunks_stats -=
                                ChunkStoreChunkStats::from_chunk(&chunk_removed);
                            diffs.push(ChunkStoreDiff::deletion(
                                chunk_removed,
                                ChunkDeletionReason::Overwrite,
                            ));
                        }
                    }
                }
            }

            (Arc::clone(chunk), diffs)
        } else {
            // Temporal data: just index the chunk on every dimension of interest.
            re_tracing::profile_scope!("temporal");

            let (elected_chunk, chunk_or_compacted) = {
                re_tracing::profile_scope!("election");

                let elected_chunk = self.find_and_elect_compaction_candidate(chunk);

                let chunk_or_compacted = if let Some(elected_chunk) = &elected_chunk {
                    let compacted = Chunk::concat_and_sort(elected_chunk, chunk)?;

                    re_log::trace!(
                        "compacted {} ({} rows) and {} ({} rows) together, resulting in {} ({} rows)",
                        chunk.id(),
                        re_format::format_uint(chunk.num_rows()),
                        elected_chunk.id(),
                        re_format::format_uint(elected_chunk.num_rows()),
                        compacted.id(),
                        re_format::format_uint(compacted.num_rows()),
                    );

                    Arc::new(compacted)
                } else {
                    Arc::clone(chunk)
                };

                (elected_chunk, chunk_or_compacted)
            };

            {
                re_tracing::profile_scope!("insertion (w/ component)");

                let temporal_chunk_ids_per_timeline = self
                    .temporal_chunk_ids_per_entity_per_component
                    .entry(chunk_or_compacted.entity_path().clone())
                    .or_default();

                // NOTE: We must make sure to use the time range of each specific component column
                // here, or we open ourselves to nasty edge cases.
                //
                // See the `latest_at_sparse_component_edge_case` test.
                for (timeline, time_range_per_component) in
                    chunk_or_compacted.time_range_per_component()
                {
                    let temporal_chunk_ids_per_component =
                        temporal_chunk_ids_per_timeline.entry(timeline).or_default();

                    for (component, time_range) in time_range_per_component {
                        let temporal_chunk_ids_per_time = temporal_chunk_ids_per_component
                            .entry(component)
                            .or_default();

                        // See `ChunkIdSetPerTime::max_interval_length`'s documentation.
                        temporal_chunk_ids_per_time.max_interval_length = u64::max(
                            temporal_chunk_ids_per_time.max_interval_length,
                            time_range.abs_length(),
                        );

                        temporal_chunk_ids_per_time
                            .per_start_time
                            .entry(time_range.min())
                            .or_default()
                            .insert(chunk_or_compacted.id());
                        temporal_chunk_ids_per_time
                            .per_end_time
                            .entry(time_range.max())
                            .or_default()
                            .insert(chunk_or_compacted.id());
                    }
                }
            }

            {
                re_tracing::profile_scope!("insertion (w/o component)");

                let temporal_chunk_ids_per_timeline = self
                    .temporal_chunk_ids_per_entity
                    .entry(chunk_or_compacted.entity_path().clone())
                    .or_default();

                for (timeline, time_column) in chunk_or_compacted.timelines() {
                    let temporal_chunk_ids_per_time = temporal_chunk_ids_per_timeline
                        .entry(*timeline)
                        .or_default();

                    let time_range = time_column.time_range();

                    // See `ChunkIdSetPerTime::max_interval_length`'s documentation.
                    temporal_chunk_ids_per_time.max_interval_length = u64::max(
                        temporal_chunk_ids_per_time.max_interval_length,
                        time_range.abs_length(),
                    );

                    temporal_chunk_ids_per_time
                        .per_start_time
                        .entry(time_range.min())
                        .or_default()
                        .insert(chunk_or_compacted.id());
                    temporal_chunk_ids_per_time
                        .per_end_time
                        .entry(time_range.max())
                        .or_default()
                        .insert(chunk_or_compacted.id());
                }
            }

            self.temporal_physical_chunks_stats +=
                ChunkStoreChunkStats::from_chunk(&chunk_or_compacted);

            let mut add = ChunkStoreDiffAddition {
                // NOTE: We are advertising only the non-compacted chunk as "added", i.e. only the new data.
                //
                // This makes sure that downstream subscribers only have to process what is new,
                // instead of needlessly reprocessing old rows that would appear to have been
                // removed and reinserted due to compaction.
                //
                // Subscribers will still be capable of tracking which chunks have been merged with which
                // by using the compaction report that we fill below.
                chunk_before_processing: Arc::clone(&chunk_before_processing),
                chunk_after_processing: chunk_or_compacted.clone(),
                direct_lineage: lineage, // lineage (might be patched below)
            };
            if let Some(elected_chunk) = &elected_chunk {
                // NOTE: The chunk that we've just added has been compacted already!
                //
                // We build `srcs` eagerly from the chunks we already have in hand, then wire up
                // `leaky_compactions` and the new compacted chunk's lineage entry *before* removing
                // the elected chunk. That way the elected chunk's `ref_count` is bumped by the new
                // compacted chunk's lineage, and the cascading cleanup inside `remove_chunks_deep`
                // sees a ref > 0 and leaves it (and the leaky_compactions entries that point to it)
                // alone.
                let srcs: BTreeMap<ChunkId, Arc<Chunk>> = [
                    (
                        chunk_before_processing.id(),
                        Arc::clone(&chunk_before_processing),
                    ),
                    (elected_chunk.id(), Arc::clone(elected_chunk)),
                ]
                .into_iter()
                .collect();

                for source_id in srcs.keys().copied() {
                    let found = self
                        .leaky_compactions
                        .insert(source_id, chunk_or_compacted.id())
                        .is_some();

                    #[expect(clippy::manual_assert)]
                    if cfg!(debug_assertions) && found {
                        let mut source_id = source_id;
                        while let Some(chunk_id) = self.leaky_compactions.get(&source_id) {
                            if self.physical_chunks_per_chunk_id.contains_key(chunk_id) {
                                panic!(
                                    "leaky compaction tracker should never get overwritten as long as one \
                                    or more direct or indirect compacted chunks still exist"
                                );
                            }
                            source_id = *chunk_id;
                        }
                    }
                }

                let direct_lineage = ChunkDirectLineageReport::CompactedFrom(srcs);
                self.insert_lineage_if_missing(chunk_or_compacted.id(), &direct_lineage);

                // NOTE: deep removal, we don't want a compacted chunk to linger on!
                self.remove_chunks_deep(
                    vec![elected_chunk.clone()],
                    None,
                    ChunkDeletionReason::Compaction,
                );

                add.direct_lineage = direct_lineage;
            }

            (chunk_or_compacted, vec![add.into()])
        };

        self.physical_chunks_per_chunk_id
            .insert(chunk_after_processing.id(), chunk_after_processing.clone());
        // Account for the physical reference. The matching decrement happens in
        // `remove_chunks_shallow` (via `drop_lineage_reference`).
        if let Some(l) = self.chunks_lineage.get_mut(&chunk_after_processing.id()) {
            l.ref_count += 1;
        }

        all_diffs.extend(diffs);

        // NOTE: ⚠️Make sure to recompute the Row ID range! The chunk might have been compacted
        // with another one, which might or might not have modified the range.
        if let Some(min_row_id) = chunk_after_processing.row_id_range().map(|(min, _)| min) {
            self.physical_chunk_ids_per_min_row_id
                .insert((min_row_id, chunk_after_processing.id()));
        }

        Ok(all_diffs)
    }

    /// Unconditionally drops all the data for a given `entity_path`.
    ///
    /// Returns the list of `Chunk`s that were dropped from the store in the form of [`ChunkStoreEvent`]s.
    ///
    /// This is _not_ recursive. The store is unaware of the entity hierarchy.
    pub fn drop_entity_path(&mut self, entity_path: &EntityPath) -> Vec<ChunkStoreEvent> {
        re_tracing::profile_function!(entity_path.to_string());

        self.gc_id += 1; // close enough

        let Self {
            id: _,
            config: _,
            schema,
            physical_chunks_per_chunk_id: chunks_per_chunk_id,
            chunks_lineage: _, // lineage metadata must never be dropped, regardless
            dangling_splits: _, // this counts as lineage metadata too
            split_on_ingest: _, // we only ever add to this
            leaky_compactions: _, // this counts as lineage metadata too
            physical_chunk_ids_per_min_row_id: chunk_ids_per_min_row_id,
            temporal_chunk_ids_per_entity_per_component,
            temporal_chunk_ids_per_entity,
            temporal_physical_chunks_stats,
            static_chunk_ids_per_entity,
            static_chunks_stats,
            queried_chunk_id_tracker: _,
            insert_id: _,
            gc_id: _,
            event_id: _,
        } = self;

        schema.drop_entity(entity_path);

        let dropped_static_chunks = {
            let dropped_static_chunk_ids: BTreeSet<_> = static_chunk_ids_per_entity
                .remove(entity_path)
                .unwrap_or_default()
                .into_values()
                .collect();

            for chunk_id in &dropped_static_chunk_ids {
                if let Some(min_row_id) = chunks_per_chunk_id
                    .get(chunk_id)
                    .and_then(|chunk| chunk.row_id_range().map(|(min, _)| min))
                {
                    chunk_ids_per_min_row_id.remove(&(min_row_id, *chunk_id));
                }
            }

            dropped_static_chunk_ids.into_iter()
        };

        let dropped_temporal_chunks = {
            temporal_chunk_ids_per_entity_per_component.remove(entity_path);

            let dropped_temporal_chunk_ids: BTreeSet<_> = temporal_chunk_ids_per_entity
                .remove(entity_path)
                .unwrap_or_default()
                .into_values()
                .flat_map(|temporal_chunk_ids_per_time| {
                    let ChunkIdSetPerTime {
                        max_interval_length: _,
                        per_start_time,
                        per_end_time: _, // same chunk IDs as above
                    } = temporal_chunk_ids_per_time;

                    per_start_time
                        .into_values()
                        .flat_map(|chunk_ids| chunk_ids.into_iter())
                })
                .collect();

            for chunk_id in &dropped_temporal_chunk_ids {
                if let Some(min_row_id) = chunks_per_chunk_id
                    .get(chunk_id)
                    .and_then(|chunk| chunk.row_id_range().map(|(min, _)| min))
                {
                    chunk_ids_per_min_row_id.remove(&(min_row_id, *chunk_id));
                }
            }

            dropped_temporal_chunk_ids.into_iter()
        };

        let dropped_static_chunks = dropped_static_chunks
            .filter_map(|chunk_id| chunks_per_chunk_id.remove(&chunk_id))
            .inspect(|chunk| {
                *static_chunks_stats -= ChunkStoreChunkStats::from_chunk(chunk);
            })
            // NOTE: gotta collect to release the mut ref on `chunks_per_chunk_id`.
            .collect_vec();

        let dropped_temporal_chunks = dropped_temporal_chunks
            .filter_map(|chunk_id| chunks_per_chunk_id.remove(&chunk_id))
            .inspect(|chunk| {
                *temporal_physical_chunks_stats -= ChunkStoreChunkStats::from_chunk(chunk);
            });

        let diffs: Vec<_> = std::iter::chain(dropped_static_chunks, dropped_temporal_chunks)
            .map(|chunk| ChunkStoreDiff::deletion(chunk, ChunkDeletionReason::ExplicitDrop))
            .collect();

        self.finalize_events(diffs)
    }
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;

    use re_chunk::{TimeInt, TimePoint, Timeline};
    use re_log_types::example_components::{MyColor, MyLabel, MyPoint, MyPoints};
    use re_log_types::{build_frame_nr, build_log_time};
    use similar_asserts::assert_eq;

    use crate::ChunkStoreConfig;

    use super::*;

    #[test]
    fn no_components() -> anyhow::Result<()> {
        re_log::setup_logging();
        let mut store = ChunkStore::new(
            re_log_types::StoreId::random(re_log_types::StoreKind::Recording, "test_app"),
            Default::default(),
        );

        {
            let entity_path = EntityPath::from("/nothing-at-all");
            let chunk = Chunk::builder(entity_path.clone()).build()?;
            let chunk = Arc::new(chunk);

            let events = store.insert_chunk(&chunk)?;
            assert!(events.is_empty());
        }
        {
            let entity_path = EntityPath::from("/static-row-no-components");
            let chunk = Chunk::builder(entity_path.clone())
                .with_component_batches(RowId::new(), TimePoint::STATIC, [])
                .build()?;
            let chunk = Arc::new(chunk);

            let events = store.insert_chunk(&chunk)?;
            assert!(events.is_empty());
        }

        let timepoint_log = build_log_time(TimeInt::new_temporal(10).into());
        let timepoint_frame = build_frame_nr(123);

        {
            let entity_path = EntityPath::from("/log-time-row-no-components");
            let chunk = Chunk::builder(entity_path.clone())
                .with_component_batches(RowId::new(), [timepoint_log], [])
                .build()?;
            let chunk = Arc::new(chunk);

            let events = store.insert_chunk(&chunk)?;
            assert!(events.is_empty());
        }
        {
            let entity_path = EntityPath::from("/frame-nr-row-no-components");
            let chunk = Chunk::builder(entity_path.clone())
                .with_component_batches(RowId::new(), [timepoint_frame], [])
                .build()?;
            let chunk = Arc::new(chunk);

            let events = store.insert_chunk(&chunk)?;
            assert!(events.is_empty());
        }
        {
            let entity_path = EntityPath::from("/both-log-frame-row-no-components");
            let chunk = Chunk::builder(entity_path.clone())
                .with_component_batches(RowId::new(), [timepoint_log, timepoint_frame], [])
                .build()?;
            let chunk = Arc::new(chunk);

            let events = store.insert_chunk(&chunk)?;
            assert!(events.is_empty());
        }

        Ok(())
    }

    #[test]
    fn static_overwrites() -> anyhow::Result<()> {
        re_log::setup_logging();

        let mut store = ChunkStore::new(
            re_log_types::StoreId::random(re_log_types::StoreKind::Recording, "test_app"),
            Default::default(),
        );

        let entity_path = EntityPath::from("this/that");

        let row_id1_1 = RowId::new();
        let row_id2_1 = RowId::new();
        let row_id2_2 = RowId::new();
        let row_id3_1 = RowId::new();

        let timepoint_static = TimePoint::STATIC;

        let points1 = &[MyPoint::new(1.0, 1.0)];
        let colors1 = &[MyColor::from_rgb(1, 1, 1)];
        let labels1 = &[MyLabel("111".to_owned())];

        let points2 = &[MyPoint::new(2.0, 2.0)];
        let colors2 = &[MyColor::from_rgb(2, 2, 2)];
        let labels2 = &[MyLabel("222".to_owned())];

        let chunk1 = Chunk::builder(entity_path.clone())
            .with_component_batches(
                row_id1_1,
                timepoint_static.clone(),
                [
                    (MyPoints::descriptor_points(), points1 as _),
                    (MyPoints::descriptor_colors(), colors1 as _),
                    (MyPoints::descriptor_labels(), labels1 as _),
                ],
            )
            .build()?;
        let chunk2 = Chunk::builder(entity_path.clone())
            .with_component_batches(
                row_id2_1,
                timepoint_static.clone(),
                [
                    (MyPoints::descriptor_points(), points2 as _),
                    (MyPoints::descriptor_colors(), colors2 as _),
                ],
            )
            .build()?;
        let chunk3 = Chunk::builder(entity_path.clone())
            .with_component_batches(
                row_id2_2,
                timepoint_static.clone(),
                [(MyPoints::descriptor_labels(), labels2 as _)],
            )
            .build()?;
        let chunk4 = Chunk::builder(entity_path.clone())
            .with_component_batches(row_id3_1, timepoint_static.clone(), [])
            .build()?;

        let chunk1 = Arc::new(chunk1);
        let chunk2 = Arc::new(chunk2);
        let chunk3 = Arc::new(chunk3);
        let chunk4 = Arc::new(chunk4);

        let events = store.insert_chunk(&chunk1)?;
        assert_eq!(events.len(), 2);
        assert_eq!(events[0].delta_chunk().unwrap().id(), chunk1.id());
        assert!(
            events[0].is_addition(),
            "the first write should result in the addition of chunk1"
        );
        // chunk1 introduces 3 new components on this entity: points, colors, labels.
        let schema_add = match &events[1].diff {
            ChunkStoreDiff::SchemaAddition(sa) => sa,
            other => panic!("expected SchemaAddition, got {other:?}"),
        };
        assert_eq!(schema_add.new_columns.len(), 1);
        assert_eq!(schema_add.new_columns[0].entity_path, entity_path);
        let new_descriptors: BTreeSet<_> = schema_add.new_columns[0]
            .components
            .iter()
            .map(|c| c.descriptor.clone())
            .collect();
        assert_eq!(
            new_descriptors,
            BTreeSet::from([
                MyPoints::descriptor_points(),
                MyPoints::descriptor_colors(),
                MyPoints::descriptor_labels(),
            ]),
            "points, colors, labels"
        );
        // All should be is_static since chunk1 is static.
        for comp in &schema_add.new_columns[0].components {
            assert!(
                comp.is_static,
                "{} should be is_static after a static insert",
                comp.descriptor
            );
        }

        let events = store.insert_chunk(&chunk2)?;
        // chunk2 only has points and colors which already exist — no new schema columns.
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].delta_chunk().unwrap().id(), chunk2.id());
        assert!(
            events[0].is_addition(),
            "the second write should result in the addition of chunk2 and nothing else"
        );

        let stats_before = store.stats();
        {
            let ChunkStoreChunkStats {
                num_chunks,
                total_size_bytes: _,
                num_rows,
                num_events,
            } = stats_before.static_chunks;
            assert_eq!(2, num_chunks);
            assert_eq!(2, num_rows);
            assert_eq!(5, num_events);
        }

        let events = store.insert_chunk(&chunk3)?;
        assert_eq!(events.len(), 2);
        assert_eq!(events[0].delta_chunk().unwrap().id(), chunk3.id());
        assert!(events[0].is_addition());
        assert_eq!(events[1].delta_chunk().unwrap().id(), chunk1.id());
        assert!(
            events[1].is_deletion(),
            "the third write should result in the addition of chunk3 and the deletion of chunk1"
        );

        let stats_after = store.stats();
        {
            let ChunkStoreChunkStats {
                num_chunks,
                total_size_bytes: _,
                num_rows,
                num_events,
            } = stats_after.static_chunks;
            assert_eq!(2, num_chunks);
            assert_eq!(2, num_rows);
            assert_eq!(3, num_events);
        }

        let events = store.insert_chunk(&chunk4)?;
        assert!(
            events.is_empty(),
            "the fourth write should result in no changes at all"
        );

        let stats_after = store.stats();
        {
            let ChunkStoreChunkStats {
                num_chunks,
                total_size_bytes: _,
                num_rows,
                num_events,
            } = stats_after.static_chunks;
            assert_eq!(2, num_chunks);
            assert_eq!(2, num_rows);
            assert_eq!(3, num_events);
        }

        Ok(())
    }

    /// Regression test for RR-4880: `rrd optimize` / `.collect(optimize=…)` lose static transforms.
    ///
    /// Both optimize paths route every chunk through `ChunkStore::insert_chunk`, which applies
    /// auto-delete shadowed static chunk semantics. See [`preserves_static_transforms`] and RR-4887
    /// for more info.
    ///
    /// This test reproduces that loss with three static chunks on the same entity, each carrying a
    /// `Transform3D` for a distinct child frame. All three must be preserved.
    #[test]
    fn static_transforms_spread_across_chunks_are_preserved() -> anyhow::Result<()> {
        re_log::setup_logging();

        let mut store = ChunkStore::new(
            re_log_types::StoreId::random(re_log_types::StoreKind::Recording, "test_app"),
            Default::default(),
        );

        let entity_path = EntityPath::from("tf_static");

        // Three distinct frames, each in its own static chunk, all on the same entity, with
        // increasing RowIds (as if logged over time). They share the same component columns but
        // carry different child frames, so last-write-wins would clobber all but the last.
        let child_frames = ["child0", "child1", "child2"];

        for (i, child_frame) in child_frames.iter().enumerate() {
            let transform = archetypes::Transform3D::default()
                .with_child_frame(*child_frame)
                .with_translation([i as f32, i as f32, i as f32]);
            let chunk = Chunk::builder(entity_path.clone())
                .with_archetype(RowId::new(), TimePoint::STATIC, &transform)
                .build()?;
            store.insert_chunk(&Arc::new(chunk))?;
        }

        let ChunkStoreChunkStats { num_rows, .. } = store.stats().static_chunks;
        assert_eq!(
            num_rows,
            child_frames.len() as u64,
            "all static transform rows spread across chunks should be preserved, \
             but {num_rows} of {} survived",
            child_frames.len(),
        );

        Ok(())
    }

    /// Counterpart to [`static_transforms_spread_across_chunks_are_preserved`]: non-transform
    /// static data must *still* be deduplicated to the latest value.
    //TODO(RR-4887): this test should no longer pass with this issue is resolved.
    #[test]
    fn static_non_transform_data_spread_across_chunks_is_deduplicated() -> anyhow::Result<()> {
        re_log::setup_logging();

        let mut store = ChunkStore::new(
            re_log_types::StoreId::random(re_log_types::StoreKind::Recording, "test_app"),
            Default::default(),
        );

        let entity_path = EntityPath::from("camera");

        let values = [
            MyPoint::new(1.0, 1.0),
            MyPoint::new(2.0, 2.0),
            MyPoint::new(3.0, 3.0),
        ];

        for value in &values {
            let chunk = Chunk::builder(entity_path.clone())
                .with_component_batches(
                    RowId::new(),
                    TimePoint::STATIC,
                    [(MyPoints::descriptor_points(), &[*value] as _)],
                )
                .build()?;
            store.insert_chunk(&Arc::new(chunk))?;
        }

        let ChunkStoreChunkStats { num_rows, .. } = store.stats().static_chunks;
        assert_eq!(
            num_rows, 1,
            "non-transform static data should be deduplicated to the latest value, \
             but {num_rows} rows survived",
        );

        Ok(())
    }

    /// Temporal data first, then static: `is_static` should transition and re-emit a `SchemaAddition`.
    #[test]
    fn schema_temporal_then_static() -> anyhow::Result<()> {
        re_log::setup_logging();

        let mut store = ChunkStore::new(
            re_log_types::StoreId::random(re_log_types::StoreKind::Recording, "test_app"),
            Default::default(),
        );

        let entity_path = EntityPath::from("this/that");
        let points = &[MyPoint::new(1.0, 1.0)];

        // Temporal insert: new component, is_static = false.
        let events = store.insert_chunk(&Arc::new(
            Chunk::builder(entity_path.clone())
                .with_component_batches(
                    RowId::new(),
                    [(Timeline::new_sequence("frame"), 1)],
                    [(MyPoints::descriptor_points(), points as _)],
                )
                .build()?,
        ))?;
        assert_eq!(events.len(), 2);
        assert!(events[0].is_addition());
        let schema_add = match &events[1].diff {
            ChunkStoreDiff::SchemaAddition(sa) => sa,
            other => panic!("expected SchemaAddition, got {other:?}"),
        };
        assert!(!schema_add.new_columns[0].components[0].is_static);

        // Static insert: same component, triggers is_static transition.
        let events = store.insert_chunk(&Arc::new(
            Chunk::builder(entity_path.clone())
                .with_component_batches(
                    RowId::new(),
                    TimePoint::STATIC,
                    [(MyPoints::descriptor_points(), points as _)],
                )
                .build()?,
        ))?;
        assert_eq!(events.len(), 2);
        assert!(events[0].is_addition());
        let schema_add = match &events[1].diff {
            ChunkStoreDiff::SchemaAddition(sa) => sa,
            other => panic!("expected SchemaAddition for is_static transition, got {other:?}"),
        };
        assert!(
            schema_add.new_columns[0].components[0].is_static,
            "component should now be is_static"
        );

        // Another temporal insert: no further transition.
        let events = store.insert_chunk(&Arc::new(
            Chunk::builder(entity_path.clone())
                .with_component_batches(
                    RowId::new(),
                    [(Timeline::new_sequence("frame"), 2)],
                    [(MyPoints::descriptor_points(), points as _)],
                )
                .build()?,
        ))?;
        assert!(
            !events.iter().any(|e| e.is_schema_addition()),
            "no SchemaAddition after transition already happened"
        );

        Ok(())
    }

    #[test]
    fn row_id_min_overwrites() -> anyhow::Result<()> {
        re_log::setup_logging();

        let entity_path = EntityPath::from("this/that");

        let timepoint = TimePoint::default().with(Timeline::log_tick(), 42);

        let row_id1_1 = RowId::new();
        let row_id2_1 = RowId::new();

        let labels1 = &[MyLabel("111".to_owned())];
        let labels2 = &[MyLabel("222".to_owned())];

        let chunk1 = Chunk::builder(entity_path.clone())
            .with_component_batches(
                row_id1_1,
                timepoint.clone(),
                [(MyPoints::descriptor_labels(), labels1 as _)],
            )
            .build()?;
        let chunk2 = Chunk::builder(entity_path.clone())
            .with_component_batches(
                row_id2_1,
                timepoint.clone(),
                [(MyPoints::descriptor_labels(), labels2 as _)],
            )
            .build()?;

        let chunk1 = Arc::new(chunk1);
        let chunk2 = Arc::new(chunk2);

        fn assert_chunk_ids_per_min_row_id(
            store: &ChunkStore,
            chunks: impl IntoIterator<Item = (RowId, ChunkId)>,
        ) {
            assert_eq!(
                chunks.into_iter().collect::<BTreeSet<_>>(),
                store.physical_chunk_ids_per_min_row_id
            );
        }

        {
            // Insert `chunk1` then `chunk2`.

            let mut store = ChunkStore::new(
                re_log_types::StoreId::random(re_log_types::StoreKind::Recording, "test_app"),
                ChunkStoreConfig {
                    enable_changelog: false,
                    chunk_max_bytes: u64::MAX,
                    chunk_max_rows: u64::MAX,
                    chunk_max_rows_if_unsorted: u64::MAX,
                },
            );

            let _ = store.insert_chunk(&chunk1)?;
            assert_chunk_ids_per_min_row_id(&store, [(row_id1_1, chunk1.id())]);

            let _ = store.insert_chunk(&chunk1)?; // noop
            assert_chunk_ids_per_min_row_id(&store, [(row_id1_1, chunk1.id())]);

            // `chunk2` gets appended to `chunk1`:
            // * the only Row ID left is `row_id1_1`
            // * there shouldn't be any warning of any kind
            // * the only chunk left in the store is the new, compacted chunk
            let _ = store.insert_chunk(&chunk2)?;
            assert_eq!(1, store.physical_chunks_per_chunk_id.len());
            let compacted_chunk_id = store
                .physical_chunks_per_chunk_id
                .values()
                .next()
                .unwrap()
                .id();
            assert_chunk_ids_per_min_row_id(&store, [(row_id1_1, compacted_chunk_id)]);
        }

        {
            // Insert `chunk2` then `chunk1`.

            let mut store = ChunkStore::new(
                re_log_types::StoreId::random(re_log_types::StoreKind::Recording, "test_app"),
                ChunkStoreConfig {
                    enable_changelog: false,
                    chunk_max_bytes: u64::MAX,
                    chunk_max_rows: u64::MAX,
                    chunk_max_rows_if_unsorted: u64::MAX,
                },
            );

            let _ = store.insert_chunk(&chunk2)?;
            assert_chunk_ids_per_min_row_id(&store, [(row_id2_1, chunk2.id())]);

            let _ = store.insert_chunk(&chunk2)?; // noop
            assert_chunk_ids_per_min_row_id(&store, [(row_id2_1, chunk2.id())]);

            // Exactly the same as before, because chunks get compacted in Row ID order, regardless
            // of the order they are inserted in.
            //
            // `chunk2` gets appended to `chunk1`:
            // * the only Row ID left is `row_id1_1`
            // * there shouldn't be any warning of any kind
            // * the only chunk left in the store is the new, compacted chunk
            let _ = store.insert_chunk(&chunk1)?;
            assert_eq!(1, store.physical_chunks_per_chunk_id.len());
            let compacted_chunk_id = store
                .physical_chunks_per_chunk_id
                .values()
                .next()
                .unwrap()
                .id();
            assert_chunk_ids_per_min_row_id(&store, [(row_id1_1, compacted_chunk_id)]);
        }

        Ok(())
    }
}
