use std::collections::HashMap;
use std::collections::hash_map::Entry;
use std::error::Error as _;
use std::fmt::Write as _;
use std::sync::{Arc, OnceLock};

use re_auth::Jwt;
use re_auth::credentials::CredentialsProviderError;
use re_byte_size::SizeBytes as _;
use re_protos::capabilities::ServerCapabilities;
use re_protos::cloud::v1alpha1::{EntryFilter, FindEntriesRequest, WhoAmIRequest};
use re_uri::Origin;
use tokio::sync::RwLock;
use tonic::Code;

use crate::connection_client::{Connection, RedapClient};
use crate::grpc::RedapClientStack;
use crate::{ApiError, ApiResult, TonicStatusError};

/// Returns a suggested host if the user likely forgot the "api." prefix.
///
/// This detects the common mistake of connecting to `xxx.cloud.rerun.io` instead of
/// `api.xxx.cloud.rerun.io`.
fn suggest_api_prefix(origin: &Origin) -> Option<String> {
    let host = origin.format_host();
    if !host.starts_with("api.") && host.ends_with(".cloud.rerun.io") {
        Some(format!("api.{host}"))
    } else {
        None
    }
}

//TODO(#11016): refactor this to achieve lazy auth retry.
pub struct ConnectionRegistry {
    /// The saved authentication tokens.
    ///
    /// These are the tokens explicitly set by the user, e.g. via `--token` or the UI. They may
    /// be persisted.
    ///
    /// When no saved token is available for a given server, we fall back to the `REDAP_TOKEN`
    /// envvar if set. See [`crate::ConnectionHandle::client`].
    saved_credentials: HashMap<re_uri::Origin, Credentials>,

    /// Fallback token.
    ///
    /// If set, the fallback token is used when no specific token is registered for a given origin.
    fallback_token: Option<Jwt>,

    /// The cached remote connections, keyed by origin.
    ///
    /// Connections are much cheaper to clone than create (since the latter involves establishing an
    /// actual TCP connection), so we keep them around once created.
    remote_connections: HashMap<re_uri::Origin, Connection>,
}

impl ConnectionRegistry {
    /// Create a new connection registry and return a handle to it.
    ///
    /// This version uses stored credentials by default if they are available.
    /// You should prefer to use this instead of [`Self::new_without_stored_credentials`]
    /// if there is no reason not to.
    pub fn new_with_stored_credentials() -> ConnectionRegistryHandle {
        ConnectionRegistryHandle {
            inner: Arc::new(RwLock::new(Self {
                saved_credentials: HashMap::new(),
                fallback_token: None,
                remote_connections: HashMap::new(),
            })),
            internal: Arc::new(OnceLock::new()),
            use_stored_credentials: true,
        }
    }

    /// Create a new connection registry and return a handle to it.
    ///
    /// This version does not use stored credentials by default if they are available.
    /// You should prefer to use [`Self::new_with_stored_credentials`] instead,
    /// if there is no reason not to.
    pub fn new_without_stored_credentials() -> ConnectionRegistryHandle {
        ConnectionRegistryHandle {
            inner: Arc::new(RwLock::new(Self {
                saved_credentials: HashMap::new(),
                fallback_token: None,
                remote_connections: HashMap::new(),
            })),
            internal: Arc::new(OnceLock::new()),
            use_stored_credentials: false,
        }
    }
}

impl re_byte_size::MemUsageTreeCapture for ConnectionRegistry {
    fn capture_mem_usage_tree(&self) -> re_byte_size::MemUsageTree {
        let Self {
            saved_credentials,
            fallback_token,
            remote_connections,
        } = self;

        re_byte_size::MemUsageNode::default()
            .with_child("saved_credentials", saved_credentials.total_size_bytes())
            .with_child("fallback_token", fallback_token.total_size_bytes())
            .with_child("remote_connections", remote_connections.total_size_bytes())
            .into_tree()
    }
}

impl re_byte_size::MemUsageTreeCapture for ConnectionRegistryHandle {
    fn capture_mem_usage_tree(&self) -> re_byte_size::MemUsageTree {
        wrap_blocking_lock(|| self.inner.blocking_read().capture_mem_usage_tree())
    }
}

/// Possible errors when creating a connection.
#[derive(Debug, thiserror::Error)]
pub enum ClientCredentialsError {
    #[error("{}", re_error::format_with_details("error when refreshing credentials", .0.to_string()))]
    RefreshError(TonicStatusError),

    #[error("the credentials are expired")]
    SessionExpired,

    #[error("{}", re_error::format_with_details("the server requires an authentication token but none was provided", .0.to_string()))]
    UnauthenticatedMissingToken(TonicStatusError),

    #[error("{}", re_error::format_with_details("the server rejected the provided authentication token", .status.to_string()))]
    UnauthenticatedBadToken {
        status: TonicStatusError,
        credentials: SourcedCredentials,
    },

    #[error("{0}")]
    HostMismatch(re_auth::HostMismatchError),

    #[error("the server requires authentication for read access")]
    NotAuthorized,
}

/// Owns shared connection and credential state for redap origins.
///
/// Use [`ConnectionRegistryHandle::connection_handle`] to bind this state to one origin for
/// application workflows. This registry is cheap to clone.
#[derive(Clone)]
pub struct ConnectionRegistryHandle {
    inner: Arc<RwLock<ConnectionRegistry>>,

    /// The in-process internal catalog connection, if enabled.
    ///
    /// Shared across cloned handles and readable from sync code without taking the async registry
    /// lock.
    internal: Arc<OnceLock<Connection>>,

    /// Whether to use credentials stored on the host machine by default.
    /// Since some tests run on a single-threaded tokio runtime and this is never updated,
    /// it lives outside the `RwLock`.
    use_stored_credentials: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Hash, re_byte_size::SizeBytes)]
pub enum Credentials {
    /// Explicit token
    Token(Jwt),

    /// Credentials from local storage
    Stored,
}

impl Credentials {
    /// Whether these credentials have write permission.
    ///
    /// Returns `None` for [`Credentials::Stored`] (resolved at connect time,
    /// permissions unknown) or if the token claims cannot be decoded.
    pub fn has_write_permission(&self) -> Option<bool> {
        match self {
            Self::Token(jwt) => {
                let claims: re_auth::Claims = jwt.decode_claims().ok()?;
                Some(claims.has_write_permission())
            }
            Self::Stored => None,
        }
    }
}

#[derive(Clone, Debug)]
pub enum CredentialSource {
    PerOrigin,
    Fallback,
    EnvVar,
}

impl std::fmt::Display for CredentialSource {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::PerOrigin => f.write_str("per-origin"),
            Self::Fallback => f.write_str("fallback"),
            Self::EnvVar => f.write_str("env-var"),
        }
    }
}

#[derive(Clone, Debug)]
pub struct SourcedCredentials {
    pub source: CredentialSource,
    pub credentials: Credentials,
}

/// A client stack that passed the `/WhoAmI` check, and the capabilities that call returned.
struct ValidatedClientStack {
    client_stack: RedapClientStack,
    capabilities: ServerCapabilities,
}

impl ConnectionRegistryHandle {
    pub fn set_credentials(&self, origin: &re_uri::Origin, credentials: Credentials) {
        wrap_blocking_lock(|| {
            let mut inner = self.inner.blocking_write();
            inner.saved_credentials.insert(origin.clone(), credentials);
            inner.remote_connections.remove(origin);
        });
    }

    pub fn credentials(&self, origin: &re_uri::Origin) -> Option<Credentials> {
        wrap_blocking_lock(|| {
            let inner = self.inner.blocking_read();
            inner.saved_credentials.get(origin).cloned()
        })
    }

    /// What the server at this origin implements and supports, for any caller.
    ///
    /// This says nothing about what the caller is allowed to do. Capabilities arrive when the
    /// connection is made, so an origin we have not connected to yet is
    /// [`ServerCapabilities::unknown`].
    pub fn capabilities(&self, origin: &re_uri::Origin) -> ServerCapabilities {
        if let Some(connection) = self.internal.get()
            && connection.origin() == origin
        {
            return connection.capabilities().clone();
        }

        wrap_blocking_lock(|| {
            self.inner
                .blocking_read()
                .remote_connections
                .get(origin)
                .map_or_else(ServerCapabilities::unknown, |connection| {
                    connection.capabilities().clone()
                })
        })
    }

    pub fn remove_credentials(&self, origin: &re_uri::Origin) {
        wrap_blocking_lock(|| {
            let mut inner = self.inner.blocking_write();
            inner.saved_credentials.remove(origin);
            inner.remote_connections.remove(origin);
        });
    }

    pub fn set_fallback_token(&self, token: Jwt) {
        wrap_blocking_lock(|| {
            let mut inner = self.inner.blocking_write();
            inner.fallback_token = Some(token);
        });
    }

    pub fn should_use_stored_credentials(&self) -> bool {
        self.use_stored_credentials
    }

    pub fn with_internal(self, internal: Connection) -> Self {
        self.set_internal(internal);
        self
    }

    pub fn set_internal(&self, internal: Connection) {
        if let Err(rejected) = self.internal.set(internal) {
            let new_origin = rejected.origin();
            let existing_origin = self
                .internal_origin()
                .map(|origin| origin.to_string())
                .unwrap_or_else(|| "<missing>".to_owned());
            re_log::debug!(
                "Ignoring duplicate internal connection for {new_origin}; already set for {existing_origin}"
            );
        }
    }

    pub fn internal_origin(&self) -> Option<re_uri::Origin> {
        self.internal
            .get()
            .map(|connection| connection.origin().clone())
    }

    pub fn connection_handle(&self, origin: re_uri::Origin) -> crate::ConnectionHandle {
        crate::ConnectionHandle::new(self.clone(), origin)
    }

    pub fn internal_connection_handle(&self) -> Option<crate::ConnectionHandle> {
        self.internal_origin()
            .map(|origin| self.connection_handle(origin))
    }

    pub fn is_internal_origin(&self, origin: &re_uri::Origin) -> bool {
        self.internal
            .get()
            .is_some_and(|connection| connection.origin() == origin)
    }

    /// Get a connection for the given origin, creating one if it doesn't exist yet.
    ///
    /// Note: although `ConnectionClient` is cheap to clone, callsites should generally *not* hold on
    /// to client instances for longer than the immediate needs. In the future, authentication may
    /// require periodic tokens refresh, so it is necessary to always get a "fresh" connection.
    ///
    /// If a token has already been registered for this origin, it will be used. Otherwise, it will attempt to
    /// use the following token, in this order:
    /// - The fallback token, if set via [`Self::set_fallback_token`].
    /// - The `REDAP_TOKEN` environment variable is set.
    /// - Local credentials for Rerun Hub
    ///
    /// Failing that, no token will be used.
    #[tracing::instrument(level = "info", skip_all)]
    pub(crate) async fn connection(&self, origin: re_uri::Origin) -> ApiResult<Connection> {
        if let Some(connection) = self.internal.get()
            && connection.origin() == &origin
        {
            return Ok(connection.clone());
        }

        {
            let inner = self.inner.read().await;
            if let Some(connection) = inner.remote_connections.get(&origin) {
                return Ok(connection.clone());
            }
        }

        // Don't hold the lock while creating the connection — this may take a while and we may
        // want to read the tokens in the meantime for other purposes.
        let (saved_credentials, fallback_token) = {
            let inner = self.inner.read().await;
            (
                inner.saved_credentials.get(&origin).cloned(),
                inner.fallback_token.clone(),
            )
        };

        let mut credentials_to_try = vec![];

        let add_cred = |creds: &mut Vec<SourcedCredentials>, cred: SourcedCredentials| {
            if !creds.iter().any(|c| c.credentials == cred.credentials) {
                creds.push(cred);
            }
        };

        for cred in [
            saved_credentials
                .clone()
                .map(|credentials| SourcedCredentials {
                    source: CredentialSource::PerOrigin,
                    credentials,
                }),
            fallback_token.clone().map(|token| SourcedCredentials {
                source: CredentialSource::Fallback,
                credentials: Credentials::Token(token),
            }),
            get_token_from_env().map(|token| SourcedCredentials {
                source: CredentialSource::EnvVar,
                credentials: Credentials::Token(token),
            }),
        ]
        .into_iter()
        .flatten()
        {
            add_cred(&mut credentials_to_try, cred);
        }

        let (
            ValidatedClientStack {
                client_stack,
                capabilities,
            },
            successful_credentials,
        ) = Self::try_connect_client_stack(origin.clone(), credentials_to_try.into_iter()).await?;

        // We have a successful connection, so we cache it and remember about the successful token.
        //
        // Note: because we only acquire the lock now, a race is possible where two threads
        // concurrently attempt to create the connection and would override each-other's results. This
        // is acceptable since both should reach the same conclusion, and preferable that holding
        // the lock for the entire time, as the connection process can take a while.
        let connection = {
            let mut inner = self.inner.write().await;

            let connection = Connection {
                client: RedapClient::new(
                    origin.clone(),
                    crate::grpc::boxed_redap_grpc_client(client_stack.clone()),
                    Some(crate::ChunkCacheHandle::default()),
                ),
                analytics: Some(crate::ConnectionAnalyticsExporter::from_remote_service(
                    origin.clone(),
                    client_stack,
                )),
                capabilities,
            };

            inner
                .remote_connections
                .insert(origin.clone(), connection.clone());

            let successful_credentials = successful_credentials.map(|c| c.credentials);

            if successful_credentials != saved_credentials {
                if let Some(successful_token) = successful_credentials {
                    inner
                        .saved_credentials
                        .insert(origin.clone(), successful_token);
                } else {
                    inner.saved_credentials.remove(&origin);
                }
            }

            connection
        };

        Ok(connection)
    }

    /// Try connecting with whatever credentials we have available.
    ///
    /// On success returns the configured client stack and the credentials specification that worked.
    #[tracing::instrument(level = "info", skip_all)]
    async fn try_connect_client_stack(
        origin: re_uri::Origin,
        possible_credentials: impl Iterator<Item = SourcedCredentials>,
    ) -> ApiResult<(ValidatedClientStack, Option<SourcedCredentials>)> {
        let mut first_failed_attempt = None;

        for credentials in possible_credentials {
            let result =
                Self::connect_and_validate_client_stack(origin.clone(), Some(credentials.clone()))
                    .await;

            match result {
                Ok(validated) => {
                    return Ok((validated, Some(credentials)));
                }

                Err(err) if err.is_client_credentials_error() => {
                    // remember about the first occurrence of this error but continue trying other
                    // tokens
                    if first_failed_attempt.is_none() {
                        first_failed_attempt = Some(err);
                    }
                }

                Err(err) => return Err(err),
            }
        }

        // Everything failed, last ditch effort without a token.
        let result = Self::connect_and_validate_client_stack(origin.clone(), None).await;

        match result {
            Ok(validated) => Ok((validated, None)),

            Err(err) => {
                // If we actually tried tokens, this error is more relevant.
                if let Some(first_failed_attempt) = first_failed_attempt {
                    Err(first_failed_attempt)
                } else {
                    Err(err)
                }
            }
        }
    }

    /// Probe `{origin}/version` to detect non-Rerun endpoints (e.g. user typed
    /// `asdf.rerun.io` instead of `api.asdf.rerun.io`).
    ///
    /// Returns `Ok(())` if the probe is inconclusive (server responded as expected),
    /// `Err(_)` with a friendly diagnostic if the origin is clearly not a Rerun server.
    #[tracing::instrument(level = "info", skip_all)]
    async fn ensure_is_rerun_server(origin: &re_uri::Origin) -> ApiResult<()> {
        let res = crate::with_retry("http_version_fetch", || async {
            ehttp::fetch_async(ehttp::Request::get(format!("{}/version", origin.as_url())))
                .await
                .map_err(|err| {
                    let mut msg = format!("failed to connect to server '{origin}': {err}");
                    if let Some(suggested) = suggest_api_prefix(origin) {
                        write!(msg, ". Did you mean '{suggested}'?").ok();
                    }
                    ApiError::connection(origin, msg)
                })
        })
        .await?;

        if res.ok {
            // Server responded as expected — probe is inconclusive about why gRPC failed.
            return Ok(());
        }

        let hint = suggest_api_prefix(origin).map(|suggested| {
            format!("Did you mean '{suggested}'? Rerun Hub endpoints require the 'api.' prefix")
        });
        // Truncate the body so we don't dump an entire HTML error page into the error.
        let body_snippet = std::str::from_utf8(&res.bytes)
            .ok()
            .map(|s| s.trim())
            .filter(|s| !s.is_empty())
            .map(|s| {
                const MAX: usize = 200;
                if s.len() > MAX {
                    format!("{}…", &s[..s.floor_char_boundary(MAX)])
                } else {
                    s.to_owned()
                }
            });
        Err(ApiError::invalid_server_with_response(
            origin,
            res.status,
            &res.status_text,
            body_snippet.as_deref(),
            hint.as_deref(),
        ))
    }

    #[tracing::instrument(level = "info", skip_all)]
    async fn connect_and_validate_client_stack(
        origin: re_uri::Origin,
        credentials: Option<SourcedCredentials>,
    ) -> ApiResult<ValidatedClientStack> {
        // Check the token's allowed hosts before wrapping it in a provider that
        // would blindly attach it to every outgoing request. If the host
        // doesn't match, return a credentials error so the caller can skip
        // this credential and try the next one.
        let host = origin.host.to_string();
        let provider: Option<Arc<dyn re_auth::credentials::CredentialsProvider + Send + Sync>> =
            match credentials.as_ref().map(|c| &c.credentials) {
                Some(Credentials::Token(token)) => {
                    token.for_host(&host).map_err(|err| {
                        ApiError::credentials_with_source(
                            &origin,
                            None,
                            ClientCredentialsError::HostMismatch(err),
                            format!("token not allowed for host '{host}'"),
                        )
                    })?;
                    Some(Arc::new(
                        re_auth::credentials::StaticCredentialsProvider::new(token.clone()),
                    ))
                }
                Some(Credentials::Stored) => {
                    // For stored credentials, load the token to check its allowed hosts
                    // before committing to using it.
                    if let Ok(Some(c)) = re_auth::oauth::load_credentials() {
                        c.access_token().jwt().for_host(&host).map_err(|err| {
                            ApiError::credentials_with_source(
                                &origin,
                                None,
                                ClientCredentialsError::HostMismatch(err),
                                format!("stored token not allowed for host '{host}'"),
                            )
                        })?;
                    }
                    Some(Arc::new(re_auth::credentials::CliCredentialsProvider::new()))
                }
                None => None,
            };

        let (mut grpc_client, client_stack) =
            match crate::grpc::connect_grpc_client(origin.clone(), provider).await {
                Ok(pair) => pair,
                Err(grpc_err) => {
                    // It's a common mistake to connect to `asdf.rerun.io` instead of `api.asdf.rerun.io`,
                    // so if what we're trying to connect to is not a valid Rerun server, then cut out
                    // a layer of noise:
                    Self::ensure_is_rerun_server(&origin).await?;

                    return Err(grpc_err);
                }
            };

        // Call the WhoAmI endpoint to check that authentication is successful. It's ok to do
        // this since we're caching the client, so we're not spamming such a request unnecessarily.
        let request_result = grpc_client.who_am_i(WhoAmIRequest {}).await;

        // TODO(rerun-io/dataplatform#1069): remove the `FindEntries` fallback once all servers
        // have been updated to support the `WhoAmI` endpoint.
        let request_result = match request_result {
            Err(err) if err.code() == Code::Unimplemented => {
                re_log::debug_once!(
                    "Server at {origin} does not support WhoAmI, falling back to FindEntries"
                );
                grpc_client
                    .find_entries(FindEntriesRequest {
                        filter: Some(EntryFilter {
                            id: None,
                            name: None,
                            entry_kind: None,
                            entry_kinds: vec![],
                        }),
                    })
                    .await
                    .map(|_| ServerCapabilities::unknown())
            }
            Ok(resp) => {
                let trace_id = crate::extract_trace_id(resp.metadata());
                let re_protos::cloud::v1alpha1::WhoAmIResponse {
                    user_id,
                    can_read,
                    can_write,
                    capabilities,
                } = resp.into_inner();
                let is_anonymous = user_id.is_none();
                let user_id = user_id.as_deref().unwrap_or("<anonymous>");
                let capabilities =
                    capabilities.map_or_else(ServerCapabilities::unknown, Into::into);
                re_log::debug_once!(
                    "Connected to {origin}: {user_id}, can_read={can_read}, can_write={can_write}, capabilities={capabilities:?}",
                );
                if !can_read {
                    if is_anonymous {
                        // Anonymous user without read access — treat as a credentials error
                        // so the auth flow is triggered.
                        return Err(ApiError::credentials_with_source(
                            &origin,
                            trace_id,
                            ClientCredentialsError::NotAuthorized,
                            "the server requires authentication for read access",
                        ));
                    }
                    return Err(ApiError::permission_denied(
                        &origin,
                        trace_id,
                        "the server reports that you do not have read access",
                    ));
                }
                Ok(capabilities)
            }
            Err(err) => Err(err),
        };

        match request_result {
            Ok(capabilities) => Ok(ValidatedClientStack {
                client_stack,
                capabilities,
            }),

            // catch unauthenticated errors and forget the token if they happen
            Err(err) if err.code() == Code::Unauthenticated => {
                let trace_id = crate::extract_trace_id(err.metadata());
                if let Some(credentials) = credentials {
                    Err(ApiError::credentials_with_source(
                        &origin,
                        trace_id,
                        ClientCredentialsError::UnauthenticatedBadToken {
                            status: err.into(),
                            credentials,
                        },
                        "unauthenticated: bad token",
                    ))
                } else {
                    Err(ApiError::credentials_with_source(
                        &origin,
                        trace_id,
                        ClientCredentialsError::UnauthenticatedMissingToken(err.into()),
                        "unauthenticated: missing token",
                    ))
                }
            }

            Err(err) => {
                if let Some(cred_error) = err.source().and_then(|s| {
                    s.downcast_ref::<re_auth::credentials::CredentialsProviderError>()
                }) {
                    match cred_error {
                        CredentialsProviderError::SessionExpired => {
                            Err(ApiError::credentials_with_source(
                                &origin,
                                None,
                                ClientCredentialsError::SessionExpired,
                                "session expired",
                            ))
                        }
                        CredentialsProviderError::Custom(_) => {
                            Err(ApiError::credentials_with_source(
                                &origin,
                                None,
                                ClientCredentialsError::RefreshError(err.into()),
                                "refreshing credentials",
                            ))
                        }
                    }
                } else {
                    Err(ApiError::tonic(
                        &origin,
                        err,
                        "verifying connection to server",
                    ))
                }
            }
        }
    }

    /// Dump all tokens for persistence purposes.
    pub fn dump_tokens(&self) -> SerializedTokens {
        wrap_blocking_lock(|| {
            let this = self.inner.blocking_read();
            let per_origin = this
                .saved_credentials
                .iter()
                .map(|(origin, credentials)| {
                    (
                        origin.clone(),
                        match credentials {
                            Credentials::Token(jwt) => SerializedCredentials::Jwt(jwt.to_string()),
                            Credentials::Stored => SerializedCredentials::Stored,
                        },
                    )
                })
                .collect();
            let fallback = this.fallback_token.clone().map(|v| v.to_string());

            SerializedTokens {
                tokens_per_origin: per_origin,
                fallback_token: fallback,
            }
        })
    }

    /// Load tokens from persistence.
    ///
    /// IMPORTANT: This will NOT overwrite any existing tokens, since it is assumed that existing
    /// tokens were explicitly set by the user (e.g. with `--token`).
    pub fn load_tokens(&self, tokens: SerializedTokens) {
        wrap_blocking_lock(|| {
            let mut inner = self.inner.blocking_write();
            for (origin, token) in tokens.tokens_per_origin {
                if let Entry::Vacant(e) = inner.saved_credentials.entry(origin.clone()) {
                    match token {
                        SerializedCredentials::Stored => {
                            e.insert(Credentials::Stored);
                        }
                        SerializedCredentials::Jwt(token) => {
                            if let Ok(jwt) = Jwt::try_from(token) {
                                e.insert(Credentials::Token(jwt));
                            } else {
                                re_log::debug!("Failed to parse token for origin {origin}");
                            }
                        }
                    }
                } else {
                    re_log::trace!("Ignoring token for origin {origin} as it is already set");
                }
            }

            if let Some(fallback_token) = tokens
                .fallback_token
                .and_then(|token| Jwt::try_from(token).ok())
                && inner.fallback_token.is_none()
            {
                inner.fallback_token = Some(fallback_token);
            }
        });
    }

    /// Clears all chunk caches.
    pub fn purge_memory(&self) {
        wrap_blocking_lock(|| {
            // Each cache has its own lock, so purging them only needs a read lock on the registry.
            let inner = self.inner.blocking_read();

            #[expect(clippy::iter_over_hash_type)]
            // Every cache is purged, so order isn't important.
            for connection in inner.remote_connections.values() {
                if let Some(cache) = connection.client.chunk_cache() {
                    cache.write().purge_memory();
                }
            }
        });
    }
}

/// Wraps code using blocking tokio locks.
///
/// This is required if the calling code is running on an async executor thread, see e.g.
/// [`tokio::sync::RwLock::blocking_write`].
#[inline]
fn wrap_blocking_lock<F, R>(inner: F) -> R
where
    F: FnOnce() -> R,
{
    cfg_select! {
        target_arch = "wasm32" => { inner() }
        _ => { tokio::task::block_in_place(inner) }
    }
}

// ---

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct SerializedTokens {
    tokens_per_origin: Vec<(re_uri::Origin, SerializedCredentials)>,
    fallback_token: Option<String>,
}

#[derive(Debug, Clone)]
enum SerializedCredentials {
    Stored,
    Jwt(String),
}

impl<'de> serde::Deserialize<'de> for SerializedCredentials {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let s: String = String::deserialize(deserializer)?;
        if s == "stored" {
            Ok(Self::Stored)
        } else {
            Ok(Self::Jwt(s))
        }
    }
}

impl serde::Serialize for SerializedCredentials {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        match self {
            Self::Stored => serializer.serialize_str("stored"),
            Self::Jwt(token) => serializer.serialize_str(token),
        }
    }
}

// ---

#[cfg(not(target_arch = "wasm32"))]
fn get_token_from_env() -> Option<Jwt> {
    std::env::var("REDAP_TOKEN")
        .map_err(|err| match err {
            std::env::VarError::NotPresent => {}
            std::env::VarError::NotUnicode(..) => {
                re_log::warn_once!("REDAP_TOKEN env var is malformed: {err}");
            }
        })
        .and_then(|t| {
            re_auth::Jwt::try_from(t).map_err(|err| {
                re_log::warn_once!(
                    "REDAP_TOKEN env var is present, but the token is invalid: {err}"
                );
            })
        })
        .ok()
}

#[cfg(target_arch = "wasm32")]
fn get_token_from_env() -> Option<Jwt> {
    None
}
