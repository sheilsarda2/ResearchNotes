mod projection;
mod segment_stream_common;

pub(crate) use self::segment_stream_common::{
    PlanSummary, compute_chunk_info_aggregates, group_chunk_infos_by_segment_id,
    prepend_string_column_schema, schema_with_array_datatypes, segment_belongs_to_partition,
    segment_stream_plan_properties,
};
// Outside this module only the native-only local chunk-store provider builds its own claims.
#[cfg(not(target_arch = "wasm32"))]
pub(crate) use self::segment_stream_common::physical_column_by_name;

use self::projection::{
    all_schema_components, compute_schema_for_query, extract_projected_components,
    extract_projected_entity_paths,
};
use crate::analytics::{QueryInfo, QueryType, expr_filter_signature};
use crate::batch_coalescer::coalesce_exec::SizedCoalesceBatchesExec;
use crate::batch_coalescer::coalescer::CoalescerOptions;
use crate::pushdown_expressions::{apply_filter_expr_to_queries, filter_expr_is_supported};
use ahash::HashSet;
use arrow::array::{RecordBatch, UInt32Array};
use arrow::datatypes::{Schema, SchemaRef};
use arrow::record_batch::RecordBatchOptions;
use async_trait::async_trait;
use datafusion::catalog::{Session, TableProvider};
use datafusion::common::{Column, DataFusionError, exec_datafusion_err};
use datafusion::datasource::TableType;
use datafusion::logical_expr::{Expr, Operator, TableProviderFilterPushDown};
use datafusion::physical_plan::ExecutionPlan;
use futures::StreamExt as _;
use itertools::Itertools as _;
use parking_lot::Mutex;
use re_async::AsyncRuntimeHandle;
use re_dataframe::{Index, IndexValue, QueryExpression, SparseFillStrategy};
use re_log_types::EntryId;
use re_protos::cloud::v1alpha1::ext::QueryDatasetDataframe;
use re_protos::cloud::v1alpha1::ext::ScanSegmentTableDataframe;
use re_protos::cloud::v1alpha1::{
    FetchChunksRequest, GetDatasetSchemaRequest, GetDatasetSchemaResponse, QueryDatasetResponse,
};
use re_protos::common::v1alpha1::ext::ScanParameters;
use re_protos::headers::RerunHeadersInjectorExt as _;
use re_protos::{
    cloud::v1alpha1::ext::{Query, QueryDatasetRequest, QueryLatestAt, QueryRange},
    common::v1alpha1::ext::SegmentId,
};
use re_redap_client::{ApiError, ApiResult, ConnectionClient, ConnectionHandle};

use crate::{IntoDfError as _, SegmentStreamExec};
use re_sorbet::ComponentColumnSelector;
use std::collections::{BTreeMap, BTreeSet};
use std::str::FromStr as _;
use std::sync::Arc;
#[cfg(not(target_arch = "wasm32"))]
use std::sync::LazyLock;
use std::time::Duration;
use tracing::Instrument as _;
use web_time::{Instant, SystemTime};

/// Environment variable to force the client to go through the `FetchChunks` data fetching path.
#[cfg(not(target_arch = "wasm32"))]
static CHUNK_STRATEGY: LazyLock<String> = LazyLock::new(|| {
    std::env::var("RERUN_CHUNK_STRATEGY")
        .unwrap_or_default()
        .to_ascii_lowercase()
});

/// True when `RERUN_CHUNK_STRATEGY=grpc` — the client should fetch all chunks via
/// `FetchChunks` gRPC and the server should skip direct-URL generation.
#[cfg(not(target_arch = "wasm32"))]
pub(crate) fn force_grpc() -> bool {
    *CHUNK_STRATEGY == "grpc"
}

/// On Wasm there are no environment variables, so gRPC is never forced via env.
#[cfg(target_arch = "wasm32")]
pub(crate) fn force_grpc() -> bool {
    false
}

/// How many of a scan's `query_dataset` requests run concurrently.
///
/// A scan may issue several; this bounds how many are in flight at
/// once. On native the width is `pipeline_budget::query_dataset_max_concurrency`,
/// and each request also takes a permit from the process-wide
/// `pipeline_budget::query_dataset_semaphore` so co-tenant scans share one
/// ceiling. On wasm `pipeline_budget` isn't compiled in and there's no env, so
/// the width is a small fixed constant.
fn query_dataset_fanout() -> usize {
    cfg_select! {
        target_arch = "wasm32" => {
            /// gRPC-web requests overlap usefully even though wasm is single-threaded;
            /// kept modest since there's no process-wide limiter to back it up.
            const WASM_QUERY_DATASET_FANOUT: usize = 8;
            WASM_QUERY_DATASET_FANOUT
        }
        _ => {
            crate::pipeline_budget::query_dataset_max_concurrency()
        }
    }
}

/// Sets the size for output record batches in rows. The last batch will likely be smaller.
/// The default for Data Fusion is 8192, which leads to a 256Kb record batch on average for
/// rows with 32b of data. We are setting this lower as a reasonable first guess to avoid
/// the pitfall of executing a single row at a time, but we will likely want to consider
/// at some point moving to a dynamic sizing.
pub(crate) const DEFAULT_BATCH_BYTES: u64 = 200 * 1024 * 1024;
pub(crate) const DEFAULT_BATCH_ROWS: usize = 2048;

/// Mapping of `rerun_segment_id` to set of `IndexValues` to be used for querying
/// a specific set of index values per segment. If the option is None, then
/// `using_index_values` will not be applied to the dataset queries.
pub(crate) type IndexValuesMap = Option<Arc<BTreeMap<SegmentId, BTreeSet<IndexValue>>>>;

#[derive(Debug)]
pub struct DataframeQueryTableProvider<T: DataframeClientAPI> {
    pub schema: SchemaRef,
    query_expression: QueryExpression,
    query_dataset_request: QueryDatasetRequest,
    sort_index: Option<Index>,
    dataset_id: EntryId,
    client: T,
    index_values: IndexValuesMap,

    /// passing trace headers between phases of execution pipeline helps keep
    /// the entire operation under a single trace.
    #[cfg(not(target_arch = "wasm32"))]
    trace_headers: Option<crate::TraceHeaders>,

    /// Per-connection analytics sender for query stats.
    analytics: Option<crate::ConnectionAnalytics>,

    /// `query_metrics()` collectors that observed this provider at construction
    /// time. The list is captured once — typically by reading the Python
    /// `ContextVar` in `dataset_view.rs::reader()` — and travels with the
    /// provider into every `SegmentStreamExec` it builds. Empty when no
    /// `query_metrics()` scope was active.
    metrics_collectors: Vec<crate::MetricsCollector>,

    /// Filter expressions offered by DataFusion at planning time, stored for
    /// inclusion in the `cloud_query_dataset` analytics span.
    ///
    /// `Arc` so that the value survives any clone made between planning and scan.
    filter_capture: Arc<Mutex<Option<FilterCapture>>>,
}

/// Per-filter classification data captured in [`DataframeQueryTableProvider::supports_filters_pushdown`]
/// and consumed in [`DataframeQueryTableProvider::scan`].
#[derive(Default, Debug)]
struct FilterCapture {
    total: u32,

    /// Semicolon-delimited SQL signatures of all offered filters (in DataFusion's order).
    all_signatures: String,

    /// Signatures of filters classified as [`TableProviderFilterPushDown::Exact`].
    exact_signatures: String,

    /// Signatures of filters classified as [`TableProviderFilterPushDown::Inexact`].
    inexact_signatures: String,

    /// Signatures of filters classified as [`TableProviderFilterPushDown::Unsupported`].
    unsupported_signatures: String,
}

/// This trait provides the specific methods used when interacting with the
/// gRPC services for the datafusion client services.
///
/// By implementing this as a trait we can provide an alternative implementation
/// in our testing facility to remove all gRPC layers and test the server
/// responses more directly.
#[async_trait]
pub trait DataframeClientAPI: std::fmt::Debug + Clone + Send + Sync + Unpin + 'static {
    /// The server this client talks to, named in the errors it produces.
    fn origin(&self) -> &re_uri::Origin;

    async fn get_dataset_schema(
        &mut self,
        request: tonic::Request<GetDatasetSchemaRequest>,
    ) -> tonic::Result<tonic::Response<GetDatasetSchemaResponse>>;

    async fn query_dataset(
        &mut self,
        request: tonic::Request<re_protos::cloud::v1alpha1::QueryDatasetRequest>,
    ) -> tonic::Result<tonic::Response<tonic::codec::Streaming<QueryDatasetResponse>>>;

    async fn fetch_chunks(
        &mut self,
        request: tonic::Request<re_protos::cloud::v1alpha1::FetchChunksRequest>,
    ) -> tonic::Result<
        tonic::Response<tonic::codec::Streaming<re_protos::cloud::v1alpha1::FetchChunksResponse>>,
    >;
}

#[async_trait]
impl DataframeClientAPI for ConnectionClient {
    fn origin(&self) -> &re_uri::Origin {
        // The inherent `RedapClient::origin`, not this trait method.
        Self::origin(self)
    }

    async fn get_dataset_schema(
        &mut self,
        request: tonic::Request<GetDatasetSchemaRequest>,
    ) -> tonic::Result<tonic::Response<GetDatasetSchemaResponse>> {
        self.inner().get_dataset_schema(request).await
    }

    async fn query_dataset(
        &mut self,
        request: tonic::Request<re_protos::cloud::v1alpha1::QueryDatasetRequest>,
    ) -> tonic::Result<tonic::Response<tonic::codec::Streaming<QueryDatasetResponse>>> {
        self.inner().query_dataset(request).await
    }

    async fn fetch_chunks(
        &mut self,
        request: tonic::Request<re_protos::cloud::v1alpha1::FetchChunksRequest>,
    ) -> tonic::Result<
        tonic::Response<tonic::codec::Streaming<re_protos::cloud::v1alpha1::FetchChunksResponse>>,
    > {
        self.inner().fetch_chunks(request).await
    }
}

impl DataframeQueryTableProvider<ConnectionClient> {
    /// Create a table provider for a gRPC query. This function is async
    /// because we need to make gRPC calls to determine the schema at the
    /// creation of the table provider.
    ///
    /// If `arrow_schema` is `Some`, it is used directly and the `/GetDatasetSchema`
    /// RPC is skipped — useful when the caller has already fetched the schema.
    #[tracing::instrument(level = "info", skip_all)]
    pub async fn new(
        connection: ConnectionHandle,
        dataset_id: EntryId,
        query_expression: &QueryExpression,
        segment_ids: &[impl AsRef<str> + Sync],
        index_values: IndexValuesMap,
        arrow_schema: Option<Schema>,
        #[cfg(not(target_arch = "wasm32"))] trace_headers: Option<crate::TraceHeaders>,
        metrics_collectors: Vec<crate::MetricsCollector>,
    ) -> ApiResult<Self> {
        let origin = connection.origin().clone();
        let connection = connection.connection().await?;

        let mut provider = Self::new_from_client(
            connection.client,
            dataset_id,
            query_expression,
            segment_ids,
            index_values,
            arrow_schema,
            #[cfg(not(target_arch = "wasm32"))]
            trace_headers,
            metrics_collectors,
        )
        .await?;

        if let Some(exporter) = connection.analytics {
            let async_runtime = AsyncRuntimeHandle::from_current_tokio_runtime_or_wasmbindgen()
                .map_err(|err| {
                    ApiError::internal_with_source(
                        &origin,
                        None,
                        err,
                        "failed to capture the async runtime for query analytics",
                    )
                })?;
            provider.analytics = Some(crate::ConnectionAnalytics::new(exporter, async_runtime));
        }

        Ok(provider)
    }
}

impl<T: DataframeClientAPI> DataframeQueryTableProvider<T> {
    #[tracing::instrument(level = "info", skip_all)]
    pub async fn new_from_client(
        mut client: T,
        dataset_id: EntryId,
        query_expression: &QueryExpression,
        segment_ids: &[impl AsRef<str> + Sync],
        index_values: IndexValuesMap,
        arrow_schema: Option<Schema>,
        #[cfg(not(target_arch = "wasm32"))] trace_headers: Option<crate::TraceHeaders>,
        metrics_collectors: Vec<crate::MetricsCollector>,
    ) -> ApiResult<Self> {
        let origin = client.origin().clone();

        // Either use the caller-provided schema or fetch it from the server.
        let (schema, trace_id) = if let Some(schema) = arrow_schema {
            (schema, None)
        } else {
            let request = tonic::Request::new(GetDatasetSchemaRequest {}).with_entry_id(dataset_id);
            let response = client
                .get_dataset_schema(request)
                .await
                .map_err(|err| ApiError::tonic(&origin, err, "get_dataset_schema"))?;
            let trace_id = re_redap_client::extract_trace_id(response.metadata());
            let schema = response.into_inner().schema().map_err(|err| {
                ApiError::deserialization_with_source(
                    &origin,
                    trace_id,
                    err,
                    "decoding dataset schema",
                )
            })?;
            (schema, trace_id)
        };

        let schema = compute_schema_for_query(&schema, query_expression).map_err(|err| {
            // `compute_schema_for_query` fails when the caller-provided query
            // references columns/entity-paths not present in the dataset schema
            ApiError::invalid_arguments_with_source(
                &origin,
                trace_id,
                err,
                "computing schema for query",
            )
        })?;

        let entity_paths = query_expression
            .view_contents
            .as_ref()
            .map_or(vec![], |contents| {
                contents.keys().cloned().collect::<Vec<_>>()
            });

        // Preserve the `QueryExpression` distinction between:
        // - `view_contents=None`: all entities
        // - `view_contents=Some(empty)`: no entities
        //
        // Both cases produce an empty `entity_paths` list, so the explicit flag
        // must be driven from `view_contents` itself rather than the derived list.
        let select_all_entity_paths = query_expression.view_contents.is_none();

        let query = query_from_query_expression(
            query_expression,
            query_expression.sparse_fill_strategy != SparseFillStrategy::None,
        );
        let fuzzy_descriptors: Vec<String> = query_expression
            .view_contents
            .as_ref()
            .map_or(BTreeSet::new(), |contents| {
                contents
                    .values()
                    .filter_map(|opt_set| opt_set.as_ref())
                    .flat_map(|set| set.iter().copied())
                    .collect::<BTreeSet<_>>()
            })
            .into_iter()
            .map(|ident| ident.to_string())
            .collect();

        let query_dataset_request = QueryDatasetRequest {
            segment_ids: segment_ids
                .iter()
                .map(|id| id.as_ref().to_owned().into())
                .collect(),
            chunk_ids: vec![],
            entity_paths,
            select_all_entity_paths,
            fuzzy_descriptors,
            exclude_static_data: false,
            exclude_temporal_data: false,
            query: Some(query),
            scan_parameters: Some(ScanParameters {
                columns: FetchChunksRequest::required_column_names(),
                ..Default::default()
            }),
            // Skip server-side URL signing when the client is forced to fetch via gRPC —
            // signing would be wasted work and, on Azure, can fail outright with a 403
            // before the gRPC fetch path is ever reached.
            generate_direct_urls: !force_grpc(),
        };

        let schema = Arc::new(prepend_string_column_schema(
            &schema,
            ScanSegmentTableDataframe::COLUMN_RERUN_SEGMENT_ID_NAME,
        ));

        Ok(Self {
            schema,
            query_expression: query_expression.to_owned(),
            query_dataset_request,
            sort_index: query_expression.filtered_index,
            dataset_id,
            client,
            index_values,
            #[cfg(not(target_arch = "wasm32"))]
            trace_headers,
            analytics: None,
            metrics_collectors,
            filter_capture: Arc::new(Mutex::new(None)),
        })
    }

    /// Whether pushdown should synthesize a `latest_at` alongside its
    /// rewritten `range`. True iff the caller requested sparse-fill semantics
    /// — synthesizing `latest_at` under [`SparseFillStrategy::None`] would
    /// force an expensive server-side latest-at fan-out whose rows the
    /// caller has already opted out of.
    ///
    /// Same gate drives the entity-path projection narrowing block in `scan`
    /// (in its inverted form): both optimizations are only safe when no fill
    /// is requested.
    fn synthesize_latest_at(&self) -> bool {
        self.query_expression.sparse_fill_strategy != SparseFillStrategy::None
    }

    fn selector_from_column(column: &Column) -> Option<ComponentColumnSelector> {
        ComponentColumnSelector::from_str(column.name()).ok()
    }

    fn is_neq_null(expr: &Expr) -> Option<&Column> {
        match expr {
            Expr::IsNotNull(inner) => {
                if let Expr::Column(col) = inner.as_ref() {
                    return Some(col);
                }
            }
            Expr::Not(inner) => {
                if let Expr::IsNull(col_expr) = inner.as_ref()
                    && let Expr::Column(col) = col_expr.as_ref()
                {
                    return Some(col);
                }
            }
            Expr::BinaryExpr(binary) => {
                if binary.op == Operator::NotEq
                    && let (Expr::Column(col), Expr::Literal(sv, _))
                    | (Expr::Literal(sv, _), Expr::Column(col)) =
                        (binary.left.as_ref(), binary.right.as_ref())
                    && sv.is_null()
                {
                    return Some(col);
                }
            }
            _ => {}
        }

        None
    }

    /// For a given input expression, check to see if it can match the supported
    /// row filtering. We can currently filter out rows for which a specific
    /// component of one entity is not null. We do this by checking the column
    /// name matches the entity path and component naming conventions, which
    /// should always be true at the level of this call. We attempt to match
    /// a few different logically equivalent variants the user may pass.
    fn compute_column_is_neq_null_filter(
        filters: &[&Expr],
    ) -> Vec<Option<ComponentColumnSelector>> {
        filters
            .iter()
            .map(|expr| Self::is_neq_null(expr).and_then(Self::selector_from_column))
            .collect()
    }
}

#[async_trait]
impl<T: DataframeClientAPI> TableProvider for DataframeQueryTableProvider<T> {
    fn schema(&self) -> SchemaRef {
        Arc::clone(&self.schema)
    }

    fn table_type(&self) -> TableType {
        TableType::Base
    }

    async fn scan(
        &self,
        state: &dyn Session,
        projection: Option<&Vec<usize>>,
        filters: &[Expr],
        limit: Option<usize>,
    ) -> datafusion::common::Result<Arc<dyn ExecutionPlan>> {
        let scan_span = {
            // Attach trace context BEFORE creating the span so the span is
            // parented under the propagated trace
            #[cfg(not(target_arch = "wasm32"))]
            let _trace_guard =
                crate::dataframe_query_provider::attach_trace_context(self.trace_headers.as_ref());

            tracing::info_span!("scan")
        };

        async {
            let scan_start_wall = SystemTime::now();
            let scan_start = Instant::now();

            let synthesize_latest_at = self.synthesize_latest_at();
            let FilterCapture {
                total: filters_total,
                all_signatures: filters_signatures,
                exact_signatures: filters_signatures_exact,
                inexact_signatures: filters_signatures_inexact,
                unsupported_signatures: filters_signatures_unsupported,
            } = self.filter_capture.lock().take().unwrap_or_default();

            let mut dataset_queries = vec![self.query_dataset_request.clone()];
            let mut filters_pushed_down: usize = 0;
            let mut filters_applied_client_side: usize = 0;
            for filter in filters {
                match apply_filter_expr_to_queries(
                    dataset_queries.clone(),
                    filter,
                    &self.schema,
                    synthesize_latest_at,
                )? {
                    Some(updated_queries) => {
                        filters_pushed_down += 1;
                        dataset_queries = updated_queries;
                    }
                    None => {
                        filters_applied_client_side += 1;
                    }
                }
            }

            // Now that filter pushdown has settled each query's `segment_ids`, bound each query's chunk fetch
            // to its sampled index values.
            // Done here rather than at construction so the per-segment value lists stay aligned with `segment_ids` after a
            // `rerun_segment_id` predicate narrows or splits them.
            for query in &mut dataset_queries {
                apply_per_segment_pushdown(
                    query,
                    &self.index_values,
                    self.query_expression.filtered_index,
                );
            }

            // Entity path projection pushdown: narrow the server request to only
            // fetch chunks for entity paths that are actually needed by the projection
            // and filters. Skip when fill_latest_at is enabled, because timestamps
            // from excluded entities would produce rows with filled values that the
            // user expects.
            let mut entity_path_narrowing_applied = false;
            if !synthesize_latest_at
                && let Some(projected_paths) = projection.map(|projection| {
                    extract_projected_entity_paths(&self.schema, projection, filters)
                })
                && !projected_paths.is_empty()
            {
                for query in &mut dataset_queries {
                    if !query.select_all_entity_paths && !query.entity_paths.is_empty() {
                        let before = query.entity_paths.len();
                        query
                            .entity_paths
                            .retain(|path| projected_paths.contains(path));
                        if query.entity_paths.len() != before {
                            entity_path_narrowing_applied = true;
                        }
                    }
                }
            }

            // Component projection pushdown: narrow `fuzzy_descriptors` to the components the
            // projection and filters reference, so the server skips chunks for unselected ones
            // (e.g. a heavy `VideoStream:sample` next to a tiny `is_keyframe`). Gated on
            // `SparseFillStrategy::None`, like the entity-path narrowing above.
            //
            // Only narrow on a strict subset. An empty list means "all components" server-side,
            // and a full read projects every column, so listing all of them would be a no-op
            // were it not that the server treats a non-empty list as exhaustive and drops
            // static-only components (those with no temporal index). Leaving it empty is correct.
            //
            // TODO(RR-3157): ideally `DatasetView` would let users select components explicitly,
            // so we wouldn't have to infer them from the query.
            if self.query_expression.sparse_fill_strategy == SparseFillStrategy::None
                && let Some(projected_components) = projection.map(|projection| {
                    extract_projected_components(&self.schema, projection, filters)
                })
                && !projected_components.is_empty()
                && projected_components.len() < all_schema_components(&self.schema).len()
            {
                for query in &mut dataset_queries {
                    if query.fuzzy_descriptors.is_empty() {
                        query.fuzzy_descriptors = projected_components.iter().cloned().collect();
                    }
                }
            }

            let mut query_expression = self.query_expression.clone();

            let mut chunk_info_batches = Vec::with_capacity(dataset_queries.len());
            let mut time_to_first_chunk_info: Option<Duration> = None;

            let mut trace_id: Option<opentelemetry::TraceId> = None;

            // These are independent read-only queries, so fan them out with
            // bounded concurrency (`query_dataset_fanout`). Order doesn't
            // matter: the batches are concatenated and deduplicated by chunk id
            // below.
            let queries_start = Instant::now();
            let mut response_futures = futures::stream::iter(dataset_queries)
                .map(|dataset_query| {
                    let client = self.client.clone();
                    let origin = client.origin().clone();
                    let dataset_id = self.dataset_id;
                    async move {
                        // Hold a process-wide permit for the whole open+drain so
                        // co-tenant queries share one ceiling on concurrent
                        // `query_dataset` streams (the fan-out width alone only
                        // bounds a single scan). Dropped when this task ends.
                        #[cfg(not(target_arch = "wasm32"))]
                        let _permit = crate::pipeline_budget::query_dataset_semaphore()
                            .acquire()
                            .await
                            .expect("query_dataset semaphore is never closed");

                        // Build the proto request once, then clone it per retry attempt
                        // (`tonic::Request` isn't `Clone`). The server rejects `QueryDataset`
                        // with `ResourceExhausted` fail-fast (before any work) when its
                        // stream-concurrency limiter is saturated, so retrying the open is
                        // idempotent. Map tonic → `ApiError` *inside* the retry so the predicate
                        // sees `ResourcesExhausted`, and to `DataFusionError` *outside*.
                        let proto_request: re_protos::cloud::v1alpha1::QueryDatasetRequest =
                            dataset_query.into();
                        let response =
                            re_redap_client::with_retry_resource_exhausted("query_dataset", || {
                                let mut client = client.clone();
                                let origin = origin.clone();
                                let request = tonic::Request::new(proto_request.clone())
                                    .with_entry_id(dataset_id);
                                async move {
                                    client.query_dataset(request).await.map_err(|err| {
                                        ApiError::tonic(&origin, err, "query_dataset")
                                    })
                                }
                            })
                            .await
                            .map_err(|err| err.into_df_error())?;

                        // Capture the server-side trace-id from response metadata.
                        let trace_id = re_redap_client::extract_trace_id(response.metadata());

                        let mut response_stream = response.into_inner();
                        let mut batches = Vec::new();
                        let mut time_to_first: Option<Duration> = None;

                        while let Some(response) = response_stream.next().await {
                            if time_to_first.is_none() {
                                time_to_first = Some(queries_start.elapsed());
                            }

                            let response = response.map_err(|err| {
                                ApiError::tonic(&origin, err, "query_dataset response stream")
                                    .with_trace_id(trace_id)
                                    .into_df_error()
                            })?;
                            let Some(dataframe_part) = response.data else {
                                continue;
                            };
                            let batch: RecordBatch = dataframe_part.try_into().map_err(|err| {
                                ApiError::deserialization_with_source(
                                    &origin,
                                    trace_id,
                                    err,
                                    "decoding query_dataset response batch",
                                )
                                .into_df_error()
                            })?;

                            batches.push(batch);
                        }

                        Ok::<_, DataFusionError>((batches, time_to_first, trace_id))
                    }
                })
                .buffer_unordered(query_dataset_fanout());

            while let Some(result) = response_futures.next().await {
                let (batches, time_to_first, response_trace_id) = result?;

                if trace_id.is_none() {
                    trace_id = response_trace_id;
                }
                // Time to first chunk info is the earliest first-response across
                // all concurrent queries, measured from the shared fan-out start.
                time_to_first_chunk_info = match (time_to_first_chunk_info, time_to_first) {
                    (Some(current), Some(candidate)) => Some(current.min(candidate)),
                    (existing, candidate) => existing.or(candidate),
                };

                chunk_info_batches.extend(batches);
            }
            let chunk_info_batches = compute_unique_chunk_info_ids(chunk_info_batches)?;

            // Build the planning-phase summary unconditionally — it feeds both the
            // analytics span (when enabled) and the `MetricsSet` on the resulting
            // `SegmentStreamExec` (always).
            let agg = chunk_info_batches
                .as_ref()
                .map(compute_chunk_info_aggregates)
                .unwrap_or_default();
            let target_partitions = state.config().target_partitions();
            let query_info = QueryInfo {
                dataset_id: self.dataset_id.to_string(),
                query_chunks: agg.chunks,
                query_segments: agg.segments,
                query_layers: agg.layers,
                query_columns: self.schema.fields().len(),
                query_entities: self.query_dataset_request.entity_paths.len(),
                query_bytes: agg.bytes,
                target_partitions,
                query_chunks_per_segment_min: agg.chunks_per_segment_min,
                query_chunks_per_segment_max: agg.chunks_per_segment_max,
                query_chunks_per_segment_mean: agg.chunks_per_segment_mean,
                query_type: QueryType::classify(&self.query_expression),
                primary_index_name: self
                    .query_expression
                    .filtered_index
                    .map(|i| i.as_str().to_owned()),
                time_to_first_chunk_info,
                trace_id,
                filters_pushed_down,
                filters_applied_client_side,
                entity_path_narrowing_applied,
                filters_total,
                filters_signatures,
                filters_signatures_exact,
                filters_signatures_inexact,
                filters_signatures_unsupported,
            };

            // Begin analytics tracking. This also constructs the plan's
            // `QueryMetrics` (fetch counters + ad-hoc `EXPLAIN ANALYZE`
            // MetricsSet), owned by the analytics struct as the single source
            // of truth — `SegmentStreamExec` reads it through
            // `PendingQueryAnalytics::metrics`. The PostHog OTLP send is gated
            // by `self.analytics.is_some()`; the resulting struct is always
            // returned so the `metrics_capture` subscribers and DataFusion
            // `metrics()` see the same data.
            let pending_analytics = crate::analytics::begin_query(
                self.analytics.clone(),
                query_info,
                scan_start,
                scan_start_wall,
            );

            // Find the first column selection that is a component
            if query_expression.filtered_is_not_null.is_none() {
                let filters = filters.iter().collect::<Vec<_>>();
                query_expression.filtered_is_not_null =
                    Self::compute_column_is_neq_null_filter(&filters)
                        .into_iter()
                        .flatten()
                        .next();
            }

            // `SegmentStreamExec` already emits batches sized by
            // `DEFAULT_BATCH_ROWS` / `DEFAULT_BATCH_BYTES` directly in
            // `dataframe_query_provider::send_next_row_batch`. We still wrap
            // it in `SizedCoalesceBatchesExec`: with the source-side sizing
            // the coalescer is mostly a pass-through, but it acts as a
            // physical-plan boundary that DataFusion's optimizer relies on
            // (removing it has been observed to confuse downstream sort /
            // projection nodes that reference `rerun_segment_id`).
            SegmentStreamExec::try_new(
                &self.schema,
                self.sort_index,
                projection,
                target_partitions,
                chunk_info_batches,
                query_expression,
                self.index_values.clone(),
                self.client.clone(),
                limit,
                #[cfg(not(target_arch = "wasm32"))]
                self.trace_headers.clone(),
                #[cfg(not(target_arch = "wasm32"))]
                trace_id,
                pending_analytics,
                self.metrics_collectors.clone(),
            )
            .map(Arc::new)
            .map(|exec| {
                Arc::new(SizedCoalesceBatchesExec::new(
                    exec,
                    CoalescerOptions {
                        target_batch_rows: DEFAULT_BATCH_ROWS,
                        target_batch_bytes: DEFAULT_BATCH_BYTES,
                        max_rows: limit,
                    },
                )) as Arc<dyn ExecutionPlan>
            })
        }
        .instrument(scan_span)
        .await
    }

    fn supports_filters_pushdown(
        &self,
        filters: &[&Expr],
    ) -> datafusion::common::Result<Vec<TableProviderFilterPushDown>> {
        let filter_columns = Self::compute_column_is_neq_null_filter(filters);
        let non_null_columns = filter_columns.iter().flatten().collect::<Vec<_>>();
        let synthesize_latest_at = self.synthesize_latest_at();
        let results: Vec<TableProviderFilterPushDown> = if let Some(col) = non_null_columns.first()
        {
            let col = *col;
            std::iter::zip(&filter_columns, filters)
                .map(|(column_selector, filter_expr)| {
                    if Some(col) == column_selector.as_ref() {
                        Ok(TableProviderFilterPushDown::Exact)
                    } else {
                        filter_expr_is_supported(
                            filter_expr,
                            &self.query_dataset_request,
                            &self.schema,
                            synthesize_latest_at,
                        )
                    }
                })
                .try_collect()?
        } else {
            filters
                .iter()
                .map(|filter_expr| {
                    filter_expr_is_supported(
                        filter_expr,
                        &self.query_dataset_request,
                        &self.schema,
                        synthesize_latest_at,
                    )
                })
                .try_collect()?
        };

        let mut all_sigs: Vec<String> = Vec::with_capacity(filters.len());
        let mut exact_sigs: Vec<String> = Vec::new();
        let mut inexact_sigs: Vec<String> = Vec::new();
        let mut unsupported_sigs: Vec<String> = Vec::new();
        for (filter, result) in std::iter::zip(filters, &results) {
            let sig = expr_filter_signature(filter);
            all_sigs.push(sig.clone());
            match result {
                TableProviderFilterPushDown::Exact => exact_sigs.push(sig),
                TableProviderFilterPushDown::Inexact => inexact_sigs.push(sig),
                TableProviderFilterPushDown::Unsupported => unsupported_sigs.push(sig),
            }
        }
        *self.filter_capture.lock() = Some(FilterCapture {
            total: filters.len() as u32,
            all_signatures: all_sigs.join(";"),
            exact_signatures: exact_sigs.join(";"),
            inexact_signatures: inexact_sigs.join(";"),
            unsupported_signatures: unsupported_sigs.join(";"),
        });

        Ok(results)
    }
}

/// Bound a single settled query's server-side chunk scan to the chunks covering
/// its sampled index values, by setting them as `QueryLatestAt.per_segment_values`
/// (aligned to the query's own `segment_ids`).
///
/// Runs in [`DataframeQueryTableProvider::scan`] *after* filter pushdown has
/// narrowed or split `segment_ids`, so the per-segment value lists always line up
/// with the segment ids the server validates against. Without it the server
/// fetches every segment's entire chunk set; it narrows only what is fetched, not
/// the rows produced.
fn apply_per_segment_pushdown(
    query_request: &mut QueryDatasetRequest,
    index_values: &IndexValuesMap,
    timeline: Option<Index>,
) {
    let Some(index_values) = index_values.as_ref() else {
        return; // no `using_index_values`, nothing to push
    };
    let Some(timeline) = timeline else {
        return; // static-only query, no index to bound
    };
    // The contract requires non-empty, positionally-matched segment ids. An
    // unscoped reader (no `filter_segments`) sends none, so there is nothing to
    // align against.
    if query_request.segment_ids.is_empty() {
        return;
    }
    let per_segment_values = per_segment_values_aligned(&query_request.segment_ids, index_values);

    let Some(query) = query_request.query.as_mut() else {
        return;
    };
    query.latest_at = Some(QueryLatestAt {
        index: Some(timeline),
        at: IndexValue::STATIC,
        per_segment_values,
    });
    query.range = None;
}

/// Build `QueryLatestAt.per_segment_values` for `segment_ids`, looking each up in `index_values`.
///
/// One list per segment, in order, since the server matches them positionally against `QueryDatasetRequest.segment_ids`.
/// Segments absent from the map get an empty list and `STATIC` values are skipped.
fn per_segment_values_aligned(
    segment_ids: &[SegmentId],
    index_values: &BTreeMap<SegmentId, BTreeSet<IndexValue>>,
) -> Vec<Vec<i64>> {
    segment_ids
        .iter()
        .map(|segment_id| {
            index_values
                .get(segment_id)
                .map(|values| {
                    values
                        .iter()
                        .filter(|value| !value.is_static())
                        .map(|value| value.as_i64())
                        .collect()
                })
                .unwrap_or_default()
        })
        .collect()
}

/// Build a server-side [`Query`] from a [`QueryExpression`].
///
/// `synthesize_latest_at` controls whether a non-static query carries a
/// `latest_at` derived from [`QueryExpression::min_latest_at`]. Pass `true`
/// when the caller wants sparse-fill semantics
/// ([`SparseFillStrategy::LatestAtGlobal`]); pass `false` (the common case,
/// [`SparseFillStrategy::None`]) to skip — without fill, the `range` already
/// carries everything the server needs and the synthesized `latest_at` would
/// only drive an expensive latest-at fan-out for rows the caller has opted
/// out of.
///
/// Static-only queries ([`QueryExpression::is_static`]) always carry
/// [`QueryLatestAt::new_static`] regardless of the flag — that marker is the
/// sole signal the server uses to filter to static chunks; stripping it
/// would turn a static-only request into a full-dataset scan.
pub fn query_from_query_expression(
    query_expression: &QueryExpression,
    synthesize_latest_at: bool,
) -> Query {
    let latest_at = if query_expression.is_static() {
        Some(QueryLatestAt::new_static())
    } else if synthesize_latest_at {
        query_expression
            .min_latest_at()
            .map(|latest_at| QueryLatestAt::global(latest_at.timeline(), latest_at.at()))
    } else {
        None
    };

    Query {
        latest_at,
        range: query_expression.max_range().map(|range| QueryRange {
            index: *range.timeline(),
            index_range: range.range,
        }),
        columns_always_include_everything: false,
        columns_always_include_entity_paths: false,
        columns_always_include_byte_offsets: true, // so we know exactly what to fetch from direct URLs
        columns_always_include_static_indexes: false,
        columns_always_include_global_indexes: false,
        columns_always_include_component_indexes: false,
    }
}

fn compute_unique_chunk_info_ids(
    chunk_info_batches: Vec<RecordBatch>,
) -> Result<Option<RecordBatch>, DataFusionError> {
    if chunk_info_batches.is_empty() {
        return Ok(None);
    }

    // Merge by column *name*, not by position: a `query_dataset` response schema is only
    // pinned by name (that is what `QueryDatasetDataframe::COLUMN_*` extraction relies on),
    // and the batches we get here come from several independent responses — one per fan-out
    // branch, each free to carry a different column order and a different set of optional
    // columns (`chunk_byte_offset`, `{timeline}:start`, …). A branch that selected nothing
    // typically answers with the server's fallback empty batch, whose columns are neither
    // ordered nor shaped like the populated branches'. Concatenating those positionally
    // either fails outright (`It is not possible to concatenate arrays of different data
    // types (Utf8, Boolean)`) or, worse, silently pairs up same-typed but unrelated columns.
    let combined = re_arrow_util::concat_polymorphic_batches(&chunk_info_batches)
        .map_err(|err| exec_datafusion_err!("merging chunk-info batches: {err}"))?;
    let schema = combined.schema();
    drop(chunk_info_batches);

    let chunk_ids = QueryDatasetDataframe::COLUMN_CHUNK_ID
        .extract(&combined)
        .map_err(|err| exec_datafusion_err!("{err}"))?;

    let mut indices_to_keep = Vec::new();
    let mut seen: HashSet<[u8; 16]> = HashSet::default();

    for (row_idx, chunk_id) in chunk_ids.iter().enumerate() {
        if seen.insert(*chunk_id) {
            indices_to_keep.push(row_idx as u32);
        }
    }

    let indices = UInt32Array::from(indices_to_keep);

    let distinct_columns = arrow::compute::take_arrays(combined.columns(), &indices, None)?;

    Ok(Some(RecordBatch::try_new_with_options(
        schema,
        distinct_columns,
        &RecordBatchOptions::default(),
    )?))
}

#[cfg(test)]
mod tests {
    use std::{collections::HashMap, iter::once};

    use arrow::datatypes::{DataType, Field};

    use super::*;

    #[test]
    fn per_segment_values_align_to_segment_ids_order() {
        let seg = |s: &str| SegmentId::from(s);
        let at = IndexValue::new_temporal;

        let index_values: BTreeMap<SegmentId, BTreeSet<IndexValue>> = [
            (seg("a"), BTreeSet::from([at(30), at(10), at(20)])),
            (seg("b"), BTreeSet::from([at(5)])),
        ]
        .into_iter()
        .collect();

        // Output is positionally matched to `segment_ids`
        // "b" comes first here, and "c" (absent from the map) yields an empty list rather than being skipped.
        let segment_ids = [seg("b"), seg("a"), seg("c")];
        let values = per_segment_values_aligned(&segment_ids, &index_values);

        assert_eq!(values, vec![vec![5], vec![10, 20, 30], vec![]]);
    }

    #[test]
    fn per_segment_values_skip_static() {
        let index_values: BTreeMap<SegmentId, BTreeSet<IndexValue>> = std::iter::once((
            SegmentId::from("a"),
            BTreeSet::from([IndexValue::STATIC, IndexValue::new_temporal(7)]),
        ))
        .collect();

        let values = per_segment_values_aligned(&[SegmentId::from("a")], &index_values);

        assert_eq!(values, vec![vec![7]]);
    }

    /// Per-segment pushdown stays aligned with `segment_ids` when a
    /// `rerun_segment_id` predicate narrows them, and rewrites the survivor into
    /// the bounded encoding: sorted `per_segment_values`, `range` dropped, and `at`
    /// parked at STATIC against the query's index.
    #[test]
    fn segment_id_filter_keeps_per_segment_values_aligned() {
        use datafusion::logical_expr::{col, lit};

        let seg = |s: &str| SegmentId::from(s);
        let at = IndexValue::new_temporal;
        let timeline = Index::from("my_index");

        // Three scoped segments, each sampled at specific index values, as set by
        // `filter_segments([…]).reader(using_index_values={…})`.
        let segment_ids = vec![seg("a"), seg("b"), seg("c")];
        // "b" carries two values so the survivor exercises sorted multi-value emission.
        let map: BTreeMap<SegmentId, BTreeSet<IndexValue>> = [
            (seg("a"), BTreeSet::from([at(10), at(20)])),
            (seg("b"), BTreeSet::from([at(15), at(5)])),
            (seg("c"), BTreeSet::from([at(7), at(8)])),
        ]
        .into_iter()
        .collect();
        let index_values: IndexValuesMap = Some(Arc::new(map));

        // Baseline request as built before any pushdown: a temporal `range`, and
        // no `per_segment_values` yet (the pushdown is deferred to `scan`).
        let request = QueryDatasetRequest {
            segment_ids: segment_ids.clone(),
            query: Some(Query {
                latest_at: None,
                range: Some(QueryRange {
                    index: timeline,
                    index_range: re_log_types::AbsoluteTimeRange::new(at(0), at(100)),
                }),
                ..Default::default()
            }),
            ..Default::default()
        };

        // 1. A `WHERE rerun_segment_id = 'b'` predicate is pushed down, narrowing
        //    `segment_ids` exactly as `scan`'s filter loop does. (The index field's
        //    `rerun:kind=index` metadata is irrelevant to a segment-id predicate,
        //    but mirrors a real query schema.)
        let schema = {
            let mut index_meta = HashMap::new();
            index_meta.insert(
                re_sorbet::metadata::RERUN_KIND.to_owned(),
                "index".to_owned(),
            );
            Arc::new(Schema::new_with_metadata(
                vec![
                    Field::new("my_index", DataType::Int64, false).with_metadata(index_meta),
                    Field::new("rerun_segment_id", DataType::Utf8, false),
                ],
                HashMap::default(),
            ))
        };
        let expr = col("rerun_segment_id").eq(lit("b"));
        let mut narrowed = apply_filter_expr_to_queries(vec![request], &expr, &schema, false)
            .unwrap()
            .expect("segment-id predicate is pushed down");
        assert_eq!(narrowed.len(), 1);

        // 2. Per-segment pushdown runs after narrowing and aligns to the survivor.
        apply_per_segment_pushdown(&mut narrowed[0], &index_values, Some(timeline));

        let narrowed = &narrowed[0];
        assert_eq!(narrowed.segment_ids, vec![seg("b")]);

        // `per_segment_values` is aligned to the surviving segment "b" → `[[5, 15]]`
        // (sorted), not the stale full `[[10, 20], [5, 15], [7, 8]]`. `range` is
        // cleared and `at` parked at STATIC against the query's index — the encoding
        // required alongside `per_segment_values`.
        let query = narrowed.query.as_ref().unwrap();
        let la = query.latest_at.as_ref().unwrap();
        assert_eq!(
            la.per_segment_values,
            vec![vec![5, 15]],
            "per_segment_values must align to the surviving segment_ids, sorted"
        );
        assert_eq!(la.index, Some(timeline));
        assert_eq!(la.at, IndexValue::STATIC);
        assert!(query.range.is_none());

        let wire: re_protos::cloud::v1alpha1::QueryDatasetRequest = narrowed.clone().into();
        re_protos::cloud::v1alpha1::ext::QueryDatasetRequest::try_from(wire)
            .expect("server must accept the request after segment-id narrowing");
    }

    /// `apply_per_segment_pushdown` only fires for a scoped temporal query with
    /// sampled values. Every other case leaves the request untouched, so the
    /// server falls back to its normal full per-segment scan.
    #[test]
    fn pushdown_is_noop_unless_scoped_temporal() {
        let seg = |s: &str| SegmentId::from(s);
        let timeline = Index::from("my_index");
        let values: IndexValuesMap = Some(Arc::new(
            once((seg("a"), BTreeSet::from([IndexValue::new_temporal(10)]))).collect(),
        ));

        let baseline = || QueryDatasetRequest {
            segment_ids: vec![seg("a")],
            query: Some(Query {
                latest_at: None,
                range: Some(QueryRange {
                    index: timeline,
                    index_range: re_log_types::AbsoluteTimeRange::new(
                        IndexValue::new_temporal(0),
                        IndexValue::new_temporal(100),
                    ),
                }),
                ..Default::default()
            }),
            ..Default::default()
        };

        let assert_untouched = |request: &QueryDatasetRequest| {
            let query = request.query.as_ref().unwrap();
            assert!(query.range.is_some(), "range must survive a no-op");
            assert!(
                query.latest_at.is_none(),
                "no `per_segment_values` must be pushed on a no-op"
            );
        };

        // No `using_index_values`.
        let no_values: IndexValuesMap = None;
        let mut req = baseline();
        apply_per_segment_pushdown(&mut req, &no_values, Some(timeline));
        assert_untouched(&req);

        // Static-only query: no index to bound against.
        let mut req = baseline();
        apply_per_segment_pushdown(&mut req, &values, None);
        assert_untouched(&req);

        // Unscoped reader: no `segment_ids` to align values to.
        let mut req = baseline();
        req.segment_ids.clear();
        apply_per_segment_pushdown(&mut req, &values, Some(timeline));
        assert_untouched(&req);
    }

    // -------------------------------------------------------------------
    // `query_from_query_expression` — gating of `latest_at` synthesis on
    // `synthesize_latest_at` for the user-supplied-range path. This is the
    // path that previously had NO coverage: a `QueryExpression` carrying a
    // `filtered_index_range` (or `filtered_index_values` / `using_index_values`)
    // with `sparse_fill_strategy = None`. Pre-altitude-fix, this path would
    // ship `latest_at=Some(...)` to the server because `min_latest_at()`
    // populated it unconditionally — the scrub helper was the safety net.
    // Post-fix, `synthesize_latest_at=false` must drop the latest_at at
    // construction; the static-only marker must survive regardless.
    // -------------------------------------------------------------------

    #[test]
    fn test_query_from_expr_user_supplied_range_no_fill_drops_latest_at() {
        use re_log_types::{AbsoluteTimeRange, TimeInt};

        let query_expression = QueryExpression {
            view_contents: None,
            filtered_index: Some("frame_nr".into()),
            filtered_index_range: Some(AbsoluteTimeRange::new(
                TimeInt::new_temporal(100),
                TimeInt::new_temporal(200),
            )),
            sparse_fill_strategy: SparseFillStrategy::None,
            ..Default::default()
        };

        let query = super::query_from_query_expression(&query_expression, false);

        assert!(
            query.latest_at.is_none(),
            "user-supplied range with sparse_fill=None must not ship latest_at",
        );
        let range = query.range.as_ref().expect("range must be set");
        assert_eq!(
            range.index_range,
            AbsoluteTimeRange {
                min: TimeInt::new_temporal(100),
                max: TimeInt::new_temporal(200),
            },
            "range must come from filtered_index_range verbatim",
        );
    }

    #[test]
    fn test_query_from_expr_user_supplied_range_fill_keeps_latest_at() {
        use re_log_types::{AbsoluteTimeRange, TimeInt};

        let query_expression = QueryExpression {
            view_contents: None,
            filtered_index: Some("frame_nr".into()),
            filtered_index_range: Some(AbsoluteTimeRange::new(
                TimeInt::new_temporal(100),
                TimeInt::new_temporal(200),
            )),
            sparse_fill_strategy: SparseFillStrategy::LatestAtGlobal,
            ..Default::default()
        };

        let query = super::query_from_query_expression(&query_expression, true);

        let la = query
            .latest_at
            .as_ref()
            .expect("LatestAtGlobal must ship latest_at");
        assert_eq!(la.at, TimeInt::new_temporal(100));
        assert!(
            la.index.is_some(),
            "non-static latest_at must carry timeline"
        );
        assert!(query.range.is_some(), "range must still be set");
    }

    #[test]
    fn test_query_from_expr_static_preserves_new_static_regardless_of_flag() {
        // `filtered_index = None` ⇒ `is_static() = true` ⇒ `latest_at` must
        // be `new_static()` even when `synthesize_latest_at=false`. The
        // static marker is the sole signal the server uses to filter to
        // static chunks; stripping it turns a static-only request into a
        // full-dataset scan.
        let query_expression = QueryExpression {
            view_contents: None,
            filtered_index: None,
            sparse_fill_strategy: SparseFillStrategy::None,
            ..Default::default()
        };

        let query = super::query_from_query_expression(&query_expression, false);

        let la = query
            .latest_at
            .as_ref()
            .expect("static-only must carry new_static() latest_at");
        assert!(
            la.is_static(),
            "latest_at must be `new_static()` for static-only queries even when \
             synthesize_latest_at=false",
        );
        assert!(query.range.is_none(), "static-only must have no range");
    }
}
