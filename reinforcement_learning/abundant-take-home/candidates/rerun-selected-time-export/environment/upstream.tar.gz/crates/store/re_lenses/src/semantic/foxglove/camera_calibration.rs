use crate::{CastTo, Lens, LensBuilderError, op};
use re_lenses_core::Selector;
use re_log_types::TimeType;
use re_sdk_types::archetypes::Pinhole;

use crate::semantic::helpers::row_major_3x3_to_column_major;

use super::{FOXGLOVE_TIMESTAMP, IMAGE_PLANE_SUFFIX};

/// Creates a lens for [`foxglove.CameraCalibration`] messages.
///
/// [`foxglove.CameraCalibration`]: https://docs.foxglove.dev/docs/sdk/schemas/camera-calibration
pub fn camera_calibration(time_type: TimeType) -> Result<Lens, LensBuilderError> {
    Lens::derive("foxglove.CameraCalibration:message")
        .to_timeline(
            FOXGLOVE_TIMESTAMP,
            time_type,
            Selector::parse(".timestamp")?.pipe(op::timespec_to_nanos()),
        )
        .to_component(
            Pinhole::descriptor_child_frame(),
            Selector::parse(".frame_id")?.pipe(op::string_suffix_nonempty(IMAGE_PLANE_SUFFIX)),
        )
        .to_component_with_cast(
            Pinhole::descriptor_resolution(),
            Selector::parse("pack(.width!, .height!)")?,
            CastTo::Auto,
        )
        .to_component(
            Pinhole::descriptor_image_from_camera(),
            Selector::parse(".K")?.pipe(row_major_3x3_to_column_major()),
        )
        .to_component(
            Pinhole::descriptor_parent_frame(),
            Selector::parse(".frame_id")?,
        )
        .build()
}
