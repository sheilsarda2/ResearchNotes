use std::collections::BTreeMap;

use super::MessageDecoder;
use crate::parsers::MessageParser;
use crate::parsers::ros2msg::Ros2MessageParser;
use crate::parsers::ros2msg::sensor_msgs::{
    BatteryStateMessageParser, ImuMessageParser, JointStateMessageParser, JoyMessageParser,
    PointCloud2MessageParser, RangeMessageParser,
};
use crate::parsers::ros2msg::std_msgs::{
    Float64ArrayMessageParser, Float64MultiArrayMessageParser,
};

type ParserFactory = fn(usize) -> Box<dyn MessageParser>;

#[derive(Debug)]
pub struct McapRos2Decoder {
    registry: BTreeMap<String, ParserFactory>,
}

impl McapRos2Decoder {
    const ENCODING: &str = "ros2msg";

    fn empty() -> Self {
        Self {
            registry: BTreeMap::new(),
        }
    }

    /// Creates a new [`McapRos2Decoder`] with all supported message types pre-registered
    pub fn new() -> Self {
        Self::empty()
            // sensor_msgs
            .register_parser::<BatteryStateMessageParser>("sensor_msgs/msg/BatteryState")
            .register_parser::<ImuMessageParser>("sensor_msgs/msg/Imu")
            .register_parser::<JoyMessageParser>("sensor_msgs/msg/Joy")
            .register_parser::<JointStateMessageParser>("sensor_msgs/msg/JointState")
            .register_parser::<PointCloud2MessageParser>("sensor_msgs/msg/PointCloud2")
            .register_parser::<RangeMessageParser>("sensor_msgs/msg/Range")
            // std_msgs
            .register_parser::<Float64ArrayMessageParser>("std_msgs/msg/Float64Array")
            .register_parser::<Float64MultiArrayMessageParser>("std_msgs/msg/Float64MultiArray")
    }

    /// Registers a new message parser for the given schema name
    pub fn register_parser<T: Ros2MessageParser + 'static>(mut self, schema_name: &str) -> Self {
        self.registry
            .insert(schema_name.to_owned(), |n| Box::new(T::new(n)));
        self
    }

    /// Registers a message parser with a custom factory function
    pub fn register_parser_with_factory(
        mut self,
        schema_name: &str,
        factory: ParserFactory,
    ) -> Self {
        self.registry.insert(schema_name.to_owned(), factory);
        self
    }

    /// Returns true if the given schema is supported by this decoder
    pub fn supports_schema(&self, schema_name: &str) -> bool {
        self.registry.contains_key(schema_name)
    }
}

impl Default for McapRos2Decoder {
    fn default() -> Self {
        Self::new()
    }
}

impl MessageDecoder for McapRos2Decoder {
    fn identifier() -> super::DecoderIdentifier {
        "ros2msg".into()
    }

    fn supports_channel(&self, channel: &mcap::Channel<'_>) -> bool {
        let Some(schema) = channel.schema.as_ref() else {
            return false;
        };

        if !self.registry.contains_key(&schema.name) {
            return false;
        }

        supports_ros2_cdr_channel(channel)
    }

    fn message_parser(
        &self,
        channel: &mcap::Channel<'_>,
        num_rows: usize,
    ) -> Option<Box<dyn MessageParser>> {
        let schema = channel.schema.as_ref()?;
        if schema.encoding.as_str() != Self::ENCODING {
            return None;
        }

        if let Some(make) = self.registry.get(&schema.name) {
            Some(make(num_rows))
        } else {
            re_log::warn_once!(
                "Message schema {:?} is currently not supported",
                schema.name
            );

            None
        }
    }
}

fn is_cdr_message_encoding(message_encoding: &str) -> bool {
    message_encoding.eq_ignore_ascii_case("cdr")
}

/// Returns true for channels that explicitly advertise CDR payloads.
pub(super) fn is_cdr_encoded_channel(channel: &mcap::Channel<'_>) -> bool {
    is_cdr_message_encoding(&channel.message_encoding)
}

/// Warns once if a ROS2 schema is not encoded as CDR.
pub(super) fn warn_if_ros2msg_non_cdr_channel(channel: &mcap::Channel<'_>) {
    // Note: empty encodings have a separate, ROS-independent warning.
    if channel.message_encoding.trim().is_empty()
        || is_cdr_message_encoding(&channel.message_encoding)
    {
        return;
    }

    re_log::warn_once!(
        concat!(
            "MCAP channel '{}' has a ROS2 message schema, but unknown encoding '{}'. ",
            "ROS 2 deserialization is only supported for CDR-encoded messages."
        ),
        channel.topic,
        channel.message_encoding,
    );
}

/// Returns true if the channel carries a ROS2 message schema with CDR payloads.
pub(super) fn supports_ros2_cdr_channel(channel: &mcap::Channel<'_>) -> bool {
    let Some(schema) = channel.schema.as_ref() else {
        return false;
    };

    if schema.encoding.as_str() != McapRos2Decoder::ENCODING {
        return false;
    }

    if !is_cdr_encoded_channel(channel) {
        warn_if_ros2msg_non_cdr_channel(channel);
        return false;
    }

    true
}
