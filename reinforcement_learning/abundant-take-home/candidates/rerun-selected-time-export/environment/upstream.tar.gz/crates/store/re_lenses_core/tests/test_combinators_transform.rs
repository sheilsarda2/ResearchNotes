mod util;

use std::str::FromStr as _;
use std::sync::Arc;

use arrow::array::{
    ArrayRef, Float32Array, Float64Array, Int32Builder, ListArray, ListBuilder, StructArray,
    UInt8Array,
};
use arrow::buffer::OffsetBuffer;
use arrow::datatypes::{DataType, Field, Fields};
use re_lenses_core::Selector;
use re_lenses_core::combinators::{
    Error, Flatten, ListToFixedSizeList, MapFixedSizeList, MapList, MapPrimitive, PrimitiveCast,
    ReplaceNull, RowMajorToColumnMajor, StructToFixedList, Transform as _, try_downcast,
};
use util::DisplayRB;

use crate::util::fixtures;

#[test]
fn simple() -> Result<(), Box<dyn std::error::Error>> {
    let array = fixtures::nested_list_struct_column();
    println!("{}", DisplayRB(array.clone()));

    let pipeline = Selector::from_str(".poses[]")?.pipe(
        |source: &ArrayRef| -> Result<Option<ArrayRef>, Error> {
            let struct_array = try_downcast::<StructArray>(source, "struct_to_fixed_list pipe")?;
            Ok(StructToFixedList::new(["x", "y"])
                .transform(struct_array)?
                .map(|arr| Arc::new(arr) as ArrayRef))
        },
    );

    let result: ListArray = pipeline.execute_per_row(&array)?.unwrap();

    insta::assert_snapshot!(format!("{}", DisplayRB(result.clone())), @r"
    ┌────────────────────────────────────────┐
    │ col                                    │
    │ ---                                    │
    │ type: List(FixedSizeList(2 x Float64)) │
    ╞════════════════════════════════════════╡
    │ [[1.0, 2.0], [3.0, 4.0]]               │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[5.0, 6.0]]                           │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                                   │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[7.0, null], [9.0, 10.0]]             │
    └────────────────────────────────────────┘
    ");

    Ok(())
}

#[test]
fn add_one_to_leaves() -> Result<(), Box<dyn std::error::Error>> {
    let array = fixtures::nested_list_struct_column();
    println!("{}", DisplayRB(array.clone()));

    let pipeline = Selector::from_str(".poses[]")?.pipe(
        |source: &ArrayRef| -> Result<Option<ArrayRef>, Error> {
            let struct_array = try_downcast::<StructArray>(source, "struct_to_fixed_list pipe")?;
            let fixed = StructToFixedList::new(["x", "y"]).transform(struct_array)?;
            let Some(fixed) = fixed else {
                return Ok(None);
            };
            let mapped =
                MapFixedSizeList::new(MapPrimitive::<arrow::datatypes::Float64Type, _>::new(|x| {
                    x + 1.0
                }))
                .transform(&fixed)?;
            Ok(mapped.map(|arr| Arc::new(arr) as ArrayRef))
        },
    );

    let result = pipeline.execute_per_row(&array)?.unwrap();

    insta::assert_snapshot!(
        format!("{}", DisplayRB(result.clone()))
        , @r"
    ┌────────────────────────────────────────┐
    │ col                                    │
    │ ---                                    │
    │ type: List(FixedSizeList(2 x Float64)) │
    ╞════════════════════════════════════════╡
    │ [[2.0, 3.0], [4.0, 5.0]]               │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[6.0, 7.0]]                           │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                                   │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[8.0, null], [10.0, 11.0]]            │
    └────────────────────────────────────────┘
    "
    );

    Ok(())
}

#[test]
fn convert_to_f32() -> Result<(), Box<dyn std::error::Error>> {
    let array = fixtures::nested_list_struct_column();
    println!("{}", DisplayRB(array.clone()));

    let pipeline = Selector::from_str(".poses[]")?.pipe(
        |source: &ArrayRef| -> Result<Option<ArrayRef>, Error> {
            let struct_array = try_downcast::<StructArray>(source, "struct_to_fixed_list pipe")?;
            let fixed = StructToFixedList::new(["x", "y"]).transform(struct_array)?;
            let Some(fixed) = fixed else {
                return Ok(None);
            };
            let casted = MapFixedSizeList::new(PrimitiveCast::<Float64Array, Float32Array>::new())
                .transform(&fixed)?;
            Ok(casted.map(|arr| Arc::new(arr) as ArrayRef))
        },
    );

    let result = pipeline.execute_per_row(&array)?.unwrap();

    insta::assert_snapshot!(DisplayRB(result.clone()), @r"
    ┌────────────────────────────────────────┐
    │ col                                    │
    │ ---                                    │
    │ type: List(FixedSizeList(2 x Float32)) │
    ╞════════════════════════════════════════╡
    │ [[1.0, 2.0], [3.0, 4.0]]               │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[5.0, 6.0]]                           │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                                   │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[7.0, null], [9.0, 10.0]]             │
    └────────────────────────────────────────┘
    ");

    Ok(())
}

#[test]
fn replace_nulls() -> Result<(), Box<dyn std::error::Error>> {
    let array = fixtures::nested_list_struct_column();
    println!("{}", DisplayRB(array.clone()));

    let pipeline = Selector::from_str(".poses[]")?.pipe(
        |source: &ArrayRef| -> Result<Option<ArrayRef>, Error> {
            let struct_array = try_downcast::<StructArray>(source, "struct_to_fixed_list pipe")?;
            let fixed = StructToFixedList::new(["x", "y"]).transform(struct_array)?;
            let Some(fixed) = fixed else {
                return Ok(None);
            };
            let replaced =
                MapFixedSizeList::new(ReplaceNull::<arrow::datatypes::Float64Type>::new(1337.0))
                    .transform(&fixed)?;
            Ok(replaced.map(|arr| Arc::new(arr) as ArrayRef))
        },
    );

    let result = pipeline.execute_per_row(&array)?.unwrap();

    insta::assert_snapshot!(format!("{}", DisplayRB(result.clone())), @r"
    ┌─────────────────────────────────────────────────┐
    │ col                                             │
    │ ---                                             │
    │ type: List(FixedSizeList(2 x non-null Float64)) │
    ╞═════════════════════════════════════════════════╡
    │ [[1.0, 2.0], [3.0, 4.0]]                        │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[5.0, 6.0]]                                    │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                              │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                              │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                                            │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[7.0, 1337.0], [9.0, 10.0]]                    │
    └─────────────────────────────────────────────────┘
    ");

    Ok(())
}

#[test]
fn test_flatten_single_element() -> Result<(), Box<dyn std::error::Error>> {
    let array = fixtures::nested_list_struct_column();
    println!("{}", DisplayRB(array.clone()));

    let pipeline = Selector::from_str(".poses[]")?;

    let result = pipeline.execute_per_row(&array)?.unwrap();

    insta::assert_snapshot!(
        format!("{}", DisplayRB(result.clone())), @r#"
    ┌────────────────────────────────────────────────┐
    │ col                                            │
    │ ---                                            │
    │ type: List(Struct("x": Float64, "y": Float64)) │
    ╞════════════════════════════════════════════════╡
    │ [{x: 1.0, y: 2.0}, {x: 3.0, y: 4.0}]           │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [{x: 5.0, y: 6.0}]                             │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                             │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                             │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                                           │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [{x: 7.0, y: null}, {x: 9.0, y: 10.0}]         │
    └────────────────────────────────────────────────┘
    "#
    );

    Ok(())
}

#[test]
fn test_flatten_multiple_elements() -> Result<(), Box<dyn std::error::Error>> {
    let inner_builder = ListBuilder::new(arrow::array::Int32Builder::new());
    let mut outer_builder = ListBuilder::new(inner_builder);

    // Row 0: [[1, 2], [3, 4]] -> should flatten to [1, 2, 3, 4]
    outer_builder.values().values().append_value(1);
    outer_builder.values().values().append_value(2);
    outer_builder.values().append(true);
    outer_builder.values().values().append_value(3);
    outer_builder.values().values().append_value(4);
    outer_builder.values().append(true);
    outer_builder.append(true);

    // Row 1: [[5, null], [6, 7, 8]] -> should flatten to [5, null, 6, 7, 8]
    outer_builder.values().values().append_value(5);
    outer_builder.values().values().append_null();
    outer_builder.values().append(true);
    outer_builder.values().values().append_value(6);
    outer_builder.values().values().append_value(7);
    outer_builder.values().values().append_value(8);
    outer_builder.values().append(true);
    outer_builder.append(true);

    // Row 2: [[]] -> should flatten to []
    outer_builder.values().append(true);
    outer_builder.append(true);

    // Row 3: [[], [9]] -> should flatten to [9]
    outer_builder.values().append(true);
    outer_builder.values().values().append_value(9);
    outer_builder.values().append(true);
    outer_builder.append(true);

    // Row 4: null -> should remain null
    outer_builder.append(false);

    // Row 5: [[10, 11]] -> should flatten to [10, 11]
    outer_builder.values().values().append_value(10);
    outer_builder.values().values().append_value(11);
    outer_builder.values().append(true);
    outer_builder.append(true);

    // Row 6: [[32], [33, 34], [], null] -> should flatten to [32, 33, 34]
    outer_builder.values().values().append_value(32);
    outer_builder.values().append(true);
    outer_builder.values().values().append_value(33);
    outer_builder.values().values().append_value(34);
    outer_builder.values().append(true);
    outer_builder.values().append(true);
    outer_builder.values().append(false);
    outer_builder.append(true);

    let list_of_lists = outer_builder.finish();

    println!("{}", DisplayRB(list_of_lists.clone()));

    let result = Selector::from_str(".[]")?
        .execute_per_row(&list_of_lists)?
        .unwrap();

    insta::assert_snapshot!(
        format!("{}", DisplayRB(result.clone())), @r"
    ┌────────────────────┐
    │ col                │
    │ ---                │
    │ type: List(Int32)  │
    ╞════════════════════╡
    │ [1, 2, 3, 4]       │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [5, null, 6, 7, 8] │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                 │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [9]                │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null               │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [10, 11]           │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [32, 33, 34]       │
    └────────────────────┘
    "
    );

    Ok(())
}

#[test]
fn test_row_major_to_col_major() -> Result<(), Box<dyn std::error::Error>> {
    let inner_builder = Int32Builder::new();
    let mut outer_builder = ListBuilder::new(inner_builder);

    // First list represents a 4x3 matrix in row-major order with some null elements.
    // Row 0
    outer_builder.values().append_value(1);
    outer_builder.values().append_null();
    outer_builder.values().append_value(3);
    // Row 1
    outer_builder.values().append_value(4);
    outer_builder.values().append_value(5);
    outer_builder.values().append_value(6);
    // Row 2
    outer_builder.values().append_value(7);
    outer_builder.values().append_value(8);
    outer_builder.values().append_null();
    // Row 3
    outer_builder.values().append_value(10);
    outer_builder.values().append_value(11);
    outer_builder.values().append_value(12);
    outer_builder.append(true);

    // Second list is invalid / null.
    for _ in 0..12 {
        // Add dummy values for Arrow's fixed-size requirements.
        // See: https://docs.rs/arrow/latest/arrow/array/struct.FixedSizeListArray.html#representation
        outer_builder.values().append_value(0);
    }
    outer_builder.append(false);

    // Third list represents a 4x3 matrix in row-major order without null elements.
    // Row 0
    outer_builder.values().append_value(13);
    outer_builder.values().append_value(14);
    outer_builder.values().append_value(15);
    // Row 1
    outer_builder.values().append_value(16);
    outer_builder.values().append_value(17);
    outer_builder.values().append_value(18);
    // Row 2
    outer_builder.values().append_value(19);
    outer_builder.values().append_value(20);
    outer_builder.values().append_value(21);
    // Row 3
    outer_builder.values().append_value(22);
    outer_builder.values().append_value(23);
    outer_builder.values().append_value(24);
    outer_builder.append(true);

    let input_array = outer_builder.finish();

    // Cast to `FixedSizeListArray` and convert to column-major order.
    let fixed_size_list_array = ListToFixedSizeList::new(12)
        .transform(&input_array)?
        .unwrap();
    let result = RowMajorToColumnMajor::new(4, 3)
        .transform(&fixed_size_list_array)?
        .unwrap();

    insta::assert_snapshot!(
        format!("{}", DisplayRB(result.clone())), @r"
    ┌──────────────────────────────────────────────────┐
    │ col                                              │
    │ ---                                              │
    │ type: FixedSizeList(12 x Int32)                  │
    ╞══════════════════════════════════════════════════╡
    │ [1, 4, 7, 10, null, 5, 8, 11, 3, 6, null, 12]    │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                                             │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [13, 16, 19, 22, 14, 17, 20, 23, 15, 18, 21, 24] │
    └──────────────────────────────────────────────────┘
    "
    );

    Ok(())
}

#[test]
fn test_map_list_nullability() -> Result<(), Box<dyn std::error::Error>> {
    let array = fixtures::nested_list_struct_column();
    println!("{}", DisplayRB(array.clone()));

    let pipeline = Selector::from_str(".poses[]")?.pipe(
        |source: &ArrayRef| -> Result<Option<ArrayRef>, Error> {
            let struct_array = try_downcast::<StructArray>(source, "struct_to_fixed_list pipe")?;
            Ok(StructToFixedList::new(["x", "y"])
                .transform(struct_array)?
                .map(|arr| Arc::new(arr) as ArrayRef))
        },
    );

    let result: ListArray = pipeline.execute_per_row(&array)?.unwrap();

    insta::assert_snapshot!(format!("{}", DisplayRB(result.clone())), @r"
    ┌────────────────────────────────────────┐
    │ col                                    │
    │ ---                                    │
    │ type: List(FixedSizeList(2 x Float64)) │
    ╞════════════════════════════════════════╡
    │ [[1.0, 2.0], [3.0, 4.0]]               │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[5.0, 6.0]]                           │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                                   │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[7.0, null], [9.0, 10.0]]             │
    └────────────────────────────────────────┘
    ");

    Ok(())
}

/// Tests that `StructToFixedList` can override the nullability of the output list.
#[test]
fn test_struct_to_fixed_list_nullability_override() -> Result<(), Box<dyn std::error::Error>> {
    let fields = Fields::from(vec![
        Field::new("x", DataType::Float64, false),
        Field::new("y", DataType::Float64, false),
    ]);
    let values = StructArray::new(
        fields.clone(),
        vec![
            Arc::new(Float64Array::from(vec![1.0, 3.0, 5.0])),
            Arc::new(Float64Array::from(vec![2.0, 4.0, 6.0])),
        ],
        None,
    );
    let array = ListArray::new(
        Arc::new(Field::new_list_field(DataType::Struct(fields), false)),
        OffsetBuffer::from_lengths([2, 1, 0]),
        Arc::new(values),
        None,
    );
    println!("{}", DisplayRB(array.clone()));

    let pipeline = MapList::new(StructToFixedList::new(["x", "y"]).with_nullable(false));

    let result: ListArray = pipeline.transform(&array)?.unwrap();

    insta::assert_snapshot!(format!("{}", DisplayRB(result.clone())), @r"
    ┌──────────────────────────────────────────────────────────┐
    │ col                                                      │
    │ ---                                                      │
    │ type: List(non-null FixedSizeList(2 x non-null Float64)) │
    ╞══════════════════════════════════════════════════════════╡
    │ [[1.0, 2.0], [3.0, 4.0]]                                 │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[5.0, 6.0]]                                             │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                                       │
    └──────────────────────────────────────────────────────────┘
    ");

    Ok(())
}

#[test]
fn test_map_list_outer_nullability() -> Result<(), Box<dyn std::error::Error>> {
    let array = fixtures::list_not_nullable();
    println!("{}", DisplayRB(array.clone()));

    let pipeline = MapList::new(PrimitiveCast::<UInt8Array, Float32Array>::new());

    let result: ListArray = pipeline.transform(&array)?.unwrap();

    insta::assert_snapshot!(format!("{}", DisplayRB(result.clone())), @r"
    ┌──────────────────────────────┐
    │ col                          │
    │ ---                          │
    │ type: List(non-null Float32) │
    ╞══════════════════════════════╡
    │ [1.0, 2.0]                   │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [3.0, 4.0, 5.0]              │
    └──────────────────────────────┘
    ");

    let array = fixtures::list_with_nulls();
    println!("{}", DisplayRB(array.clone()));

    let result: ListArray = pipeline.transform(&array)?.unwrap();
    insta::assert_snapshot!(format!("{}", DisplayRB(result.clone())), @r"
    ┌─────────────────────┐
    │ col                 │
    │ ---                 │
    │ type: List(Float32) │
    ╞═════════════════════╡
    │ [1.0, 2.0]          │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                │
    └─────────────────────┘
    ");

    Ok(())
}

#[test]
fn test_map_list_outer_nullability_identity() -> Result<(), Box<dyn std::error::Error>> {
    let array = fixtures::list_not_nullable();
    println!("{}", DisplayRB(array.clone()));

    let pipeline = MapList::new(MapPrimitive::<arrow::datatypes::UInt8Type, _>::new(|x| x));

    let result: ListArray = pipeline.transform(&array)?.unwrap();

    insta::assert_snapshot!(format!("{}", DisplayRB(result.clone())), @r"
    ┌────────────────────────────┐
    │ col                        │
    │ ---                        │
    │ type: List(non-null UInt8) │
    ╞════════════════════════════╡
    │ [1, 2]                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [3, 4, 5]                  │
    └────────────────────────────┘
    ");

    Ok(())
}

#[test]
fn test_flatten_fixed_size_list() -> Result<(), Box<dyn std::error::Error>> {
    let array = fixtures::nested_list_struct_column();

    // Produces List(FixedSizeList(2 x Float64)) instead of creating a new test case from scratch.
    let source: ListArray = Selector::from_str(".poses[]")?
        .pipe(|source: &ArrayRef| -> Result<Option<ArrayRef>, Error> {
            let struct_array = try_downcast::<StructArray>(source, "struct_to_fixed_list pipe")?;
            Ok(StructToFixedList::new(["x", "y"])
                .transform(struct_array)?
                .map(|arr| Arc::new(arr) as ArrayRef))
        })
        .execute_per_row(&array)?
        .unwrap();

    insta::assert_snapshot!(format!("{}", DisplayRB(source.clone())), @"
    ┌────────────────────────────────────────┐
    │ col                                    │
    │ ---                                    │
    │ type: List(FixedSizeList(2 x Float64)) │
    ╞════════════════════════════════════════╡
    │ [[1.0, 2.0], [3.0, 4.0]]               │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[5.0, 6.0]]                           │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                                   │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [[7.0, null], [9.0, 10.0]]             │
    └────────────────────────────────────────┘
    ");

    let result = Flatten::new().transform(&source)?.unwrap();

    insta::assert_snapshot!(format!("{}", DisplayRB(result)), @"
    ┌────────────────────────┐
    │ col                    │
    │ ---                    │
    │ type: List(Float64)    │
    ╞════════════════════════╡
    │ [1.0, 2.0, 3.0, 4.0]   │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [5.0, 6.0]             │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ []                     │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ null                   │
    ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┤
    │ [7.0, null, 9.0, 10.0] │
    └────────────────────────┘
    ");

    Ok(())
}
