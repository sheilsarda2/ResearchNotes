//! Common helper functions for transforming Arrow data in lenses.

use std::sync::Arc;

use arrow::array::{
    Array, ArrayRef, BinaryArray, Float32Array, Float64Array, ListArray, StringArray, StructArray,
};
use re_lenses_core::combinators::{
    Error, GetField, ListToFixedSizeList, MapFixedSizeList, PrimitiveCast, RowMajorToColumnMajor,
    StructToFixedList, Transform as _, try_downcast,
};

/// Returns a pipe-compatible function that converts 3x3 row-major f64 matrices stored in variable-size lists to column-major f32 fixed-size lists.
pub fn row_major_3x3_to_column_major()
-> impl Fn(&ArrayRef) -> Result<Option<ArrayRef>, Error> + Send + Sync {
    move |source: &ArrayRef| {
        let list_array = try_downcast::<ListArray>(source, "row_major_3x3_to_column_major input")?;
        let transform = ListToFixedSizeList::new(9)
            .then(RowMajorToColumnMajor::new(3, 3))
            .then(MapFixedSizeList::new(PrimitiveCast::<
                Float64Array,
                Float32Array,
            >::new()));
        Ok(transform
            .transform(list_array)?
            .map(|arr| Arc::new(arr) as ArrayRef))
    }
}

/// Extracts a struct field by name and downcasts it to the expected array type.
pub fn get_field_as<T: Array + Clone + 'static>(
    source: &StructArray,
    name: &str,
) -> Result<T, Error> {
    let array_ref = GetField::new(name)
        .transform(source)?
        .ok_or_else(|| Error::FieldNotFound {
            field_name: name.to_owned(),
            available_fields: source.fields().iter().map(|f| f.name().clone()).collect(),
        })?;
    try_downcast::<T>(&array_ref, name).cloned()
}

/// Extracts a blob field represented as either `BinaryArray` or `ListArray<UInt8>`.
// TODO(RR-1977): consistently use only `BinaryArray` for all blob types.
pub fn get_blob_field_as_binary(source: &StructArray, name: &str) -> Result<BinaryArray, Error> {
    let array_ref = GetField::new(name)
        .transform(source)?
        .ok_or_else(|| Error::FieldNotFound {
            field_name: name.to_owned(),
            available_fields: source.fields().iter().map(|f| f.name().clone()).collect(),
        })?;

    re_arrow_util::blob_array_to_binary(array_ref.as_ref()).ok_or_else(|| Error::TypeMismatch {
        expected: "BinaryArray or ListArray<UInt8> without null byte values".to_owned(),
        actual: array_ref.data_type().clone(),
        context: name.to_owned(),
    })
}

/// Returns a pipe-compatible function that emits the given string as a constant column, one value per input row.
pub fn constant_string(
    value: &'static str,
) -> impl Fn(&ArrayRef) -> Result<Option<ArrayRef>, Error> + Send + Sync {
    move |source: &ArrayRef| {
        Ok(Some(
            Arc::new(StringArray::from(vec![value; source.len()])) as ArrayRef
        ))
    }
}

/// Converts a struct with `latitude`, `longitude` fields to a fixed-size list with two f64 values.
pub fn lat_lon_struct_to_fixed()
-> impl Fn(&ArrayRef) -> Result<Option<ArrayRef>, Error> + Send + Sync {
    move |source: &ArrayRef| {
        let struct_array = try_downcast::<StructArray>(source, "lat_lon_struct_to_fixed input")?;
        // [`re_sdk_types::components::LatLon`] (`DVec2D`) requires non-null f64 fields.
        let transform = StructToFixedList::new(["latitude", "longitude"]).with_nullable(false);
        Ok(transform
            .transform(struct_array)?
            .map(|arr| Arc::new(arr) as ArrayRef))
    }
}
