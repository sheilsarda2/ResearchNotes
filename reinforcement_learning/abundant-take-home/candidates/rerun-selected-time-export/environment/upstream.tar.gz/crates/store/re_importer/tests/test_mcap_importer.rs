#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use re_chunk::Chunk;
    use re_chunk_store::{ChunkStore, ChunkStoreConfig, ChunkStoreHandle};
    use re_importer::importer_mcap::McapImporter;
    use re_importer::{ImportedData, ImporterSettings};
    use re_log_types::StoreId;

    // Load an MCAP file into a list of chunks.
    fn load_mcap_chunks(path: impl AsRef<std::path::Path>) -> Vec<Chunk> {
        let path = path.as_ref();
        println!("Loading MCAP file: {}", path.display());
        let mcap_data = std::fs::read(path).unwrap();
        let (tx, rx) = crossbeam::channel::bounded(1024);
        let settings = ImporterSettings::recommended("test");
        let mcap_file = re_mcap::McapFile::new(mcap_data, false);
        McapImporter::default()
            .with_raw_fallback(false)
            .load_and_send(&mcap_file, &settings, &tx)
            .unwrap();
        drop(tx);

        // Collect chunks
        rx.iter().filter_map(ImportedData::into_chunk).collect()
    }

    // TODO(grtlr): This should be something like a snippet / backwards-compatibility test, but
    // we don't really have the infrastructure for this yet and we already test a different
    // MCAP file in snippets.
    #[test]
    fn test_mcap_importer_ros2() {
        let chunks = load_mcap_chunks("tests/assets/supported_ros2_messages.mcap");

        // Create a ChunkStore and ChunkStoreHandle
        let store = ChunkStore::new(
            StoreId::random(re_log_types::StoreKind::Recording, "test_mcap_importer"),
            ChunkStoreConfig::default(),
        );
        let store_handle = ChunkStoreHandle::new(store);

        // Insert all chunks into the store
        {
            let mut store = store_handle.write();
            for chunk in chunks {
                store.insert_chunk(&Arc::new(chunk)).unwrap();
            }
        }

        // Extract and snapshot the schema
        let schema = store_handle.read().schema().chunk_column_descriptors();
        insta::assert_debug_snapshot!("ros2", schema);
    }
}
