use crate::{Lens, LensBuilderError, op};
use re_lenses_core::Selector;
use re_log_types::TimeType;
use re_sdk_types::archetypes::{CoordinateFrame, GeoPoints};

use crate::semantic::helpers::lat_lon_struct_to_fixed;

use super::FOXGLOVE_TIMESTAMP;

/// Creates a lens for [`foxglove.LocationFixes`] messages.
///
/// Each fix in the batch gets its own timestamp, position, color, and coordinate frame.
///
/// [`foxglove.LocationFixes`]: https://docs.foxglove.dev/docs/sdk/schemas/location-fixes
pub fn location_fixes(time_type: TimeType) -> Result<Lens, LensBuilderError> {
    Lens::scatter("foxglove.LocationFixes:message")
        .to_timeline(
            FOXGLOVE_TIMESTAMP,
            time_type,
            Selector::parse(".fixes[].timestamp")?.pipe(op::timespec_to_nanos()),
        )
        // `frame_id` can be missing in old versions of the schema.
        .to_component(
            CoordinateFrame::descriptor_frame(),
            Selector::parse(".fixes[].frame_id!")?,
        )
        .to_component(
            GeoPoints::descriptor_positions(),
            Selector::parse(".fixes[]")?.pipe(lat_lon_struct_to_fixed()),
        )
        // `color` field is optional.
        .to_component(
            GeoPoints::descriptor_colors(),
            Selector::parse(".fixes[].color!")?.pipe(op::rgba_struct_to_uint32()),
        )
        .build()
}
