// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

#[macro_use]
extern crate criterion;
use criterion::Criterion;
use rand::RngExt;
use rand::distr::{Distribution, StandardUniform, Uniform};
use std::hint;

use chrono::{DateTime, NaiveDate, NaiveDateTime};
use std::sync::Arc;

use arrow::array::*;
use arrow::compute::cast;
use arrow::datatypes::*;
use arrow::util::bench_util::*;
use arrow::util::test_util::seedable_rng;

fn build_array<T: ArrowPrimitiveType>(size: usize) -> ArrayRef
where
    StandardUniform: Distribution<T::Native>,
{
    let array = create_primitive_array::<T>(size, 0.1);
    Arc::new(array)
}

fn build_utf8_date_array(size: usize, with_nulls: bool) -> ArrayRef {
    use chrono::NaiveDate;

    // use random numbers to avoid spurious compiler optimizations wrt to branching
    let mut rng = seedable_rng();
    let mut builder = StringBuilder::new();
    let range = Uniform::new(0, 737776).unwrap();

    for _ in 0..size {
        if with_nulls && rng.random::<f32>() > 0.8 {
            builder.append_null();
        } else {
            let string = NaiveDate::from_num_days_from_ce_opt(rng.sample(range))
                .unwrap()
                .format("%Y-%m-%d")
                .to_string();
            builder.append_value(&string);
        }
    }
    Arc::new(builder.finish())
}

fn build_utf8_date_time_array(size: usize, with_nulls: bool) -> ArrayRef {
    // use random numbers to avoid spurious compiler optimizations wrt to branching
    let mut rng = seedable_rng();
    let mut builder = StringBuilder::new();
    let range = Uniform::new(0, 1608071414123).unwrap();

    for _ in 0..size {
        if with_nulls && rng.random::<f32>() > 0.8 {
            builder.append_null();
        } else {
            let string = DateTime::from_timestamp(rng.sample(range), 0)
                .unwrap()
                .format("%Y-%m-%dT%H:%M:%S")
                .to_string();
            builder.append_value(&string);
        }
    }
    Arc::new(builder.finish())
}

fn build_decimal128_array(size: usize, precision: u8, scale: i8) -> ArrayRef {
    let mut rng = seedable_rng();
    let mut builder = Decimal128Builder::with_capacity(size);

    for _ in 0..size {
        builder.append_value(rng.random_range::<i128, _>(0..1000000000));
    }
    Arc::new(
        builder
            .finish()
            .with_precision_and_scale(precision, scale)
            .unwrap(),
    )
}

fn build_decimal256_array(size: usize, precision: u8, scale: i8) -> ArrayRef {
    let mut rng = seedable_rng();
    let mut builder = Decimal256Builder::with_capacity(size);
    let mut bytes = [0; 32];
    for _ in 0..size {
        let num = rng.random_range::<i128, _>(0..1000000000);
        bytes[0..16].clone_from_slice(&num.to_le_bytes());
        builder.append_value(i256::from_le_bytes(bytes));
    }
    Arc::new(
        builder
            .finish()
            .with_precision_and_scale(precision, scale)
            .unwrap(),
    )
}

fn build_string_array(size: usize) -> ArrayRef {
    let mut builder = StringBuilder::new();
    for v in 0..size {
        match v % 3 {
            0 => builder.append_value("small"),
            1 => builder.append_value("larger string more than 12 bytes"),
            _ => builder.append_null(),
        }
    }
    Arc::new(builder.finish())
}

fn build_string_float_array(size: usize, null_density: f32) -> ArrayRef {
    let mut builder = StringBuilder::new();

    let mut rng = seedable_rng();

    for _ in 0..size {
        if rng.random::<f32>() < null_density {
            builder.append_null()
        } else {
            builder.append_value(
                rng.random_range(-1_000_000_000_f32..1_000_000_000_f32)
                    .to_string(),
            )
        }
    }
    Arc::new(builder.finish())
}

fn build_float64_array_for_cast_to_decimal(size: usize, null_density: f32) -> ArrayRef {
    Arc::new(create_primitive_array_range::<Float64Type>(
        size,
        null_density,
        -999_999_999f64..999_999_999f64,
    ))
}

macro_rules! build_array_with_samples {
    ($builder: ident, $size: ident, $null_density: expr, $samples: ident) => {{
        let mut rng = seedable_rng();
        for i in 0..$size {
            if rng.random::<f32>() < $null_density {
                $builder.append_null();
            } else {
                $builder.append_value($samples[i % $samples.len()])
            }
        }
        Arc::new($builder.finish())
    }};
}

fn build_float64_array_invalid_items(size: usize, null_density: f32) -> ArrayRef {
    let mut builder = Float64Builder::with_capacity(size);
    let invalid_values = [f64::NAN, f64::INFINITY, f64::NEG_INFINITY];

    build_array_with_samples!(builder, size, null_density, invalid_values)
}

// Builds a BinaryArray of `size` rows over `unique_count` distinct byte strings.
// `null_every` controls null density: Some(n) inserts a null every n rows, None means no nulls.
// Binary and Utf8 both route through pack_byte_to_dictionary, so binary covers both paths.
fn build_binary_array_for_dict_cast(
    size: usize,
    unique_count: usize,
    null_every: Option<usize>,
) -> ArrayRef {
    let values: Vec<Vec<u8>> = (0..unique_count)
        .map(|i| format!("value{i:08}").into_bytes())
        .collect();
    let mut builder = BinaryBuilder::with_capacity(size, size * 10);
    for i in 0..size {
        if null_every.is_some_and(|n| i % n == 0) {
            builder.append_null();
        } else {
            builder.append_value(&values[i % unique_count]);
        }
    }
    Arc::new(builder.finish())
}

fn build_dict_array(size: usize) -> ArrayRef {
    let values = StringArray::from_iter([
        Some("small"),
        Some("larger string more than 12 bytes"),
        None,
    ]);
    let keys = UInt64Array::from_iter((0..size as u64).map(|v| v % 3));

    Arc::new(DictionaryArray::new(keys, Arc::new(values)))
}

// Dictionary<UInt32, Dictionary<UInt32, Utf8>>: an inner dictionary of 4096
// entries over 64 moderately long distinct values, wrapped by `size` outer keys
// that index into it. Casting to Dictionary<UInt32, Utf8> flattens the two index
// layers; the old path unpacks (copies) the inner values, the fast path reuses
// them and only remaps indices.
fn build_nested_dict_array(size: usize) -> ArrayRef {
    let distinct: Vec<String> = (0..64)
        .map(|i| format!("a moderately long symbol name number {i:04}"))
        .collect();
    let inner_values = StringArray::from_iter(distinct.iter().map(|s| Some(s.as_str())));
    let inner_len = 4096u32;
    let distinct_len = inner_values.len() as u32;
    let inner_keys = UInt32Array::from_iter((0..inner_len).map(|v| v % distinct_len));
    let inner = DictionaryArray::new(inner_keys, Arc::new(inner_values));

    let outer_keys = UInt32Array::from_iter((0..size as u32).map(|v| v % inner_len));
    Arc::new(DictionaryArray::new(outer_keys, Arc::new(inner)))
}

// Keys for a `size` row dictionary, spread over `distinct` values so a cast has to touch
// the whole values buffer rather than a contiguous prefix of it.
fn dict_keys(size: usize, distinct: usize) -> UInt64Array {
    let mut rng = seedable_rng();
    let range = Uniform::new(0, distinct as u64).unwrap();
    UInt64Array::from_iter_values((0..size).map(|_| rng.sample(range)))
}

// `Dictionary<UInt64, Utf8>` of `size` rows over `distinct` values, alternating between
// values short enough to inline into a view and longer ones that reference the buffer.
//
// Different implementation paths may be taken based on the ratio of rows to distinct
// values.
fn build_string_dict_array(size: usize, distinct: usize) -> ArrayRef {
    let values = StringArray::from_iter_values((0..distinct).map(|i| {
        if i % 2 == 0 {
            format!("val {i}")
        } else {
            format!("dictionary value {i:07}")
        }
    }));

    Arc::new(DictionaryArray::new(
        dict_keys(size, distinct),
        Arc::new(values),
    ))
}

// cast array from specified primitive array type to desired data type
fn cast_array(array: &ArrayRef, to_type: DataType) {
    hint::black_box(cast(hint::black_box(array), hint::black_box(&to_type)).unwrap());
}

fn add_benchmark(c: &mut Criterion) {
    let i32_array = build_array::<Int32Type>(512);
    let i64_array = build_array::<Int64Type>(512);
    let f32_array = build_array::<Float32Type>(512);
    let f32_utf8_array = cast(&build_array::<Float32Type>(512), &DataType::Utf8).unwrap();
    let i32_utf8_array = cast(&build_array::<Int32Type>(512), &DataType::Utf8).unwrap();

    let f64_array = build_array::<Float64Type>(512);
    let date64_array = build_array::<Date64Type>(512);
    let date32_array = build_array::<Date32Type>(512);
    let time32s_array = build_array::<Time32SecondType>(512);
    let time64ns_array = build_array::<Time64NanosecondType>(512);
    let time_ns_array = build_array::<TimestampNanosecondType>(512);
    let time_ms_array = build_array::<TimestampMillisecondType>(512);
    let utf8_date_array = build_utf8_date_array(512, true);
    let utf8_date_time_array = build_utf8_date_time_array(512, true);

    let decimal128_array = build_decimal128_array(8_000, 10, 3);
    let decimal256_array = build_decimal256_array(8_000, 50, 3);
    let string_array = build_string_array(512);
    let wide_string_array = cast(&string_array, &DataType::LargeUtf8).unwrap();

    let binary_low_card = build_binary_array_for_dict_cast(10_000, 25, Some(20));
    let binary_med_card = build_binary_array_for_dict_cast(10_000, 500, Some(20));
    let binary_high_card = build_binary_array_for_dict_cast(10_000, 2_500, Some(20));
    let binary_low_card_no_nulls = build_binary_array_for_dict_cast(10_000, 25, None);
    let binary_med_card_no_nulls = build_binary_array_for_dict_cast(10_000, 500, None);
    let binary_high_card_no_nulls = build_binary_array_for_dict_cast(10_000, 2_500, None);

    let dict_array = build_dict_array(10_000);
    let nested_dict_array = build_nested_dict_array(10_000);
    let string_view_array = cast(&dict_array, &DataType::Utf8View).unwrap();
    let binary_view_array = cast(&string_view_array, &DataType::BinaryView).unwrap();

    // the dictionary is far larger than the array is long, as after a selective filter.
    // `dict_array` above is the opposite shape, many rows over few dictionary values.
    let sparse_dict_array = build_string_dict_array(1_024, 32_768);
    let sparse_binary_dict_array = cast(
        &sparse_dict_array,
        &DataType::Dictionary(Box::new(DataType::UInt64), Box::new(DataType::Binary)),
    )
    .unwrap();

    let string_float_array_normal = build_string_float_array(5_000, 0.1);
    let float64_array_cast_to_decimal = build_float64_array_for_cast_to_decimal(8_000, 0.1);
    let invalid_float64_array_to_decimal = build_float64_array_invalid_items(8_000, 0.1);

    c.bench_function("cast int32 to int32 512", |b| {
        b.iter(|| cast_array(&i32_array, DataType::Int32))
    });
    c.bench_function("cast int32 to uint32 512", |b| {
        b.iter(|| cast_array(&i32_array, DataType::UInt32))
    });
    c.bench_function("cast int32 to float32 512", |b| {
        b.iter(|| cast_array(&i32_array, DataType::Float32))
    });
    c.bench_function("cast int32 to float64 512", |b| {
        b.iter(|| cast_array(&i32_array, DataType::Float64))
    });
    c.bench_function("cast int32 to int64 512", |b| {
        b.iter(|| cast_array(&i32_array, DataType::Int64))
    });
    c.bench_function("cast float32 to int32 512", |b| {
        b.iter(|| cast_array(&f32_array, DataType::Int32))
    });
    c.bench_function("cast float64 to float32 512", |b| {
        b.iter(|| cast_array(&f64_array, DataType::Float32))
    });
    c.bench_function("cast float64 to uint64 512", |b| {
        b.iter(|| cast_array(&f64_array, DataType::UInt64))
    });
    c.bench_function("cast int64 to int32 512", |b| {
        b.iter(|| cast_array(&i64_array, DataType::Int32))
    });
    c.bench_function("cast int64 to decimal32(9, 0) 512", |b| {
        b.iter(|| cast_array(&i64_array, DataType::Decimal32(9, 0)))
    });
    c.bench_function("cast int64 to decimal32(9, -1) 512", |b| {
        b.iter(|| cast_array(&i64_array, DataType::Decimal32(9, -1)))
    });
    c.bench_function("cast date64 to date32 512", |b| {
        b.iter(|| cast_array(&date64_array, DataType::Date32))
    });
    c.bench_function("cast date32 to date64 512", |b| {
        b.iter(|| cast_array(&date32_array, DataType::Date64))
    });
    c.bench_function("cast time32s to time32ms 512", |b| {
        b.iter(|| cast_array(&time32s_array, DataType::Time32(TimeUnit::Millisecond)))
    });
    c.bench_function("cast time32s to time64us 512", |b| {
        b.iter(|| cast_array(&time32s_array, DataType::Time64(TimeUnit::Microsecond)))
    });
    c.bench_function("cast time64ns to time32s 512", |b| {
        b.iter(|| cast_array(&time64ns_array, DataType::Time32(TimeUnit::Second)))
    });
    c.bench_function("cast timestamp_ns to timestamp_s 512", |b| {
        b.iter(|| {
            cast_array(
                &time_ns_array,
                DataType::Timestamp(TimeUnit::Nanosecond, None),
            )
        })
    });
    c.bench_function("cast timestamp_ms to timestamp_ns 512", |b| {
        b.iter(|| {
            cast_array(
                &time_ms_array,
                DataType::Timestamp(TimeUnit::Nanosecond, None),
            )
        })
    });
    c.bench_function("cast utf8 to f32", |b| {
        b.iter(|| cast_array(&f32_utf8_array, DataType::Float32))
    });
    c.bench_function("cast utf8 to i32", |b| {
        b.iter(|| cast_array(&i32_utf8_array, DataType::Int32))
    });
    c.bench_function("cast i64 to string 512", |b| {
        b.iter(|| cast_array(&i64_array, DataType::Utf8))
    });
    c.bench_function("cast f32 to string 512", |b| {
        b.iter(|| cast_array(&f32_array, DataType::Utf8))
    });
    c.bench_function("cast f64 to string 512", |b| {
        b.iter(|| cast_array(&f64_array, DataType::Utf8))
    });
    c.bench_function("cast timestamp_ms to i64 512", |b| {
        b.iter(|| cast_array(&time_ms_array, DataType::Int64))
    });
    c.bench_function("cast utf8 to date32 512", |b| {
        b.iter(|| cast_array(&utf8_date_array, DataType::Date32))
    });
    c.bench_function("cast utf8 to date64 512", |b| {
        b.iter(|| cast_array(&utf8_date_time_array, DataType::Date64))
    });

    c.bench_function("cast decimal128 to decimal128 512", |b| {
        b.iter(|| cast_array(&decimal128_array, DataType::Decimal128(30, 5)))
    });
    c.bench_function("cast decimal128 to decimal128 512 lower precision", |b| {
        b.iter(|| cast_array(&decimal128_array, DataType::Decimal128(6, 5)))
    });
    c.bench_function("cast decimal128 to decimal256 512", |b| {
        b.iter(|| cast_array(&decimal128_array, DataType::Decimal256(50, 5)))
    });
    c.bench_function("cast decimal256 to decimal128 512", |b| {
        b.iter(|| cast_array(&decimal256_array, DataType::Decimal128(38, 2)))
    });
    c.bench_function("cast decimal256 to decimal256 512", |b| {
        b.iter(|| cast_array(&decimal256_array, DataType::Decimal256(50, 5)))
    });

    c.bench_function("cast decimal128 to decimal128 512 with same scale", |b| {
        b.iter(|| cast_array(&decimal128_array, DataType::Decimal128(30, 3)))
    });

    c.bench_function(
        "cast decimal128 to decimal128 512 with lower scale (infallible)",
        |b| b.iter(|| cast_array(&decimal128_array, DataType::Decimal128(7, -1))),
    );

    c.bench_function("cast decimal256 to decimal256 512 with same scale", |b| {
        b.iter(|| cast_array(&decimal256_array, DataType::Decimal256(60, 3)))
    });
    c.bench_function("cast dict to string view", |b| {
        b.iter(|| cast_array(&dict_array, DataType::Utf8View))
    });
    c.bench_function("cast dict to string view (sparse)", |b| {
        b.iter(|| cast_array(&sparse_dict_array, DataType::Utf8View))
    });
    c.bench_function("cast binary dict to string view (sparse)", |b| {
        b.iter(|| cast_array(&sparse_binary_dict_array, DataType::Utf8View))
    });
    c.bench_function("cast nested dict to dict", |b| {
        b.iter(|| {
            cast_array(
                &nested_dict_array,
                DataType::Dictionary(Box::new(DataType::UInt32), Box::new(DataType::Utf8)),
            )
        })
    });
    c.bench_function("cast binary to dict low cardinality", |b| {
        b.iter(|| {
            cast_array(
                &binary_low_card,
                DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Binary)),
            )
        })
    });
    c.bench_function("cast binary to dict medium cardinality", |b| {
        b.iter(|| {
            cast_array(
                &binary_med_card,
                DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Binary)),
            )
        })
    });
    c.bench_function("cast binary to dict high cardinality", |b| {
        b.iter(|| {
            cast_array(
                &binary_high_card,
                DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Binary)),
            )
        })
    });
    c.bench_function("cast binary to dict low cardinality no nulls", |b| {
        b.iter(|| {
            cast_array(
                &binary_low_card_no_nulls,
                DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Binary)),
            )
        })
    });
    c.bench_function("cast binary to dict medium cardinality no nulls", |b| {
        b.iter(|| {
            cast_array(
                &binary_med_card_no_nulls,
                DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Binary)),
            )
        })
    });
    c.bench_function("cast binary to dict high cardinality no nulls", |b| {
        b.iter(|| {
            cast_array(
                &binary_high_card_no_nulls,
                DataType::Dictionary(Box::new(DataType::Int32), Box::new(DataType::Binary)),
            )
        })
    });
    c.bench_function("cast string view to dict", |b| {
        b.iter(|| {
            cast_array(
                &string_view_array,
                DataType::Dictionary(Box::new(DataType::UInt64), Box::new(DataType::Utf8)),
            )
        })
    });
    c.bench_function("cast string view to string", |b| {
        b.iter(|| cast_array(&string_view_array, DataType::Utf8))
    });
    c.bench_function("cast string view to wide string", |b| {
        b.iter(|| cast_array(&string_view_array, DataType::LargeUtf8))
    });
    c.bench_function("cast binary view to string", |b| {
        b.iter(|| cast_array(&binary_view_array, DataType::Utf8))
    });
    c.bench_function("cast binary view to wide string", |b| {
        b.iter(|| cast_array(&binary_view_array, DataType::LargeUtf8))
    });
    c.bench_function("cast string to binary view 512", |b| {
        b.iter(|| cast_array(&string_array, DataType::BinaryView))
    });
    c.bench_function("cast wide string to binary view 512", |b| {
        b.iter(|| cast_array(&wide_string_array, DataType::BinaryView))
    });
    c.bench_function("cast string view to binary view", |b| {
        b.iter(|| cast_array(&string_view_array, DataType::BinaryView))
    });
    c.bench_function("cast binary view to string view", |b| {
        b.iter(|| cast_array(&binary_view_array, DataType::Utf8View))
    });

    macro_rules! benchmark_cast {
        ($name: expr, $input_array: ident, $target_type: expr) => {
            c.bench_function(stringify!($name), |b| {
                b.iter(|| cast_array(&$input_array, $target_type))
            });
        };
    }

    // cast string with normal items to decimals
    benchmark_cast!(
        "cast string to decimal128(38, 3)",
        string_float_array_normal,
        DataType::Decimal128(38, 3)
    );
    benchmark_cast!(
        "cast string to decimal256(76, 3)",
        string_float_array_normal,
        DataType::Decimal256(76, 3)
    );

    // cast float64 to decimals
    benchmark_cast!(
        "cast float64 to decimal128(32, 3)",
        float64_array_cast_to_decimal,
        DataType::Decimal128(32, 3)
    );

    // cast invalid float64 to decimals
    benchmark_cast!(
        "cast invalid float64 to to decimal128(32, 3)",
        invalid_float64_array_to_decimal,
        DataType::Decimal128(32, 3)
    );

    // cast decimals to float/integers
    benchmark_cast!(
        "cast decimal128 to float64",
        decimal128_array,
        DataType::Float64
    );
    benchmark_cast!("cast decimal128 to int8", decimal128_array, DataType::Int8);
    benchmark_cast!(
        "cast decimal128 to int64",
        decimal128_array,
        DataType::Int64
    );

    benchmark_cast!(
        "cast decimal256 to float64",
        decimal256_array,
        DataType::Float64
    );
    benchmark_cast!(
        "cast decimal256 to int64",
        decimal256_array,
        DataType::Int64
    );

    c.bench_function("cast string single run to ree<int32>", |b| {
        let source_array = StringArray::from(vec!["a"; 8192]);
        let array_ref = Arc::new(source_array) as ArrayRef;
        let target_type = DataType::RunEndEncoded(
            Arc::new(Field::new("run_ends", DataType::Int32, false)),
            Arc::new(Field::new("values", DataType::Utf8, true)),
        );
        b.iter(|| cast(&array_ref, &target_type).unwrap());
    });

    c.bench_function("cast runs of 10 string to ree<int32>", |b| {
        let source_array: Int32Array = (0..8192).map(|i| i / 10).collect();
        let array_ref = Arc::new(source_array) as ArrayRef;
        let target_type = DataType::RunEndEncoded(
            Arc::new(Field::new("run_ends", DataType::Int32, false)),
            Arc::new(Field::new("values", DataType::Int32, true)),
        );
        b.iter(|| cast(&array_ref, &target_type).unwrap());
    });

    c.bench_function("cast runs of 1000 int32s to ree<int32>", |b| {
        let source_array: Int32Array = (0..8192).map(|i| i / 1000).collect();
        let array_ref = Arc::new(source_array) as ArrayRef;
        let target_type = DataType::RunEndEncoded(
            Arc::new(Field::new("run_ends", DataType::Int32, false)),
            Arc::new(Field::new("values", DataType::Int32, true)),
        );
        b.iter(|| cast(&array_ref, &target_type).unwrap());
    });

    c.bench_function("cast no runs of int32s to ree<int32>", |b| {
        let source_array: Int32Array = (0..8192).collect();
        let array_ref = Arc::new(source_array) as ArrayRef;
        let target_type = DataType::RunEndEncoded(
            Arc::new(Field::new("run_ends", DataType::Int32, false)),
            Arc::new(Field::new("values", DataType::Int32, true)),
        );
        b.iter(|| cast(&array_ref, &target_type).unwrap());
    });

    c.bench_function("cast date to string", |b| {
        // the min and max of the date32 type
        let range = NaiveDate::MIN.to_epoch_days()..NaiveDate::MAX.to_epoch_days();
        let date32_array: PrimitiveArray<Date32Type> =
            create_primitive_array_range::<Date32Type>(8192, 0.1, range);
        let target_type = DataType::Utf8;
        b.iter(|| cast(&date32_array, &target_type).unwrap());
    });
    c.bench_function("cast time64 to string", |b| {
        let time64_array: PrimitiveArray<Time64MicrosecondType> =
            create_primitive_array_range::<Time64MicrosecondType>(8192, 0.1, 0..86400000000);
        let target_type = DataType::Utf8;
        b.iter(|| cast(&time64_array, &target_type).unwrap());
    });
    c.bench_function("cast micro timestamp to string", |b| {
        let range = NaiveDateTime::MIN.and_utc().timestamp_micros()
            ..NaiveDateTime::MAX.and_utc().timestamp_micros();
        let timestamp_micro_array: PrimitiveArray<TimestampMicrosecondType> =
            create_primitive_array_range::<TimestampMicrosecondType>(8192, 0.1, range);
        let target_type = DataType::Utf8;
        b.iter(|| cast(&timestamp_micro_array, &target_type).unwrap());
    });
    c.bench_function("cast micro timestamp with timezone to string", |b| {
        let range = NaiveDateTime::MIN.and_utc().timestamp_micros()
            ..NaiveDateTime::MAX.and_utc().timestamp_micros();
        let timestamp_micro_utc_array =
            create_primitive_array_range::<TimestampMicrosecondType>(8192, 0.1, range)
                .with_timezone("+08:00");
        let target_type = DataType::Utf8;
        b.iter(|| cast(&timestamp_micro_utc_array, &target_type).unwrap());
    });
}

criterion_group!(benches, add_benchmark);
criterion_main!(benches);
