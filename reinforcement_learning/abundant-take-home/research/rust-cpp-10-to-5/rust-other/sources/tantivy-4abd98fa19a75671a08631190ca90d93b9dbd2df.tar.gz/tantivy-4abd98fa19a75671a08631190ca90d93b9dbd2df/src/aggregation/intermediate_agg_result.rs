//! Contains the intermediate aggregation tree, that can be merged.
//! Intermediate aggregation results can be used to merge results between segments or between
//! indices.

use std::cmp::Ordering;
use std::collections::hash_map::Entry;
use std::hash::Hash;
use std::net::Ipv6Addr;

use columnar::{ColumnType, NumericalValue};
use itertools::Itertools;
use rustc_hash::FxHashMap;
use serde::{Deserialize, Serialize};

use super::agg_req::{Aggregation, AggregationVariants, Aggregations};
use super::agg_result::{AggregationResult, BucketResult, MetricResult, RangeBucketEntry};
use super::bucket::{
    composite_intermediate_key_ordering, cut_off_buckets, get_agg_name_and_property,
    intermediate_histogram_buckets_to_final_buckets, CompositeAggregation, GetDocCount,
    MissingOrder, Order, OrderTarget, RangeAggregation, TermsAggregation,
};
use super::metric::{
    IntermediateAverage, IntermediateCount, IntermediateExtendedStats, IntermediateMax,
    IntermediateMin, IntermediateStats, IntermediateSum, PercentilesCollector, TopHitsTopNComputer,
};
use super::segment_agg_result::AggregationLimitsGuard;
use super::{format_date, AggregationError, Key, SerializedKey};
use crate::aggregation::agg_result::{
    AggregationResults, BucketEntries, BucketEntry, CompositeBucketEntry, FilterBucketResult,
};
use crate::aggregation::bucket::{IntermediateMultiTermsBucketResult, TermsAggregationInternal};
use crate::aggregation::metric::CardinalityCollector;
use crate::TantivyError;

/// Controls which size limit is applied when pruning intermediate aggregation results.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PruneMode {
    /// Use the same rules for pruning as the per-segment pruning, notably using `segment_size`.
    Intermediate,
    /// Use the same rules for pruning as what happen when creating normal results.
    /// Uses `size`, and possibly apply other filtering such as `min_doc_count`.
    Final,
}

/// Contains the intermediate aggregation result, which is optimized to be merged with other
/// intermediate results.
///
/// Notice: This struct should not be de/serialized via JSON format.
#[derive(Default, Clone, Debug, Serialize, Deserialize)]
pub struct IntermediateAggregationResults {
    pub(crate) aggs_res: FxHashMap<String, IntermediateAggregationResult>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
/// The key to identify a bucket.
/// This might seem redundant with `Key`, but the point is to have a different
/// Serialize implementation.
pub enum IntermediateKey {
    /// Ip Addr key
    IpAddr(Ipv6Addr),
    /// Bool key
    Bool(bool),
    /// String key
    Str(String),
    /// `f64` key
    F64(f64),
    /// `i64` key
    I64(i64),
    /// `u64` key
    U64(u64),
}

impl IntermediateKey {
    fn variant_ord(&self) -> u8 {
        match self {
            Self::IpAddr(_) => 0,
            Self::Bool(_) => 1,
            Self::Str(_) => 2,
            Self::F64(_) => 3,
            Self::I64(_) => 4,
            Self::U64(_) => 5,
        }
    }
}

impl Ord for IntermediateKey {
    fn cmp(&self, other: &Self) -> Ordering {
        match (self, other) {
            (Self::IpAddr(left), Self::IpAddr(right)) => left.cmp(right),
            (Self::Bool(left), Self::Bool(right)) => left.cmp(right),
            (Self::Str(left), Self::Str(right)) => left.cmp(right),
            (Self::F64(left), Self::F64(right)) => left.total_cmp(right),
            (Self::I64(left), Self::I64(right)) => left.cmp(right),
            (Self::U64(left), Self::U64(right)) => left.cmp(right),
            (left, right) => left.variant_ord().cmp(&right.variant_ord()),
        }
    }
}

impl PartialOrd for IntermediateKey {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl PartialEq for IntermediateKey {
    fn eq(&self, other: &Self) -> bool {
        self.cmp(other) == Ordering::Equal
    }
}

impl Eq for IntermediateKey {}

impl From<NumericalValue> for IntermediateKey {
    fn from(value: NumericalValue) -> Self {
        match value {
            NumericalValue::U64(value) => Self::U64(value),
            NumericalValue::I64(value) => Self::I64(value),
            NumericalValue::F64(value) => Self::F64(value),
        }
    }
}
impl From<Key> for IntermediateKey {
    fn from(value: Key) -> Self {
        match value {
            Key::Str(s) => Self::Str(s),
            Key::F64(f) => Self::F64(f),
            Key::U64(f) => Self::U64(f),
            Key::I64(f) => Self::I64(f),
        }
    }
}
impl From<IntermediateKey> for Key {
    fn from(value: IntermediateKey) -> Self {
        match value {
            IntermediateKey::Str(s) => Self::Str(s),
            IntermediateKey::IpAddr(s) => {
                // Prefer to use the IPv4 representation if possible
                if let Some(ip) = s.to_ipv4_mapped() {
                    Self::Str(ip.to_string())
                } else {
                    Self::Str(s.to_string())
                }
            }
            IntermediateKey::F64(f) => Self::F64(f),
            IntermediateKey::Bool(f) => Self::U64(f as u64),
            IntermediateKey::U64(f) => Self::U64(f),
            IntermediateKey::I64(f) => Self::I64(f),
        }
    }
}

impl std::fmt::Display for IntermediateKey {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            IntermediateKey::Str(val) => f.write_str(val),
            IntermediateKey::F64(val) => f.write_str(&val.to_string()),
            IntermediateKey::U64(val) => f.write_str(&val.to_string()),
            IntermediateKey::I64(val) => f.write_str(&val.to_string()),
            IntermediateKey::Bool(val) => f.write_str(&val.to_string()),
            IntermediateKey::IpAddr(val) => f.write_str(&val.to_string()),
        }
    }
}

impl std::hash::Hash for IntermediateKey {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        core::mem::discriminant(self).hash(state);
        match self {
            IntermediateKey::Str(text) => text.hash(state),
            IntermediateKey::F64(val) => val.to_bits().hash(state),
            IntermediateKey::U64(val) => val.hash(state),
            IntermediateKey::I64(val) => val.hash(state),
            IntermediateKey::Bool(val) => val.hash(state),
            IntermediateKey::IpAddr(val) => val.hash(state),
        }
    }
}

impl IntermediateAggregationResults {
    /// Returns a reference to the intermediate aggregation result for the given key.
    pub fn get(&self, key: &str) -> Option<&IntermediateAggregationResult> {
        self.aggs_res.get(key)
    }

    /// Removes and returns the intermediate aggregation result for the given key.
    pub fn remove(&mut self, key: &str) -> Option<IntermediateAggregationResult> {
        self.aggs_res.remove(key)
    }

    /// Returns an iterator over the keys in the intermediate aggregation results.
    pub fn keys(&self) -> impl Iterator<Item = &String> {
        self.aggs_res.keys()
    }

    /// Add a result
    pub fn push(&mut self, key: String, value: IntermediateAggregationResult) -> crate::Result<()> {
        let entry = self.aggs_res.entry(key);
        match entry {
            Entry::Occupied(mut e) => {
                // In case of term aggregation over different types, we need to merge the results.
                e.get_mut().merge_fruits(value)?;
            }
            Entry::Vacant(e) => {
                e.insert(value);
            }
        }
        Ok(())
    }

    /// Convert intermediate result and its aggregation request to the final result.
    pub fn into_final_result(
        self,
        req: Aggregations,
        mut limits: AggregationLimitsGuard,
    ) -> crate::Result<AggregationResults> {
        let res = self.into_final_result_internal(&req, &mut limits)?;
        let bucket_count = res.get_bucket_count() as u32;
        if bucket_count > limits.get_bucket_limit() {
            return Err(TantivyError::AggregationError(
                AggregationError::BucketLimitExceeded {
                    limit: limits.get_bucket_limit(),
                    current: bucket_count,
                },
            ));
        }
        Ok(res)
    }

    /// Convert intermediate result and its aggregation request to the final result.
    pub(crate) fn into_final_result_internal(
        self,
        req: &Aggregations,
        limits: &mut AggregationLimitsGuard,
    ) -> crate::Result<AggregationResults> {
        let mut results: FxHashMap<String, AggregationResult> = FxHashMap::default();
        for (key, agg_res) in self.aggs_res.into_iter() {
            let req = req.get(key.as_str()).unwrap_or_else(|| {
                panic!(
                    "Could not find key {:?} in request keys {:?}. This probably means that \
                     add_intermediate_aggregation_result passed the wrong agg object.",
                    key,
                    req.keys().collect::<Vec<_>>()
                )
            });
            results.insert(key, agg_res.into_final_result(req, limits)?);
        }
        // Handle empty results
        if results.len() != req.len() {
            for (key, req) in req.iter() {
                if !results.contains_key(key) {
                    let empty_res = empty_from_req(req);
                    results.insert(key.to_string(), empty_res.into_final_result(req, limits)?);
                }
            }
        }

        Ok(AggregationResults(results))
    }

    pub(crate) fn empty_from_req(req: &Aggregations) -> Self {
        let mut aggs_res: FxHashMap<String, IntermediateAggregationResult> = FxHashMap::default();
        for (key, req) in req.iter() {
            let empty_res = empty_from_req(req);
            aggs_res.insert(key.to_string(), empty_res);
        }

        Self { aggs_res }
    }

    pub(crate) fn get_value_from_aggregation(
        &self,
        name: &str,
        agg_property: &str,
    ) -> crate::Result<Option<f64>> {
        if let Some(agg) = self.aggs_res.get(name) {
            agg.get_value_from_aggregation(name, agg_property)
        } else {
            Err(TantivyError::InternalError(format!(
                "Can't find aggregation {name:?} in sub-aggregations"
            )))
        }
    }

    /// Re-prune intermediate results using the limits from the aggregation request.
    pub fn prune_intermediate_results(
        &mut self,
        req: &Aggregations,
        mode: PruneMode,
    ) -> crate::Result<()> {
        for (key, agg_res) in self.aggs_res.iter_mut() {
            if let Some(agg_req) = req.get(key.as_str()) {
                agg_res.prune_intermediate_results(agg_req, mode)?;
            }
        }
        Ok(())
    }

    /// Merge another intermediate aggregation result into this result.
    pub fn merge_fruits(&mut self, mut other: IntermediateAggregationResults) -> crate::Result<()> {
        for (key, left) in self.aggs_res.iter_mut() {
            if let Some(key) = other.aggs_res.remove(key) {
                left.merge_fruits(key)?;
            }
        }
        // Move remainder of other aggs_res into self.
        // Note: Currently we don't expect this to happen, as we create empty intermediate results
        // via [IntermediateAggregationResults::empty_from_req].
        for (key, value) in other.aggs_res {
            self.aggs_res.insert(key, value);
        }
        Ok(())
    }
}

pub(crate) fn empty_from_req(req: &Aggregation) -> IntermediateAggregationResult {
    use AggregationVariants::*;
    match req.agg {
        Terms(_) => IntermediateAggregationResult::Bucket(IntermediateBucketResult::Terms {
            buckets: Default::default(),
        }),
        Range(_) => IntermediateAggregationResult::Bucket(IntermediateBucketResult::Range(
            Default::default(),
        )),
        Histogram(_) => {
            IntermediateAggregationResult::Bucket(IntermediateBucketResult::Histogram {
                buckets: Vec::new(),
                is_date_agg: false,
            })
        }
        DateHistogram(_) => {
            IntermediateAggregationResult::Bucket(IntermediateBucketResult::Histogram {
                buckets: Vec::new(),
                is_date_agg: true,
            })
        }
        Average(_) => IntermediateAggregationResult::Metric(IntermediateMetricResult::Average(
            IntermediateAverage::default(),
        )),
        Count(_) => IntermediateAggregationResult::Metric(IntermediateMetricResult::Count(
            IntermediateCount::default(),
        )),
        Max(_) => IntermediateAggregationResult::Metric(IntermediateMetricResult::Max(
            IntermediateMax::default(),
        )),
        Min(_) => IntermediateAggregationResult::Metric(IntermediateMetricResult::Min(
            IntermediateMin::default(),
        )),
        Stats(_) => IntermediateAggregationResult::Metric(IntermediateMetricResult::Stats(
            IntermediateStats::default(),
        )),
        ExtendedStats(_) => IntermediateAggregationResult::Metric(
            IntermediateMetricResult::ExtendedStats(IntermediateExtendedStats::default()),
        ),
        Sum(_) => IntermediateAggregationResult::Metric(IntermediateMetricResult::Sum(
            IntermediateSum::default(),
        )),
        Percentiles(_) => IntermediateAggregationResult::Metric(
            IntermediateMetricResult::Percentiles(PercentilesCollector::default()),
        ),
        TopHits(ref req) => IntermediateAggregationResult::Metric(
            IntermediateMetricResult::TopHits(TopHitsTopNComputer::new(req)),
        ),
        Cardinality(_) => IntermediateAggregationResult::Metric(
            IntermediateMetricResult::Cardinality(CardinalityCollector::default()),
        ),
        Filter(_) => IntermediateAggregationResult::Bucket(IntermediateBucketResult::Filter {
            doc_count: 0,
            sub_aggregations: IntermediateAggregationResults::default(),
        }),
        Composite(_) => {
            IntermediateAggregationResult::Bucket(IntermediateBucketResult::Composite {
                buckets: IntermediateCompositeBucketResult::default(),
            })
        }
        MultiTerms(_) => {
            IntermediateAggregationResult::Bucket(IntermediateBucketResult::MultiTerms {
                buckets: Default::default(),
            })
        }
    }
}

/// An aggregation is either a bucket or a metric.
#[derive(Clone, Debug, Serialize, Deserialize)]
#[allow(clippy::large_enum_variant)]
pub enum IntermediateAggregationResult {
    /// Bucket variant
    Bucket(IntermediateBucketResult),
    /// Metric variant
    Metric(IntermediateMetricResult),
}

impl IntermediateAggregationResult {
    pub(crate) fn into_final_result(
        self,
        req: &Aggregation,
        limits: &mut AggregationLimitsGuard,
    ) -> crate::Result<AggregationResult> {
        let res = match self {
            IntermediateAggregationResult::Bucket(bucket) => {
                AggregationResult::BucketResult(bucket.into_final_bucket_result(req, limits)?)
            }
            IntermediateAggregationResult::Metric(metric) => {
                AggregationResult::MetricResult(metric.into_final_metric_result(req))
            }
        };
        Ok(res)
    }
    fn merge_fruits(&mut self, other: IntermediateAggregationResult) -> crate::Result<()> {
        match (self, other) {
            (
                IntermediateAggregationResult::Bucket(b1),
                IntermediateAggregationResult::Bucket(b2),
            ) => b1.merge_fruits(b2),
            (
                IntermediateAggregationResult::Metric(m1),
                IntermediateAggregationResult::Metric(m2),
            ) => m1.merge_fruits(m2),
            _ => panic!("aggregation result type mismatch (mixed metric and buckets)"),
        }
    }

    pub(crate) fn get_value_from_aggregation(
        &self,
        _name: &str,
        agg_property: &str,
    ) -> crate::Result<Option<f64>> {
        match self {
            IntermediateAggregationResult::Bucket(_) => Err(TantivyError::InternalError(
                "Tried to retrieve value from bucket aggregation. This is not supported and \
                 should not happen during collection phase, but should be caught during validation"
                    .to_string(),
            )),
            IntermediateAggregationResult::Metric(metric) => metric.get_value(agg_property),
        }
    }

    pub(crate) fn prune_intermediate_results(
        &mut self,
        req: &Aggregation,
        mode: PruneMode,
    ) -> crate::Result<()> {
        match self {
            IntermediateAggregationResult::Bucket(bucket) => {
                bucket.prune_intermediate_results(req, mode)
            }
            IntermediateAggregationResult::Metric(_) => Ok(()),
        }
    }
}

/// Holds the intermediate data for metric results
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum IntermediateMetricResult {
    /// Intermediate average result.
    Percentiles(PercentilesCollector),
    /// Intermediate average result.
    Average(IntermediateAverage),
    /// Intermediate count result.
    Count(IntermediateCount),
    /// Intermediate max result.
    Max(IntermediateMax),
    /// Intermediate min result.
    Min(IntermediateMin),
    /// Intermediate stats result.
    Stats(IntermediateStats),
    /// Intermediate stats result.
    ExtendedStats(IntermediateExtendedStats),
    /// Intermediate sum result.
    Sum(IntermediateSum),
    /// Intermediate top_hits result
    TopHits(TopHitsTopNComputer),
    /// Intermediate cardinality result
    Cardinality(CardinalityCollector),
}

impl IntermediateMetricResult {
    fn into_final_metric_result(self, req: &Aggregation) -> MetricResult {
        match self {
            IntermediateMetricResult::Average(intermediate_avg) => {
                MetricResult::Average(intermediate_avg.finalize().into())
            }
            IntermediateMetricResult::Count(intermediate_count) => {
                MetricResult::Count(intermediate_count.finalize().into())
            }
            IntermediateMetricResult::Max(intermediate_max) => {
                MetricResult::Max(intermediate_max.finalize().into())
            }
            IntermediateMetricResult::Min(intermediate_min) => {
                MetricResult::Min(intermediate_min.finalize().into())
            }
            IntermediateMetricResult::Stats(intermediate_stats) => {
                MetricResult::Stats(intermediate_stats.finalize())
            }
            IntermediateMetricResult::ExtendedStats(intermediate_stats) => {
                MetricResult::ExtendedStats(intermediate_stats.finalize())
            }
            IntermediateMetricResult::Sum(intermediate_sum) => {
                // By default match Elasticsearch: empty / all-missing sum
                // buckets serialize as `"value": 0`, not `"value": null`.
                // The non-ES `none_if_no_match` flag on `SumAggregation`
                // opts into SQL-style `null` for downstream consumers.
                let none_if_no_match = req
                    .agg
                    .as_sum()
                    .and_then(|sum| sum.none_if_no_match)
                    .unwrap_or(false);
                let value = intermediate_sum.finalize();
                if none_if_no_match {
                    MetricResult::Sum(value.into())
                } else {
                    let value = Some(value.unwrap_or(0.0));
                    MetricResult::Sum(value.into())
                }
            }
            IntermediateMetricResult::Percentiles(percentiles) => MetricResult::Percentiles(
                percentiles
                    .into_final_result(req.agg.as_percentile().expect("unexpected metric type")),
            ),
            IntermediateMetricResult::TopHits(top_hits) => {
                MetricResult::TopHits(top_hits.into_final_result())
            }
            IntermediateMetricResult::Cardinality(cardinality) => {
                MetricResult::Cardinality(cardinality.finalize().into())
            }
        }
    }

    pub(crate) fn get_value(&self, agg_property: &str) -> crate::Result<Option<f64>> {
        match self {
            IntermediateMetricResult::Average(avg) => Ok(avg.finalize()),
            IntermediateMetricResult::Count(count) => Ok(count.finalize()),
            IntermediateMetricResult::Max(max) => Ok(max.finalize()),
            IntermediateMetricResult::Min(min) => Ok(min.finalize()),
            IntermediateMetricResult::Stats(stats) => stats.finalize().get_value(agg_property),
            IntermediateMetricResult::ExtendedStats(stats) => {
                stats.finalize().get_value(agg_property)
            }
            IntermediateMetricResult::Sum(sum) => Ok(sum.finalize()),
            IntermediateMetricResult::Percentiles(collector) => {
                let percentile: f64 = agg_property.parse().map_err(|_| {
                    TantivyError::AggregationError(AggregationError::InvalidRequest(format!(
                        "percentile property {agg_property:?} is not a valid number"
                    )))
                })?;
                collector.get_percentile(percentile)
            }
            IntermediateMetricResult::TopHits(_) => Err(TantivyError::AggregationError(
                AggregationError::InvalidRequest("top_hits can't be used to order".to_string()),
            )),
            IntermediateMetricResult::Cardinality(card) => Ok(card.clone().finalize()),
        }
    }

    // TODO: this is our top-of-the-chain fruit merge mech
    fn merge_fruits(&mut self, other: IntermediateMetricResult) -> crate::Result<()> {
        match (self, other) {
            (
                IntermediateMetricResult::Average(avg_left),
                IntermediateMetricResult::Average(avg_right),
            ) => {
                avg_left.merge_fruits(avg_right);
            }
            (
                IntermediateMetricResult::Count(count_left),
                IntermediateMetricResult::Count(count_right),
            ) => {
                count_left.merge_fruits(count_right);
            }
            (IntermediateMetricResult::Max(max_left), IntermediateMetricResult::Max(max_right)) => {
                max_left.merge_fruits(max_right);
            }
            (IntermediateMetricResult::Min(min_left), IntermediateMetricResult::Min(min_right)) => {
                min_left.merge_fruits(min_right);
            }
            (
                IntermediateMetricResult::Stats(stats_left),
                IntermediateMetricResult::Stats(stats_right),
            ) => {
                stats_left.merge_fruits(stats_right);
            }
            (
                IntermediateMetricResult::ExtendedStats(extended_stats_left),
                IntermediateMetricResult::ExtendedStats(extended_stats_right),
            ) => {
                extended_stats_left.merge_fruits(extended_stats_right);
            }
            (IntermediateMetricResult::Sum(sum_left), IntermediateMetricResult::Sum(sum_right)) => {
                sum_left.merge_fruits(sum_right);
            }
            (
                IntermediateMetricResult::Percentiles(left),
                IntermediateMetricResult::Percentiles(right),
            ) => {
                left.merge_fruits(right)?;
            }
            (IntermediateMetricResult::TopHits(left), IntermediateMetricResult::TopHits(right)) => {
                left.merge_fruits(right)?;
            }
            (
                IntermediateMetricResult::Cardinality(left),
                IntermediateMetricResult::Cardinality(right),
            ) => {
                left.merge_fruits(right)?;
            }
            _ => {
                panic!("incompatible fruit types in tree or missing merge_fruits handler");
            }
        }

        Ok(())
    }
}

/// The intermediate bucket results. Internally they can be easily merged via the keys of the
/// buckets.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum IntermediateBucketResult {
    /// This is the range entry for a bucket, which contains a key, count, from, to, and optionally
    /// sub_aggregations.
    Range(IntermediateRangeBucketResult),
    /// This is the histogram entry for a bucket, which contains a key, count, and optionally
    /// sub_aggregations.
    Histogram {
        /// The column_type of the underlying `Column` is DateTime
        is_date_agg: bool,
        /// The histogram buckets
        buckets: Vec<IntermediateHistogramBucketEntry>,
    },
    /// Term aggregation
    Terms {
        /// The term buckets
        buckets: IntermediateTermBucketResult,
    },
    /// Filter aggregation - a single bucket with sub-aggregations
    Filter {
        /// Document count in the filter bucket
        doc_count: u64,
        /// Sub-aggregation results
        sub_aggregations: IntermediateAggregationResults,
    },
    /// Composite aggregation
    Composite {
        /// The composite buckets
        buckets: IntermediateCompositeBucketResult,
    },
    /// Multi-terms aggregation
    MultiTerms {
        /// The multi-terms buckets
        buckets: IntermediateMultiTermsBucketResult,
    },
}

impl IntermediateBucketResult {
    pub(crate) fn into_final_bucket_result(
        self,
        req: &Aggregation,
        limits: &mut AggregationLimitsGuard,
    ) -> crate::Result<BucketResult> {
        match self {
            IntermediateBucketResult::Range(range_res) => {
                let mut buckets: Vec<RangeBucketEntry> = range_res
                    .buckets
                    .into_values()
                    .map(|bucket| {
                        bucket.into_final_bucket_entry(
                            req.sub_aggregation(),
                            req.agg
                                .as_range()
                                .expect("unexpected aggregation, expected histogram aggregation"),
                            range_res.column_type,
                            limits,
                        )
                    })
                    .collect::<crate::Result<Vec<_>>>()?;

                buckets.sort_by(|left, right| {
                    left.from
                        .unwrap_or(f64::MIN)
                        .total_cmp(&right.from.unwrap_or(f64::MIN))
                });

                let is_keyed = req
                    .agg
                    .as_range()
                    .expect("unexpected aggregation, expected range aggregation")
                    .keyed;
                let buckets = if is_keyed {
                    let mut bucket_map =
                        FxHashMap::with_capacity_and_hasher(buckets.len(), Default::default());
                    for bucket in buckets {
                        bucket_map.insert(bucket.key.to_string(), bucket);
                    }
                    BucketEntries::HashMap(bucket_map)
                } else {
                    BucketEntries::Vec(buckets)
                };
                Ok(BucketResult::Range { buckets })
            }
            IntermediateBucketResult::Histogram {
                is_date_agg,
                buckets,
            } => {
                let histogram_req = &req
                    .agg
                    .as_histogram()?
                    .expect("unexpected aggregation, expected histogram aggregation");
                let buckets = intermediate_histogram_buckets_to_final_buckets(
                    buckets,
                    is_date_agg,
                    histogram_req,
                    req.sub_aggregation(),
                    limits,
                )?;

                let buckets = if histogram_req.keyed {
                    let mut bucket_map =
                        FxHashMap::with_capacity_and_hasher(buckets.len(), Default::default());
                    for bucket in buckets {
                        bucket_map.insert(bucket.key.to_string(), bucket);
                    }
                    BucketEntries::HashMap(bucket_map)
                } else {
                    BucketEntries::Vec(buckets)
                };
                Ok(BucketResult::Histogram { buckets })
            }
            IntermediateBucketResult::Terms { buckets: terms } => terms.into_final_result(
                req.agg
                    .as_term()
                    .expect("unexpected aggregation, expected term aggregation"),
                req.sub_aggregation(),
                limits,
            ),
            IntermediateBucketResult::Filter {
                doc_count,
                sub_aggregations,
            } => {
                // Convert sub-aggregation results to final format
                let final_sub_aggregations = sub_aggregations
                    .into_final_result(req.sub_aggregation().clone(), limits.clone())?;
                Ok(BucketResult::Filter(FilterBucketResult {
                    doc_count,
                    sub_aggregations: final_sub_aggregations,
                }))
            }
            IntermediateBucketResult::Composite { buckets } => {
                let composite_req = req
                    .agg
                    .as_composite()
                    .expect("unexpected aggregation, expected composite aggregation");
                buckets.into_final_result(composite_req, req.sub_aggregation(), limits)
            }
            IntermediateBucketResult::MultiTerms { buckets } => {
                let multi_terms_req = req
                    .agg
                    .as_multi_terms()
                    .expect("unexpected aggregation, expected multi_terms aggregation");
                buckets.into_final_result(multi_terms_req, req.sub_aggregation(), limits)
            }
        }
    }

    pub(crate) fn prune_intermediate_results(
        &mut self,
        req: &Aggregation,
        mode: PruneMode,
    ) -> crate::Result<()> {
        match self {
            IntermediateBucketResult::Terms { buckets } => {
                let terms_req = req
                    .agg
                    .as_term()
                    .expect("unexpected aggregation, expected term aggregation");
                buckets.prune_intermediate_results(terms_req, req.sub_aggregation(), mode)
            }
            IntermediateBucketResult::Range(range_res) => {
                for entry in range_res.buckets.values_mut() {
                    entry
                        .sub_aggregation_res
                        .prune_intermediate_results(req.sub_aggregation(), mode)?;
                }
                Ok(())
            }
            IntermediateBucketResult::Histogram { buckets, .. } => {
                for entry in buckets.iter_mut() {
                    entry
                        .sub_aggregation
                        .prune_intermediate_results(req.sub_aggregation(), mode)?;
                }
                Ok(())
            }
            IntermediateBucketResult::Filter {
                sub_aggregations, ..
            } => sub_aggregations.prune_intermediate_results(req.sub_aggregation(), mode),
            IntermediateBucketResult::Composite { buckets } => {
                if mode == PruneMode::Final {
                    buckets.trim()?;
                }
                for entry in buckets.entries.values_mut() {
                    entry
                        .sub_aggregation
                        .prune_intermediate_results(req.sub_aggregation(), mode)?;
                }
                Ok(())
            }
            IntermediateBucketResult::MultiTerms { buckets } => {
                let multi_terms_req = req
                    .agg
                    .as_multi_terms()
                    .expect("unexpected aggregation, expected multi_terms aggregation");
                buckets.prune_intermediate_results(multi_terms_req, req.sub_aggregation(), mode)
            }
        }
    }

    fn merge_fruits(&mut self, other: IntermediateBucketResult) -> crate::Result<()> {
        match (self, other) {
            (
                IntermediateBucketResult::Terms {
                    buckets: term_res_left,
                },
                IntermediateBucketResult::Terms {
                    buckets: term_res_right,
                },
            ) => {
                term_res_left.merge(term_res_right)?;
            }

            (
                IntermediateBucketResult::Range(range_res_left),
                IntermediateBucketResult::Range(range_res_right),
            ) => {
                merge_maps(&mut range_res_left.buckets, range_res_right.buckets)?;
            }
            (
                IntermediateBucketResult::Histogram {
                    buckets: buckets_left,
                    is_date_agg: _,
                },
                IntermediateBucketResult::Histogram {
                    buckets: buckets_right,
                    is_date_agg: _,
                },
            ) => {
                let buckets: Result<Vec<IntermediateHistogramBucketEntry>, TantivyError> =
                    buckets_left
                        .drain(..)
                        .merge_join_by(buckets_right, |left, right| {
                            left.key.partial_cmp(&right.key).unwrap_or(Ordering::Equal)
                        })
                        .map(|either| match either {
                            itertools::EitherOrBoth::Both(mut left, right) => {
                                left.merge_fruits(right)?;
                                Ok(left)
                            }
                            itertools::EitherOrBoth::Left(left) => Ok(left),
                            itertools::EitherOrBoth::Right(right) => Ok(right),
                        })
                        .collect::<Result<_, _>>();

                *buckets_left = buckets?;
            }
            (
                IntermediateBucketResult::Filter {
                    doc_count: doc_count_left,
                    sub_aggregations: sub_aggs_left,
                },
                IntermediateBucketResult::Filter {
                    doc_count: doc_count_right,
                    sub_aggregations: sub_aggs_right,
                },
            ) => {
                *doc_count_left += doc_count_right;
                sub_aggs_left.merge_fruits(sub_aggs_right)?;
            }
            (
                IntermediateBucketResult::Composite {
                    buckets: composite_left,
                },
                IntermediateBucketResult::Composite {
                    buckets: composite_right,
                },
            ) => {
                composite_left.merge_fruits(composite_right)?;
            }
            (
                IntermediateBucketResult::MultiTerms { buckets: mt_left },
                IntermediateBucketResult::MultiTerms { buckets: mt_right },
            ) => {
                merge_maps(&mut mt_left.entries, mt_right.entries)?;
                mt_left.sum_other_doc_count += mt_right.sum_other_doc_count;
                mt_left.doc_count_error_upper_bound += mt_right.doc_count_error_upper_bound;
            }
            (IntermediateBucketResult::Range(_), _) => {
                panic!("try merge on different types")
            }
            (IntermediateBucketResult::Histogram { .. }, _) => {
                panic!("try merge on different types")
            }
            (IntermediateBucketResult::Terms { .. }, _) => {
                panic!("try merge on different types")
            }
            (IntermediateBucketResult::Filter { .. }, _) => {
                panic!("try merge on different types")
            }
            (IntermediateBucketResult::Composite { .. }, _) => {
                panic!("try merge on different types")
            }
            (IntermediateBucketResult::MultiTerms { .. }, _) => {
                panic!("try merge on different types")
            }
        }
        Ok(())
    }
}

#[derive(Default, Clone, Debug, Serialize, Deserialize)]
/// Range aggregation including error counts
pub struct IntermediateRangeBucketResult {
    pub(crate) buckets: FxHashMap<SerializedKey, IntermediateRangeBucketEntry>,
    pub(crate) column_type: Option<ColumnType>,
}

#[derive(Default, Clone, Debug, Serialize, Deserialize)]
/// Term aggregation including error counts
pub struct IntermediateTermBucketResult {
    /// Bucket entries as a flat `Vec`, in unspecified order. The final result is sorted by the
    /// requested order (see `into_final_result`).
    #[serde(with = "tuple_vec_map")]
    pub(crate) entries: Vec<(IntermediateKey, IntermediateTermBucketEntry)>,
    pub(crate) sum_other_doc_count: u64,
    pub(crate) doc_count_error_upper_bound: u64,
    /// Transient `key -> position in entries` index, populated lazily on the first merge so that
    /// folding many segment results stays O(total entries) instead of rebuilding a dictionary on
    /// every pairwise merge. Not serialized; rebuilt on demand.
    #[serde(skip)]
    pub(crate) key_to_idx_in_entries: FxHashMap<IntermediateKey, u32>,
}

impl IntermediateTermBucketResult {
    /// Merge `other` into `self` in place.
    ///
    /// The first merge builds `self.key_to_idx_in_entries` (`key -> position`) once; subsequent
    /// merges reuse it, so
    /// each entry is hashed once and the accumulator grows incrementally. This keeps both the
    /// per-segment fold and the cross-node `merge_fruits` fold linear in the total number of
    /// entries. Output order is first-seen: existing keys merge in place, new keys are appended.
    fn merge(&mut self, other: IntermediateTermBucketResult) -> crate::Result<()> {
        self.sum_other_doc_count += other.sum_other_doc_count;
        self.doc_count_error_upper_bound += other.doc_count_error_upper_bound;
        if other.entries.is_empty() {
            return Ok(());
        }
        if self.entries.is_empty() {
            self.entries = other.entries;
            return Ok(());
        }
        if self.key_to_idx_in_entries.is_empty() {
            self.key_to_idx_in_entries
                .reserve(self.entries.len() + other.entries.len());
            for (idx, (key, _)) in self.entries.iter().enumerate() {
                self.key_to_idx_in_entries.insert(key.clone(), idx as u32);
            }
        }
        for (key, bucket) in other.entries {
            if let Some(&idx_in_entries) = self.key_to_idx_in_entries.get(&key) {
                let entry = &mut self.entries[idx_in_entries as usize].1;
                entry.doc_count += bucket.doc_count;
                entry.sub_aggregation.merge_fruits(bucket.sub_aggregation)?;
            } else {
                self.key_to_idx_in_entries
                    .insert(key.clone(), self.entries.len() as u32);
                self.entries.push((key, bucket));
            }
        }
        Ok(())
    }

    /// Returns the bucket entries. Order is unspecified.
    pub fn entries(&self) -> &[(IntermediateKey, IntermediateTermBucketEntry)] {
        &self.entries
    }

    /// Returns the count of documents not included in the returned buckets.
    pub fn sum_other_doc_count(&self) -> u64 {
        self.sum_other_doc_count
    }

    /// Returns the upper bound of the error on document counts in the returned buckets.
    pub fn doc_count_error_upper_bound(&self) -> u64 {
        self.doc_count_error_upper_bound
    }

    pub(crate) fn into_final_result(
        self,
        req: &TermsAggregation,
        sub_aggregation_req: &Aggregations,
        limits: &mut AggregationLimitsGuard,
    ) -> crate::Result<BucketResult> {
        let req = TermsAggregationInternal::from_req(req);
        let mut buckets: Vec<BucketEntry> = self
            .entries
            .into_iter()
            .filter(|bucket| bucket.1.doc_count >= req.min_doc_count)
            .map(|(key, entry)| {
                let key_as_string = match key {
                    IntermediateKey::Bool(key) => {
                        let val = if key { "true" } else { "false" };
                        Some(val.to_string())
                    }
                    _ => None,
                };
                Ok(BucketEntry {
                    key_as_string,
                    key: key.into(),
                    doc_count: entry.doc_count,
                    sub_aggregation: entry
                        .sub_aggregation
                        .into_final_result_internal(sub_aggregation_req, limits)?,
                })
            })
            .collect::<crate::Result<_>>()?;

        let order = req.order.order;
        match req.order.target {
            OrderTarget::Key => {
                buckets.sort_by(|left, right| {
                    if req.order.order == Order::Asc {
                        left.key.cmp(&right.key)
                    } else {
                        right.key.cmp(&left.key)
                    }
                });
            }
            OrderTarget::Count => {
                // Tie-break equal counts by key ascending so the output is deterministic
                // regardless of the merge's (insertion-order) output.
                let key_tie = |left: &BucketEntry, right: &BucketEntry| left.key.cmp(&right.key);
                if req.order.order == Order::Desc {
                    buckets.sort_unstable_by(|left, right| {
                        right
                            .doc_count()
                            .cmp(&left.doc_count())
                            .then_with(|| key_tie(left, right))
                    });
                } else {
                    buckets.sort_unstable_by(|left, right| {
                        left.doc_count()
                            .cmp(&right.doc_count())
                            .then_with(|| key_tie(left, right))
                    });
                }
            }
            OrderTarget::SubAggregation(name) => {
                let (agg_name, agg_property) = get_agg_name_and_property(&name);
                let mut buckets_with_val = buckets
                    .into_iter()
                    .map(|bucket| {
                        let val = bucket
                            .sub_aggregation
                            .get_value_from_aggregation(agg_name, agg_property)?
                            .unwrap_or(f64::MIN);
                        Ok((bucket, val))
                    })
                    .collect::<crate::Result<Vec<_>>>()?;

                buckets_with_val.sort_by(|(_, val1), (_, val2)| match &order {
                    Order::Desc => val2.total_cmp(val1),
                    Order::Asc => val1.total_cmp(val2),
                });
                buckets = buckets_with_val
                    .into_iter()
                    .map(|(bucket, _val)| bucket)
                    .collect_vec();
            }
        }

        // We ignore _term_doc_count_before_cutoff here, because it increases the upperbound error
        // only for terms that didn't make it into the top N.
        //
        // This can be interesting, as a value of quality of the results, but not good to check the
        // actual error count for the returned terms.
        let (_term_doc_count_before_cutoff, sum_other_doc_count) =
            cut_off_buckets(&mut buckets, req.size as usize, None);

        let doc_count_error_upper_bound = if req.show_term_doc_count_error {
            Some(self.doc_count_error_upper_bound)
        } else {
            None
        };

        Ok(BucketResult::Terms {
            buckets,
            sum_other_doc_count: self.sum_other_doc_count + sum_other_doc_count,
            doc_count_error_upper_bound,
        })
    }

    pub(crate) fn prune_intermediate_results(
        &mut self,
        req: &TermsAggregation,
        sub_aggregation_req: &Aggregations,
        mode: PruneMode,
    ) -> crate::Result<()> {
        let req_internal = TermsAggregationInternal::from_req(req);
        // Pruning changes entry positions, invalidating the transient merge index.
        self.key_to_idx_in_entries.clear();
        let size = if mode == PruneMode::Final {
            let min_doc_count = req_internal.min_doc_count;
            self.entries
                .retain(|(_, entry)| entry.doc_count >= min_doc_count);
            req_internal.size as usize
        } else {
            req_internal.segment_size as usize
        };

        if self.entries.len() > size {
            let mut entries = std::mem::take(&mut self.entries);

            match &req_internal.order.target {
                OrderTarget::SubAggregation(sub_agg_path) => {
                    let (agg_name, agg_prop) = get_agg_name_and_property(sub_agg_path);
                    let mut keyed: Vec<(f64, (IntermediateKey, IntermediateTermBucketEntry))> =
                        entries
                            .into_iter()
                            .map(|entry| {
                                let val = entry
                                    .1
                                    .sub_aggregation
                                    .get_value_from_aggregation(agg_name, agg_prop)
                                    .ok()
                                    .flatten()
                                    .unwrap_or(f64::MIN);
                                (val, entry)
                            })
                            .collect();
                    if req_internal.order.order == Order::Desc {
                        keyed.select_nth_unstable_by(size, |a, b| b.0.total_cmp(&a.0));
                    } else {
                        keyed.select_nth_unstable_by(size, |a, b| a.0.total_cmp(&b.0));
                    }
                    entries = keyed.into_iter().map(|(_, entry)| entry).collect();
                }
                OrderTarget::Key => {
                    let mut keyed: Vec<(Key, (IntermediateKey, IntermediateTermBucketEntry))> =
                        entries
                            .into_iter()
                            .map(|entry| (entry.0.clone().into(), entry))
                            .collect();
                    if req_internal.order.order == Order::Desc {
                        keyed.select_nth_unstable_by(size, |(k1, _), (k2, _)| k2.cmp(k1));
                    } else {
                        keyed.select_nth_unstable_by(size, |(k1, _), (k2, _)| k1.cmp(k2));
                    }
                    entries = keyed.into_iter().map(|(_, entry)| entry).collect();
                }
                OrderTarget::Count => {
                    // Match the final result ordering at every pruning level: equal counts are
                    // ordered by key ascending, making the selected bucket set deterministic.
                    let mut keyed: Vec<(Key, (IntermediateKey, IntermediateTermBucketEntry))> =
                        entries
                            .into_iter()
                            .map(|entry| (entry.0.clone().into(), entry))
                            .collect();
                    if req_internal.order.order == Order::Desc {
                        keyed.select_nth_unstable_by(
                            size,
                            |(left_key, (_, left)), (right_key, (_, right))| {
                                right
                                    .doc_count
                                    .cmp(&left.doc_count)
                                    .then_with(|| left_key.cmp(right_key))
                            },
                        );
                    } else {
                        keyed.select_nth_unstable_by(
                            size,
                            |(left_key, (_, left)), (right_key, (_, right))| {
                                left.doc_count
                                    .cmp(&right.doc_count)
                                    .then_with(|| left_key.cmp(right_key))
                            },
                        );
                    }
                    entries = keyed.into_iter().map(|(_, entry)| entry).collect();
                }
            }
            let cutoff_doc_count = entries[size].1.doc_count;
            self.sum_other_doc_count += entries[size..]
                .iter()
                .map(|(_, e)| e.doc_count)
                .sum::<u64>();
            if mode == PruneMode::Intermediate {
                self.doc_count_error_upper_bound += cutoff_doc_count;
            }
            entries.truncate(size);
            self.entries = entries;
        }

        for (_, entry) in &mut self.entries {
            entry
                .sub_aggregation
                .prune_intermediate_results(sub_aggregation_req, mode)?;
        }

        Ok(())
    }
}

trait MergeFruits {
    fn merge_fruits(&mut self, other: Self) -> crate::Result<()>;
}

fn merge_maps<V: MergeFruits + Clone, T: Eq + PartialEq + Hash>(
    entries_left: &mut FxHashMap<T, V>,
    mut entries_right: FxHashMap<T, V>,
) -> crate::Result<()> {
    for (name, entry_left) in entries_left.iter_mut() {
        if let Some(entry_right) = entries_right.remove(name) {
            entry_left.merge_fruits(entry_right)?;
        }
    }

    for (key, res) in entries_right.into_iter() {
        entries_left.entry(key).or_insert(res);
    }
    Ok(())
}

/// This is the histogram entry for a bucket, which contains a key, count, and optionally
/// sub_aggregations.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct IntermediateHistogramBucketEntry {
    /// The unique the bucket is identified.
    pub key: f64,
    /// The number of documents in the bucket.
    pub doc_count: u64,
    /// The sub_aggregation in this bucket.
    pub sub_aggregation: IntermediateAggregationResults,
}

impl IntermediateHistogramBucketEntry {
    pub(crate) fn into_final_bucket_entry(
        self,
        req: &Aggregations,
        limits: &mut AggregationLimitsGuard,
    ) -> crate::Result<BucketEntry> {
        Ok(BucketEntry {
            key_as_string: None,
            key: Key::F64(self.key),
            doc_count: self.doc_count,
            sub_aggregation: self
                .sub_aggregation
                .into_final_result_internal(req, limits)?,
        })
    }
}

/// This is the range entry for a bucket, which contains a key, count, and optionally
/// sub_aggregations.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct IntermediateRangeBucketEntry {
    /// The unique key the bucket is identified with.
    pub key: IntermediateKey,
    /// The number of documents in the bucket.
    pub doc_count: u64,
    /// The sub_aggregation in this bucket.
    pub sub_aggregation_res: IntermediateAggregationResults,
    /// The from range of the bucket. Equals `f64::MIN` when `None`.
    pub from: Option<f64>,
    /// The to range of the bucket. Equals `f64::MAX` when `None`.
    pub to: Option<f64>,
}

impl IntermediateRangeBucketEntry {
    pub(crate) fn into_final_bucket_entry(
        self,
        req: &Aggregations,
        _range_req: &RangeAggregation,
        column_type: Option<ColumnType>,
        limits: &mut AggregationLimitsGuard,
    ) -> crate::Result<RangeBucketEntry> {
        let mut range_bucket_entry = RangeBucketEntry {
            key: self.key.into(),
            doc_count: self.doc_count,
            sub_aggregation: self
                .sub_aggregation_res
                .into_final_result_internal(req, limits)?,
            to: self.to,
            from: self.from,
            to_as_string: None,
            from_as_string: None,
        };

        // If we have a date type on the histogram buckets, we add the `key_as_string` field as
        // rfc3339
        if column_type == Some(ColumnType::DateTime) {
            if let Some(val) = range_bucket_entry.to {
                let key_as_string = format_date(val as i64)?;
                range_bucket_entry.to_as_string = Some(key_as_string);
            }
            if let Some(val) = range_bucket_entry.from {
                let key_as_string = format_date(val as i64)?;
                range_bucket_entry.from_as_string = Some(key_as_string);
            }
        }

        Ok(range_bucket_entry)
    }
}

/// This is the term entry for a bucket, which contains a count, and optionally
/// sub_aggregations.
#[derive(Clone, Default, Debug, Serialize, Deserialize)]
pub struct IntermediateTermBucketEntry {
    /// The number of documents in the bucket.
    pub doc_count: u64,
    /// The sub_aggregation in this bucket.
    pub sub_aggregation: IntermediateAggregationResults,
}

impl MergeFruits for IntermediateTermBucketEntry {
    fn merge_fruits(&mut self, other: IntermediateTermBucketEntry) -> crate::Result<()> {
        self.doc_count += other.doc_count;
        self.sub_aggregation.merge_fruits(other.sub_aggregation)?;
        Ok(())
    }
}

impl MergeFruits for IntermediateRangeBucketEntry {
    fn merge_fruits(&mut self, other: IntermediateRangeBucketEntry) -> crate::Result<()> {
        self.doc_count += other.doc_count;
        self.sub_aggregation_res
            .merge_fruits(other.sub_aggregation_res)?;
        Ok(())
    }
}

impl MergeFruits for IntermediateHistogramBucketEntry {
    fn merge_fruits(&mut self, other: IntermediateHistogramBucketEntry) -> crate::Result<()> {
        self.doc_count += other.doc_count;
        self.sub_aggregation.merge_fruits(other.sub_aggregation)?;
        Ok(())
    }
}

/// Entry for the composite bucket.
pub type IntermediateCompositeBucketEntry = IntermediateTermBucketEntry;

/// The fully typed key for composite aggregation
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum CompositeIntermediateKey {
    /// Bool key
    Bool(bool),
    /// String key
    Str(String),
    /// Float key
    F64(f64),
    /// Signed integer key
    I64(i64),
    /// Unsigned integer key
    U64(u64),
    /// DateTime key, nanoseconds since epoch
    DateTime(i64),
    /// IP Address key
    IpAddr(Ipv6Addr),
    /// Missing value key
    Null,
}

impl Eq for CompositeIntermediateKey {}

impl std::hash::Hash for CompositeIntermediateKey {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        core::mem::discriminant(self).hash(state);
        match self {
            CompositeIntermediateKey::Bool(val) => val.hash(state),
            CompositeIntermediateKey::Str(text) => text.hash(state),
            CompositeIntermediateKey::F64(val) => val.to_bits().hash(state),
            CompositeIntermediateKey::U64(val) => val.hash(state),
            CompositeIntermediateKey::I64(val) => val.hash(state),
            CompositeIntermediateKey::DateTime(val) => val.hash(state),
            CompositeIntermediateKey::IpAddr(val) => val.hash(state),
            CompositeIntermediateKey::Null => {}
        }
    }
}

/// Composite aggregation page.
#[derive(Default, Clone, Debug, Serialize, Deserialize)]
pub struct IntermediateCompositeBucketResult {
    pub(crate) entries: FxHashMap<Vec<CompositeIntermediateKey>, IntermediateCompositeBucketEntry>,
    pub(crate) target_size: u32,
    pub(crate) orders: Vec<(Order, MissingOrder)>,
}

impl IntermediateCompositeBucketResult {
    pub(crate) fn into_final_result(
        self,
        req: &CompositeAggregation,
        sub_aggregation_req: &Aggregations,
        limits: &mut AggregationLimitsGuard,
    ) -> crate::Result<BucketResult> {
        let trimmed_entry_vec =
            trim_composite_buckets(self.entries, &self.orders, self.target_size)?;
        let after_key = trimmed_entry_vec
            .last()
            .map(|bucket| {
                let (intermediate_key, _entry) = bucket;
                intermediate_key
                    .iter()
                    .enumerate()
                    .map(|(idx, intermediate_key)| {
                        let source = &req.sources[idx];
                        (source.name().to_string(), intermediate_key.clone().into())
                    })
                    .collect()
            })
            .unwrap_or_default();

        let buckets = trimmed_entry_vec
            .into_iter()
            .map(|(intermediate_key, entry)| {
                let key = intermediate_key
                    .into_iter()
                    .enumerate()
                    .map(|(idx, intermediate_key)| {
                        let source = &req.sources[idx];
                        (source.name().to_string(), intermediate_key.into())
                    })
                    .collect();
                Ok(CompositeBucketEntry {
                    key,
                    doc_count: entry.doc_count,
                    sub_aggregation: entry
                        .sub_aggregation
                        .into_final_result_internal(sub_aggregation_req, limits)?,
                })
            })
            .collect::<crate::Result<Vec<_>>>()?;

        Ok(BucketResult::Composite { after_key, buckets })
    }

    fn merge_fruits(&mut self, other: IntermediateCompositeBucketResult) -> crate::Result<()> {
        merge_maps(&mut self.entries, other.entries)?;
        if self.entries.len() as u32 > 2 * self.target_size {
            self.trim()?;
        }
        Ok(())
    }

    /// Trim the composite buckets to the target size, according to the ordering.
    pub(crate) fn trim(&mut self) -> crate::Result<()> {
        if self.entries.len() as u32 <= self.target_size {
            return Ok(());
        }

        let sorted_entries = trim_composite_buckets(
            std::mem::take(&mut self.entries),
            &self.orders,
            self.target_size,
        )?;

        self.entries = sorted_entries.into_iter().collect();
        Ok(())
    }
}

fn trim_composite_buckets(
    entries: FxHashMap<Vec<CompositeIntermediateKey>, IntermediateCompositeBucketEntry>,
    orders: &[(Order, MissingOrder)],
    target_size: u32,
) -> crate::Result<
    Vec<(
        Vec<CompositeIntermediateKey>,
        IntermediateCompositeBucketEntry,
    )>,
> {
    let mut entries: Vec<_> = entries.into_iter().collect();
    let mut sort_error: Option<TantivyError> = None;
    entries.sort_by(|(left_key, _), (right_key, _)| {
        if sort_error.is_some() {
            return Ordering::Equal;
        }

        for idx in 0..orders.len() {
            match composite_intermediate_key_ordering(
                &left_key[idx],
                &right_key[idx],
                orders[idx].0,
                orders[idx].1,
            ) {
                Ok(ordering) if ordering != Ordering::Equal => return ordering,
                Ok(_) => continue,
                Err(err) => {
                    sort_error = Some(err);
                    break;
                }
            }
        }
        Ordering::Equal
    });

    if let Some(err) = sort_error {
        return Err(err);
    }

    entries.truncate(target_size as usize);
    Ok(entries)
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use pretty_assertions::assert_eq;

    use super::*;

    #[test]
    fn test_deserialize_legacy_postcard_term_result() {
        // Quickwit sends intermediate aggregation results between nodes, which may run different
        // versions during a rollout. This fixture ensures the wire format of existing aggregations
        // remains readable. It was generated with commit 8e7e157f1, where term entries were stored
        // in an FxHashMap, and contains one terms bucket with a nested histogram bucket.
        const POSTCARD_FIXTURE: &[u8] = &[
            1, 1, 116, 0, 2, 1, 5, 0, 1, 1, 1, 104, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 3, 4,
        ];

        let mut result: IntermediateAggregationResults =
            postcard::from_bytes(POSTCARD_FIXTURE).unwrap();
        let IntermediateAggregationResult::Bucket(IntermediateBucketResult::Terms { buckets }) =
            result.aggs_res.remove("t").unwrap()
        else {
            panic!("expected terms aggregation");
        };
        assert_eq!(buckets.sum_other_doc_count, 3);
        assert_eq!(buckets.doc_count_error_upper_bound, 4);
        let [(IntermediateKey::U64(0), term_entry)] = buckets.entries.as_slice() else {
            panic!("expected one u64 term bucket");
        };
        assert_eq!(term_entry.doc_count, 1);

        let IntermediateAggregationResult::Bucket(IntermediateBucketResult::Histogram {
            is_date_agg,
            buckets,
        }) = term_entry.sub_aggregation.aggs_res.get("h").unwrap()
        else {
            panic!("expected nested histogram aggregation");
        };
        assert!(!is_date_agg);
        assert_eq!(buckets.len(), 1);
        assert_eq!(buckets[0].key, 0.0);
        assert_eq!(buckets[0].doc_count, 2);
        assert!(buckets[0].sub_aggregation.aggs_res.is_empty());
    }

    fn get_sub_test_tree(data: &[(String, u64)]) -> IntermediateAggregationResults {
        let mut map = HashMap::new();
        let mut buckets = FxHashMap::default();
        for (key, doc_count) in data {
            buckets.insert(
                key.to_string(),
                IntermediateRangeBucketEntry {
                    key: IntermediateKey::Str(key.to_string()),
                    doc_count: *doc_count,
                    sub_aggregation_res: Default::default(),
                    from: None,
                    to: None,
                },
            );
        }
        map.insert(
            "my_agg_level2".to_string(),
            IntermediateAggregationResult::Bucket(IntermediateBucketResult::Range(
                IntermediateRangeBucketResult {
                    buckets,
                    column_type: None,
                },
            )),
        );
        IntermediateAggregationResults {
            aggs_res: map.into_iter().collect(),
        }
    }

    fn get_intermediate_tree_with_ranges(
        data: &[(String, u64, String, u64)],
    ) -> IntermediateAggregationResults {
        let mut map = HashMap::new();
        let mut buckets: FxHashMap<_, _> = Default::default();
        for (key, doc_count, sub_aggregation_key, sub_aggregation_count) in data {
            buckets.insert(
                key.to_string(),
                IntermediateRangeBucketEntry {
                    key: IntermediateKey::Str(key.to_string()),
                    doc_count: *doc_count,
                    from: None,
                    to: None,
                    sub_aggregation_res: get_sub_test_tree(&[(
                        sub_aggregation_key.to_string(),
                        *sub_aggregation_count,
                    )]),
                },
            );
        }
        map.insert(
            "my_agg_level1".to_string(),
            IntermediateAggregationResult::Bucket(IntermediateBucketResult::Range(
                IntermediateRangeBucketResult {
                    buckets,
                    column_type: None,
                },
            )),
        );
        IntermediateAggregationResults {
            aggs_res: map.into_iter().collect(),
        }
    }

    fn assert_range_trees_eq(
        actual: &IntermediateAggregationResults,
        expected: &IntermediateAggregationResults,
    ) {
        assert_eq!(actual.aggs_res.len(), expected.aggs_res.len());
        for (name, actual_result) in &actual.aggs_res {
            let expected_result = expected.aggs_res.get(name).unwrap();
            let (
                IntermediateAggregationResult::Bucket(IntermediateBucketResult::Range(
                    actual_range,
                )),
                IntermediateAggregationResult::Bucket(IntermediateBucketResult::Range(
                    expected_range,
                )),
            ) = (actual_result, expected_result)
            else {
                panic!("expected range aggregation results");
            };
            assert_eq!(actual_range.column_type, expected_range.column_type);
            assert_eq!(actual_range.buckets.len(), expected_range.buckets.len());
            for (key, actual_entry) in &actual_range.buckets {
                let expected_entry = expected_range.buckets.get(key).unwrap();
                assert_eq!(actual_entry.key, expected_entry.key);
                assert_eq!(actual_entry.doc_count, expected_entry.doc_count);
                assert_eq!(actual_entry.from, expected_entry.from);
                assert_eq!(actual_entry.to, expected_entry.to);
                assert_range_trees_eq(
                    &actual_entry.sub_aggregation_res,
                    &expected_entry.sub_aggregation_res,
                );
            }
        }
    }

    #[test]
    fn test_merge_fruits_tree_1() {
        let mut tree_left = get_intermediate_tree_with_ranges(&[
            ("red".to_string(), 50, "1900".to_string(), 25),
            ("blue".to_string(), 30, "1900".to_string(), 30),
        ]);
        let tree_right = get_intermediate_tree_with_ranges(&[
            ("red".to_string(), 60, "1900".to_string(), 30),
            ("blue".to_string(), 25, "1900".to_string(), 50),
        ]);

        tree_left.merge_fruits(tree_right).unwrap();

        let tree_expected = get_intermediate_tree_with_ranges(&[
            ("red".to_string(), 110, "1900".to_string(), 55),
            ("blue".to_string(), 55, "1900".to_string(), 80),
        ]);

        assert_range_trees_eq(&tree_left, &tree_expected);
    }

    #[test]
    fn test_merge_fruits_tree_2() {
        let mut tree_left = get_intermediate_tree_with_ranges(&[
            ("red".to_string(), 50, "1900".to_string(), 25),
            ("blue".to_string(), 30, "1900".to_string(), 30),
        ]);
        let tree_right = get_intermediate_tree_with_ranges(&[
            ("red".to_string(), 60, "1900".to_string(), 30),
            ("green".to_string(), 25, "1900".to_string(), 50),
        ]);

        tree_left.merge_fruits(tree_right).unwrap();

        let tree_expected = get_intermediate_tree_with_ranges(&[
            ("red".to_string(), 110, "1900".to_string(), 55),
            ("blue".to_string(), 30, "1900".to_string(), 30),
            ("green".to_string(), 25, "1900".to_string(), 50),
        ]);

        assert_range_trees_eq(&tree_left, &tree_expected);
    }

    #[test]
    fn test_prune_intermediate_results_finalizer_size() {
        use crate::aggregation::bucket::TermsAggregation;

        let mut buckets: FxHashMap<IntermediateKey, IntermediateTermBucketEntry> =
            FxHashMap::default();
        for (key, count) in [("a", 10u64), ("b", 5), ("c", 20), ("d", 1), ("e", 15)] {
            buckets.insert(
                IntermediateKey::Str(key.to_string()),
                IntermediateTermBucketEntry {
                    doc_count: count,
                    sub_aggregation: Default::default(),
                },
            );
        }
        let mut term_result = IntermediateTermBucketResult {
            entries: buckets.into_iter().collect(),
            ..Default::default()
        };

        let req: TermsAggregation =
            serde_json::from_str(r#"{"field": "myfield", "size": 2, "segment_size": 4}"#).unwrap();

        // Final mode, keep top 2 by count: c(20), e(15); prune a(10), b(5), d(1)
        term_result
            .prune_intermediate_results(&req, &Default::default(), PruneMode::Final)
            .unwrap();
        assert_eq!(term_result.entries.len(), 2);
        assert!(term_result
            .entries
            .iter()
            .any(|(key, _)| key == &IntermediateKey::Str("c".to_string())));
        assert!(term_result
            .entries
            .iter()
            .any(|(key, _)| key == &IntermediateKey::Str("e".to_string())));
        assert_eq!(term_result.sum_other_doc_count, 10 + 5 + 1);
        // final-size cutoff doesn't contribute to error bound
        assert_eq!(term_result.doc_count_error_upper_bound, 0);
    }

    #[test]
    fn test_prune_intermediate_results_count_ties_by_key() {
        use crate::aggregation::bucket::TermsAggregation;

        for mode in [PruneMode::Final, PruneMode::Intermediate] {
            for order in ["asc", "desc"] {
                let entries = ["z", "y", "a"]
                    .into_iter()
                    .map(|key| {
                        (
                            IntermediateKey::Str(key.to_string()),
                            IntermediateTermBucketEntry {
                                doc_count: 1,
                                sub_aggregation: Default::default(),
                            },
                        )
                    })
                    .collect();
                let mut term_result = IntermediateTermBucketResult {
                    entries,
                    ..Default::default()
                };
                let req: TermsAggregation = serde_json::from_value(serde_json::json!({
                    "field": "myfield",
                    "size": 1,
                    "segment_size": 1,
                    "order": { "_count": order },
                }))
                .unwrap();

                term_result
                    .prune_intermediate_results(&req, &Default::default(), mode)
                    .unwrap();

                assert_eq!(
                    term_result.entries[0].0,
                    IntermediateKey::Str("a".to_string())
                );
            }
        }
    }

    #[test]
    fn test_prune_intermediate_results_segment_size() {
        use crate::aggregation::bucket::TermsAggregation;

        let mut buckets: FxHashMap<IntermediateKey, IntermediateTermBucketEntry> =
            FxHashMap::default();
        for (key, count) in [("a", 10u64), ("b", 5), ("c", 20), ("d", 1), ("e", 15)] {
            buckets.insert(
                IntermediateKey::Str(key.to_string()),
                IntermediateTermBucketEntry {
                    doc_count: count,
                    sub_aggregation: Default::default(),
                },
            );
        }
        let mut term_result = IntermediateTermBucketResult {
            entries: buckets.into_iter().collect(),
            ..Default::default()
        };

        let req: TermsAggregation =
            serde_json::from_str(r#"{"field": "myfield", "size": 2, "segment_size": 4}"#).unwrap();

        // Intermediate mode, keep top 4 by count: c(20), e(15), a(10), b(5); prune d(1)
        term_result
            .prune_intermediate_results(&req, &Default::default(), PruneMode::Intermediate)
            .unwrap();
        assert_eq!(term_result.entries.len(), 4);
        assert!(!term_result
            .entries
            .iter()
            .any(|(key, _)| key == &IntermediateKey::Str("d".to_string())));
        assert_eq!(term_result.sum_other_doc_count, 1);
        assert_eq!(term_result.doc_count_error_upper_bound, 1);
    }

    #[test]
    fn test_prune_intermediate_results_via_top_level() {
        let mut buckets: FxHashMap<IntermediateKey, IntermediateTermBucketEntry> =
            FxHashMap::default();
        for (key, count) in [("x", 100u64), ("y", 50), ("z", 10)] {
            buckets.insert(
                IntermediateKey::Str(key.to_string()),
                IntermediateTermBucketEntry {
                    doc_count: count,
                    sub_aggregation: Default::default(),
                },
            );
        }
        let mut results = IntermediateAggregationResults::default();
        results.aggs_res.insert(
            "my_terms".to_string(),
            IntermediateAggregationResult::Bucket(IntermediateBucketResult::Terms {
                buckets: IntermediateTermBucketResult {
                    entries: buckets.into_iter().collect(),
                    ..Default::default()
                },
            }),
        );

        let req: crate::aggregation::agg_req::Aggregations =
            serde_json::from_str(r#"{"my_terms": {"terms": {"field": "myfield", "size": 1}}}"#)
                .unwrap();

        results
            .prune_intermediate_results(&req, PruneMode::Final)
            .unwrap();

        let IntermediateAggregationResult::Bucket(IntermediateBucketResult::Terms { buckets }) =
            results.aggs_res.get("my_terms").unwrap()
        else {
            panic!("expected terms bucket");
        };
        assert_eq!(buckets.entries.len(), 1);
        assert!(buckets
            .entries
            .iter()
            .any(|(key, _)| key == &IntermediateKey::Str("x".to_string())));
        assert_eq!(buckets.sum_other_doc_count, 60); // y(50) + z(10)
    }

    #[test]
    fn test_prune_intermediate_results_key_order() {
        use crate::aggregation::bucket::TermsAggregation;

        let mut buckets: FxHashMap<IntermediateKey, IntermediateTermBucketEntry> =
            FxHashMap::default();
        for key in ["a", "b", "c", "d", "e"] {
            buckets.insert(
                IntermediateKey::Str(key.to_string()),
                IntermediateTermBucketEntry {
                    doc_count: 1,
                    sub_aggregation: Default::default(),
                },
            );
        }
        let mut term_result = IntermediateTermBucketResult {
            entries: buckets.into_iter().collect(),
            ..Default::default()
        };

        let req: TermsAggregation =
            serde_json::from_str(r#"{"field": "myfield", "size": 2, "order": {"_key": "asc"}}"#)
                .unwrap();

        // asc key order, size=2 → keep "a" and "b"
        term_result
            .prune_intermediate_results(&req, &Default::default(), PruneMode::Final)
            .unwrap();
        assert_eq!(term_result.entries.len(), 2);
        assert!(term_result
            .entries
            .iter()
            .any(|(key, _)| key == &IntermediateKey::Str("a".to_string())));
        assert!(term_result
            .entries
            .iter()
            .any(|(key, _)| key == &IntermediateKey::Str("b".to_string())));
    }

    #[test]
    fn test_term_bucket_doc_count_no_u32_overflow() {
        // Two segments each contributing (u32::MAX - 100) docs to the same term. Summing them
        // overflowed when doc_count was u32.
        let per_segment = u32::MAX as u64 - 100;
        let mut entry = IntermediateTermBucketEntry {
            doc_count: per_segment,
            sub_aggregation: Default::default(),
        };
        entry
            .merge_fruits(IntermediateTermBucketEntry {
                doc_count: per_segment,
                sub_aggregation: Default::default(),
            })
            .unwrap();
        assert_eq!(entry.doc_count, per_segment * 2);
    }

    #[test]
    fn test_merge_fruits_tree_empty() {
        let mut tree_left = get_intermediate_tree_with_ranges(&[
            ("red".to_string(), 50, "1900".to_string(), 25),
            ("blue".to_string(), 30, "1900".to_string(), 30),
        ]);

        let orig = tree_left.clone();

        tree_left
            .merge_fruits(IntermediateAggregationResults::default())
            .unwrap();

        assert_range_trees_eq(&tree_left, &orig);
    }
}
