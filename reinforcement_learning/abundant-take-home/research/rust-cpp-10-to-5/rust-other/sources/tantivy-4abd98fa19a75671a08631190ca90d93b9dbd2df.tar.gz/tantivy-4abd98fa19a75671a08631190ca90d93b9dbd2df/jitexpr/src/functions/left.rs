//! `LEFT(input, length)` returns the first `length` UTF-8 bytes of a string.
//!
//! The length must be an integer constant and is stored as a `usize`. A length greater than the
//! input byte length returns the whole string, zero returns a present empty string, and null input
//! propagates. Negative lengths and lengths that split a UTF-8 code point return null.

use std::collections::HashMap;

use cranelift::frontend::FunctionBuilder;
use cranelift::prelude::{InstBuilder, IntCC};

use crate::ast::{Function, InferredTypeSet, Literal, TypeError, UntypedExpr};
use crate::compile::{
    CompileError, CompileFnBuilder, LoweredValue, LoweringContext, TypedExpr, TypedExprAst,
};
use crate::functions::{FnCall, FnCallEnum};
use crate::types::VarType;

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct LeftFnCall {
    input: Box<TypedExpr>,
    length: usize,
}

fn constant_length(expression: &UntypedExpr) -> Result<Option<usize>, super::InvalidFnCall> {
    let UntypedExpr::Literal(literal) = expression else {
        return Err(super::InvalidFnCall::ExpectedLiteral {
            argument: 2,
            expected: VarType::I64,
        });
    };
    if !literal.is_none() && !literal.types().contains(VarType::I64) {
        return Err(super::InvalidFnCall::ExpectedLiteral {
            argument: 2,
            expected: VarType::I64,
        });
    }
    Ok(match literal {
        Literal::I64(value) => usize::try_from(*value).ok(),
        Literal::U64(value) => usize::try_from(*value).ok(),
        Literal::F64(value) => usize::try_from(*value as i64).ok(),
        Literal::None => None,
        Literal::Bool(_) | Literal::String(_) => None,
    })
}

impl FnCall for LeftFnCall {
    const ARG_COUNT: super::ArgumentCount = super::ArgumentCount::Exactly(2);

    fn validate_args(args: &[UntypedExpr]) -> Result<(), super::InvalidFnCall> {
        Self::ARG_COUNT.validate(args)?;
        super::validate_literal(args, 1, VarType::I64, |literal| {
            literal.is_none() || literal.types().contains(VarType::I64)
        })
    }

    fn infer_types<'a>(
        args: &'a [UntypedExpr],
        target_type: InferredTypeSet,
        inferred_types: &mut HashMap<&'a str, InferredTypeSet>,
    ) -> Result<InferredTypeSet, TypeError> {
        if target_type.intersect(InferredTypeSet::STRING).is_none() {
            return Err(TypeError::WrongFunctionReturnType {
                function: Function::Left,
                expected: target_type,
                got: InferredTypeSet::STRING,
            });
        }
        if args.len() != 2 {
            return Err(TypeError::InvalidNumberOfArguments {
                function: Function::Left,
                expected: 2,
                got: args.len(),
            });
        }
        crate::ast::infer_types_aux(&args[0], InferredTypeSet::STRING, inferred_types)?;
        crate::ast::infer_types_aux(&args[1], InferredTypeSet::I64, inferred_types)?;
        Ok(InferredTypeSet::STRING)
    }

    fn call_with_types(
        args: &[UntypedExpr],
        _target_type_set: InferredTypeSet,
        context: &mut CompileFnBuilder<'_, '_>,
    ) -> Result<TypedExpr, CompileError> {
        Self::ARG_COUNT.validate(args)?;
        let input = context.apply_types(&args[0], InferredTypeSet::STRING)?;
        let Some(length) = constant_length(&args[1])? else {
            return Ok(TypedExpr::none());
        };
        Ok(TypedExpr {
            return_type: VarType::Str,
            ast: TypedExprAst::from_fn_call(LeftFnCall {
                input: Box::new(input),
                length,
            }),
        })
    }

    fn args_mut(&mut self) -> &mut [TypedExpr] {
        std::slice::from_mut(&mut self.input)
    }

    fn serialize(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(formatter, "LEFT {} {}u64", self.input, self.length)
    }

    fn emit_cranelift_ir(
        &self,
        return_type: VarType,
        context: &mut LoweringContext<'_>,
        builder: &mut FunctionBuilder<'_>,
    ) -> Result<LoweredValue, CompileError> {
        debug_assert_eq!(return_type, VarType::Str);
        let input = context.compile_expr(&self.input, builder)?;
        let null = builder.ins().iconst(context.pointer_type(), 0);
        let input_ptr = builder.ins().select(input.is_present, input.value, null);
        let length = builder
            .ins()
            .iconst(context.pointer_type(), self.length as i64);
        let call = builder.ins().call(
            context.native_functions().substring(),
            &[input_ptr, input.string_len, null, length],
        );
        let value = builder.inst_results(call)[0];
        let string_len = builder.inst_results(call)[1];
        let native_succeeded = builder.ins().icmp_imm_u(IntCC::NotEqual, value, 0);
        let is_present = builder.ins().band(input.is_present, native_succeeded);
        Ok(LoweredValue {
            value,
            is_present,
            string_len,
        })
    }
}

impl From<LeftFnCall> for FnCallEnum {
    fn from(call: LeftFnCall) -> Self {
        FnCallEnum::Left(call)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ast::deserialize;
    use crate::compile::compile;
    use crate::types::VariableValue;

    fn eval(expression: &str) -> Option<String> {
        let expression = deserialize(expression).unwrap();
        let mut compiled = compile(&expression, &HashMap::new()).unwrap().context();
        // SAFETY: The expression has no inputs and returns a nullable string.
        unsafe { compiled.call(&[]).as_str().map(str::to_owned) }
    }

    #[test]
    fn test_signature_and_byte_lengths() {
        for expression in ["(LEFT \"abc\")", "(LEFT \"abc\" 1i64 2i64)"] {
            assert!(deserialize(expression).is_err());
        }

        assert_eq!(eval("(LEFT \"abcdef\" 3i64)"), Some("abc".into()));
        assert_eq!(eval("(LEFT \"éclair\" 2i64)"), Some("é".into()));
        assert_eq!(eval("(LEFT \"éclair\" 1i64)"), None);
    }

    #[test]
    fn test_zero_clamping_and_invalid_length() {
        assert_eq!(eval("(LEFT \"abc\" 0i64)"), Some(String::new()));
        assert_eq!(eval("(LEFT \"abc\" 99i64)"), Some("abc".into()));
        assert_eq!(eval("(LEFT \"abc\" -1i64)"), None);
    }

    #[test]
    fn test_runtime_null() {
        let expression = deserialize("(LEFT value 2i64)").unwrap();
        let mut compiled = compile(&expression, &HashMap::from([("value", VarType::Str)]))
            .unwrap()
            .context();

        // SAFETY: The compiled expression expects one nullable string argument.
        assert_eq!(
            unsafe { compiled.call(&[VariableValue::some("abc")]).as_str() },
            Some("ab")
        );
        // SAFETY: The compiled expression expects one nullable string argument.
        assert_eq!(
            unsafe { compiled.call(&[VariableValue::none()]).as_str() },
            None
        );
    }
}
