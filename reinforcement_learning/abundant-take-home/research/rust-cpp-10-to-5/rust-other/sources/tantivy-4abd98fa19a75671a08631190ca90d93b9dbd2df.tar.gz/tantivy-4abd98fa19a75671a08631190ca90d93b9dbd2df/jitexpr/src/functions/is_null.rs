//! `IS_NULL` observes absence without propagating it.
//!
//! It accepts exactly one expression of any supported type and always returns a present boolean:
//! `true` when its argument is absent and `false` when it is present. Payload values such as
//! `false`, zero, `NaN`, and the empty string are present and therefore return `false`.

use std::collections::HashMap;

use cranelift::prelude::{FunctionBuilder, InstBuilder, types};

use crate::ast::{Function, InferredTypeSet, TypeError, UntypedExpr};
use crate::compile::{
    CompileError, CompileFnBuilder, LoweredValue, LoweringContext, TypedExpr, TypedExprAst,
};
use crate::functions::{FnCall, FnCallEnum};
use crate::types::VarType;

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct IsNullFnCall {
    pub(crate) args: Box<[TypedExpr]>,
}

impl FnCall for IsNullFnCall {
    const ARG_COUNT: super::ArgumentCount = super::ArgumentCount::Exactly(1);

    fn infer_types<'a>(
        args: &'a [UntypedExpr],
        target_type: InferredTypeSet,
        inferred_types: &mut HashMap<&'a str, InferredTypeSet>,
    ) -> Result<InferredTypeSet, TypeError> {
        if target_type.intersect(InferredTypeSet::BOOLEAN).is_none() {
            return Err(TypeError::WrongFunctionReturnType {
                function: Function::IsNull,
                expected: target_type,
                got: InferredTypeSet::BOOLEAN,
            });
        }
        if args.len() != 1 {
            return Err(TypeError::InvalidNumberOfArguments {
                function: Function::IsNull,
                expected: 1,
                got: args.len(),
            });
        }

        crate::ast::infer_types_aux(&args[0], InferredTypeSet::ALL, inferred_types)?;
        Ok(InferredTypeSet::BOOLEAN)
    }

    fn call_with_types(
        args: &[UntypedExpr],
        target_type_set: InferredTypeSet,
        context: &mut CompileFnBuilder<'_, '_>,
    ) -> Result<TypedExpr, CompileError> {
        Self::ARG_COUNT.validate(args)?;
        debug_assert!(target_type_set.contains(VarType::Bool));

        let arg = context.apply_types(&args[0], InferredTypeSet::ALL)?;
        Ok(TypedExpr {
            return_type: VarType::Bool,
            ast: TypedExprAst::from_fn_call(IsNullFnCall {
                args: vec![arg].into_boxed_slice(),
            }),
        })
    }

    fn args_mut(&mut self) -> &mut [TypedExpr] {
        &mut self.args
    }

    fn serialize(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        crate::compile::format_fn_call("IS_NULL", self.args.iter(), formatter)
    }

    fn emit_cranelift_ir(
        &self,
        return_type: VarType,
        context: &mut LoweringContext<'_>,
        builder: &mut FunctionBuilder<'_>,
    ) -> Result<LoweredValue, CompileError> {
        debug_assert_eq!(return_type, VarType::Bool);
        let arg = context.compile_expr(&self.args[0], builder)?;
        let value = builder.ins().bxor_imm_u(arg.is_present, 1);
        Ok(LoweredValue {
            value,
            is_present: builder.ins().iconst(types::I8, 1),
            string_len: builder.ins().iconst(types::I64, 0),
        })
    }
}

impl From<IsNullFnCall> for FnCallEnum {
    fn from(call: IsNullFnCall) -> Self {
        FnCallEnum::IsNull(call)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ast::{InvalidFnCall, deserialize, infer_types};
    use crate::compile::compile;
    use crate::functions::ArgumentCount;
    use crate::types::VariableValue;

    fn eval(expression: &str) -> Option<bool> {
        let expression = deserialize(expression).unwrap();
        let mut compiled = compile(&expression, &HashMap::new()).unwrap().context();
        // SAFETY: These expressions have no runtime inputs and return booleans.
        unsafe { compiled.call(&[]).as_bool() }
    }

    #[test]
    fn test_infer_types_accepts_any_single_argument() {
        let expression = deserialize("(IS_NULL value)").unwrap();
        let inferred_types = infer_types(&expression).unwrap();

        assert_eq!(inferred_types.get("value"), Some(&InferredTypeSet::ALL));
    }

    #[test]
    fn test_rejects_wrong_arity() {
        for args in [
            vec![],
            vec![
                UntypedExpr::variable("value"),
                UntypedExpr::variable("other"),
            ],
        ] {
            let invalid_fn_call: InvalidFnCall =
                UntypedExpr::new_fn_call(Function::IsNull, args).unwrap_err();
            assert!(matches!(
                invalid_fn_call,
                InvalidFnCall::InvalidNumberOfArguments {
                    expected: ArgumentCount::Exactly(1),
                    ..
                }
            ));
        }
    }

    #[test]
    fn test_absent_values_are_true() {
        assert_eq!(eval("(IS_NULL none)"), Some(true));
        assert_eq!(eval("(IS_NULL missing)"), Some(true));
        assert_eq!(
            eval(r#"(IS_NULL (REGEXP_EXTRACT "b" "(a+)" 1u64))"#),
            Some(true)
        );
    }

    #[test]
    fn test_present_edge_values_are_false() {
        for expression in [
            "(IS_NULL false)",
            "(IS_NULL 0i64)",
            "(IS_NULL -0f64)",
            r#"(IS_NULL "")"#,
            r#"(IS_NULL (REGEXP_EXTRACT "b" "(a*)b" 1u64))"#,
        ] {
            assert_eq!(eval(expression), Some(false), "expression: {expression}");
        }
    }

    #[test]
    fn test_non_finite_values_are_present() {
        // The textual parser rejects non-finite literals, but programmatically
        // constructed expressions can still contain them. They are not null.
        for value in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
            let expression =
                UntypedExpr::new_fn_call(Function::IsNull, vec![UntypedExpr::literal(value)])
                    .unwrap();
            let mut compiled = compile(&expression, &HashMap::new()).unwrap().context();
            // SAFETY: The expression has no runtime inputs and returns a boolean.
            assert_eq!(unsafe { compiled.call(&[]).as_bool() }, Some(false));
        }
    }

    #[test]
    fn test_runtime_absent_variable_is_true_and_present_variable_is_false() {
        let expression = deserialize("(IS_NULL value)").unwrap();
        let variable_types = HashMap::from([("value", VarType::I64)]);
        let mut compiled = compile(&expression, &variable_types).unwrap().context();

        // SAFETY: The input and output types match the compiled signature.
        assert_eq!(
            unsafe { compiled.call(&[VariableValue::none()]).as_bool() },
            Some(true)
        );
        // SAFETY: The input and output types match the compiled signature.
        assert_eq!(
            unsafe { compiled.call(&[VariableValue::some(0i64)]).as_bool() },
            Some(false)
        );
    }
}
