use std::fmt::Debug;
use std::hash::Hash;
use std::net::Ipv6Addr;

use columnar::column_values::CompactSpaceU64Accessor;
use columnar::{
    Column, ColumnType, Dictionary, MonotonicallyMappableToU128, MonotonicallyMappableToU64,
    NumericalValue, StrColumn,
};
use common::{BitSet, TinySet};
use rustc_hash::FxHashMap;
use serde::{Deserialize, Serialize};

use super::{BucketIdSlot, CustomOrder, Order, OrderTarget};
use crate::aggregation::agg_data::{
    build_segment_agg_collectors, AggRefNode, AggregationsSegmentCtx,
};
use crate::aggregation::agg_limits::MemoryConsumption;
use crate::aggregation::agg_req::Aggregations;
use crate::aggregation::buffered_sub_aggs::{
    BufferedSubAggs, HighCardBufferedSubAggs, HighCardSubAggBuffer, LowCardBufferedSubAggs,
    LowCardSubAggBuffer, SubAggBuffer,
};
use crate::aggregation::intermediate_agg_result::{
    IntermediateAggregationResult, IntermediateAggregationResults, IntermediateBucketResult,
    IntermediateKey, IntermediateTermBucketEntry, IntermediateTermBucketResult,
};
use crate::aggregation::segment_agg_result::{BucketIdProvider, SegmentAggregationCollector};
use crate::aggregation::{format_date, BucketId, Key};
use crate::error::DataCorruption;
use crate::TantivyError;

mod flattened_term_histogram;

/// Contains all information required by the SegmentTermCollector to perform the
/// terms aggregation on a segment.
#[derive(Debug, Clone)]
pub struct TermsAggReqData {
    /// The column accessor to access the fast field values.
    pub accessor: Column<u64>,
    /// The type of the column.
    pub column_type: ColumnType,
    /// The string dictionary column if the field is of type text.
    pub str_dict_column: Option<StrColumn>,
    /// The missing value as u64 value.
    pub missing_value_for_accessor: Option<u64>,
    /// Used to build the correct nested result when we have an empty result.
    pub sug_aggregations: Aggregations,
    /// The name of the aggregation.
    pub name: String,
    /// The normalized term aggregation request.
    pub req: TermsAggregationInternal,
    /// Preloaded allowed term ords (string columns only). If set, only ords present are collected.
    pub allowed_term_ids: Option<BitSet>,
    /// True if this terms aggregation is at the top level of the aggregation tree (not nested).
    pub is_top_level: bool,
}

impl TermsAggReqData {
    /// Estimate the memory consumption of this struct in bytes.
    pub fn get_memory_consumption(&self) -> usize {
        std::mem::size_of::<Self>()
            + std::mem::size_of::<TermsAggregationInternal>()
            + self
                .allowed_term_ids
                .as_ref()
                .map(|bs| bs.len() / 8)
                .unwrap_or(0)
    }
}

/// Creates a bucket for every unique term and counts the number of occurrences.
/// Note that doc_count in the response buckets equals term count here.
///
/// If the text is untokenized and single value, that means one term per document and therefore it
/// is in fact doc count.
///
/// ## Prerequisite
/// Term aggregations work only on [fast fields](`crate::fastfield`) of type `u64`, `f64`, `i64` and
/// text.
///
/// ## Document count error
/// To improve performance, results from one segment are cut off at `segment_size`. On a index with
/// a single segment this is fine. When combining results of multiple segments, terms that
/// don't make it in the top n of a shard increase the theoretical upper bound error by lowest
/// term-count.
///
/// Even with a larger `segment_size` value, doc_count values for a terms aggregation may be
/// approximate. As a result, any sub-aggregations on the terms aggregation may also be approximate.
/// `sum_other_doc_count` is the number of documents that didn’t make it into the top size
/// terms. If this is greater than 0, you can be sure that the terms agg had to throw away some
/// buckets, either because they didn’t fit into size on the root node or they didn’t fit into
/// `segment_size` on the segment node.
///
/// ## Per bucket document count error
/// If you set the `show_term_doc_count_error` parameter to true, the terms aggregation will include
/// doc_count_error_upper_bound, which is an upper bound to the error on the doc_count returned by
/// each segment. It’s the sum of the size of the largest bucket on each segment that didn’t fit
/// into segment_size.
///
/// Result type is [`BucketResult`](crate::aggregation::agg_result::BucketResult) with
/// [`BucketEntry`](crate::aggregation::agg_result::BucketEntry) on the
/// `AggregationCollector`.
///
/// Result type is
/// [`IntermediateBucketResult`](crate::aggregation::intermediate_agg_result::IntermediateBucketResult) with
/// [`IntermediateTermBucketEntry`](crate::aggregation::intermediate_agg_result::IntermediateTermBucketEntry) on the
/// `DistributedAggregationCollector`.
///
/// # Limitations/Compatibility
///
/// Each segment returns up to [segment_size](TermsAggregation::segment_size) results. This
/// differences to elasticsearch behaviour.
///
/// # Request JSON Format
/// ```json
/// {
///     "genres": {
///         "terms":{ "field": "genre" }
///     }
/// }
/// ```
///
/// /// # Response JSON Format
/// ```json
/// {
///     ...
///     "aggregations": {
///         "genres": {
///             "doc_count_error_upper_bound": 0,
///             "sum_other_doc_count": 0,
///             "buckets": [
///                 { "key": "drumnbass", "doc_count": 6 },
///                 { "key": "raggae", "doc_count": 4 },
///                 { "key": "jazz", "doc_count": 2 }
///             ]
///         }
///     }
/// }
/// ```

#[derive(Clone, Debug, PartialEq)]
pub enum IncludeExcludeParam {
    /// A single string pattern is treated as regex.
    Regex(String),
    /// An array of strings is treated as exact values.
    Values(Vec<String>),
}

impl Serialize for IncludeExcludeParam {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where S: serde::Serializer {
        match self {
            IncludeExcludeParam::Regex(s) => serializer.serialize_str(s),
            IncludeExcludeParam::Values(v) => v.serialize(serializer),
        }
    }
}

// Custom deserializer to accept either a single string (regex) or an array of strings (values).
impl<'de> Deserialize<'de> for IncludeExcludeParam {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where D: serde::Deserializer<'de> {
        use serde::de::{self, SeqAccess, Visitor};
        struct IncludeExcludeVisitor;

        impl<'de> Visitor<'de> for IncludeExcludeVisitor {
            type Value = IncludeExcludeParam;

            fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
                formatter.write_str("a string (regex) or an array of strings")
            }

            fn visit_str<E>(self, v: &str) -> Result<Self::Value, E>
            where E: de::Error {
                Ok(IncludeExcludeParam::Regex(v.to_string()))
            }

            fn visit_borrowed_str<E>(self, v: &'de str) -> Result<Self::Value, E>
            where E: de::Error {
                Ok(IncludeExcludeParam::Regex(v.to_string()))
            }

            fn visit_string<E>(self, v: String) -> Result<Self::Value, E>
            where E: de::Error {
                Ok(IncludeExcludeParam::Regex(v))
            }

            fn visit_seq<A>(self, mut seq: A) -> Result<Self::Value, A::Error>
            where A: SeqAccess<'de> {
                let mut values: Vec<String> = Vec::new();
                while let Some(elem) = seq.next_element::<String>()? {
                    values.push(elem);
                }
                Ok(IncludeExcludeParam::Values(values))
            }
        }

        deserializer.deserialize_any(IncludeExcludeVisitor)
    }
}

/// The terms aggregation allows you to group documents by unique values of a field.
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
pub struct TermsAggregation {
    /// The field to aggregate on.
    pub field: String,
    /// By default, the top 10 terms with the most documents are returned.
    /// Larger values for size are more expensive.
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub size: Option<u32>,

    /// To get more accurate results, we fetch more than `size` from each segment.
    ///
    /// Increasing this value is will increase the cost for more accuracy.
    ///
    /// Defaults to 10 * size.
    #[serde(skip_serializing_if = "Option::is_none", default)]
    #[serde(alias = "shard_size")]
    #[serde(alias = "split_size")]
    pub segment_size: Option<u32>,

    /// If you set the `show_term_doc_count_error` parameter to true, the terms aggregation will
    /// include doc_count_error_upper_bound, which is an upper bound to the error on the
    /// doc_count returned by each shard. It’s the sum of the size of the largest bucket on
    /// each segment that didn’t fit into `shard_size`.
    ///
    /// Defaults to true when ordering by count desc.
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub show_term_doc_count_error: Option<bool>,

    /// Filter all terms that are lower than `min_doc_count`. Defaults to 1.
    ///
    /// **Expensive**: When set to 0, this will return all terms in the field.
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub min_doc_count: Option<u64>,

    /// Set the order. `String` is here a target, which is either "_count", "_key", or the name of
    /// a metric sub_aggregation.
    ///
    /// Single value metrics like average can be addressed by its name.
    /// Multi value metrics like stats are required to address their field by name e.g.
    /// "stats.avg"
    ///
    /// Examples in JSON format:
    /// { "_count": "asc" }
    /// { "_key": "asc" }
    /// { "average_price": "asc" }
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub order: Option<CustomOrder>,

    /// The missing parameter defines how documents that are missing a value should be treated.
    /// By default they will be ignored but it is also possible to treat them as if they had a
    /// value. Examples in JSON format:
    /// { "missing": "NO_DATA" }
    ///
    /// # Internal
    ///
    /// Internally, `missing` requires some specialized handling in some scenarios.
    ///
    /// Simple Case:
    /// In the simplest case, we can just put the missing value in the termmap and use that. In
    /// case of text we put a special u64::MAX and replace it at the end with the actual
    /// missing value, when loading the text.
    /// Special Case 1:
    /// If we have multiple columns on one field, we need to have a union on the indices on both
    /// columns, to find docids without a value. That requires a special missing aggregation.
    /// Special Case 2: if the key is of type text and the column is numerical, we also need to use
    /// the special missing aggregation, since there is no mechanism in the numerical column to
    /// add text.
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub missing: Option<Key>,

    /// Include terms by either regex (single string) or exact values (array).
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub include: Option<IncludeExcludeParam>,
    /// Exclude terms by either regex (single string) or exact values (array).
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub exclude: Option<IncludeExcludeParam>,
}

/// Same as TermsAggregation, but with populated defaults.
#[derive(Clone, Debug, PartialEq)]
pub struct TermsAggregationInternal {
    /// The field to aggregate on.
    pub field: String,
    /// By default, the top 10 terms with the most documents are returned.
    /// Larger values for size are more expensive.
    ///
    /// Defaults to 10.
    pub size: u32,

    /// If you set the `show_term_doc_count_error` parameter to true, the terms aggregation will
    /// include doc_count_error_upper_bound, which is an upper bound to the error on the
    /// doc_count returned by each shard. It’s the sum of the size of the largest bucket on
    /// each segment that didn’t fit into `segment_size`.
    pub show_term_doc_count_error: bool,

    /// The get more accurate results, we fetch more than `size` from each segment.
    ///
    /// Increasing this value is will increase the cost for more accuracy.
    pub segment_size: u32,

    /// Filter all terms that are lower than `min_doc_count`. Defaults to 1.
    ///
    /// *Expensive*: When set to 0, this will return all terms in the field.
    pub min_doc_count: u64,

    /// Set the order. `String` is here a target, which is either "_count", "_key", or the name of
    /// a metric sub_aggregation.
    pub order: CustomOrder,

    /// The missing parameter defines how documents that are missing a value should be treated.
    pub missing: Option<Key>,
}

impl TermsAggregationInternal {
    pub(crate) fn from_req(req: &TermsAggregation) -> Self {
        let size = req.size.unwrap_or(10);

        let mut segment_size = req.segment_size.unwrap_or(size * 10);

        let order = req.order.clone().unwrap_or_default();
        segment_size = segment_size.max(size);
        TermsAggregationInternal {
            field: req.field.to_string(),
            size,
            segment_size,
            show_term_doc_count_error: req
                .show_term_doc_count_error
                .unwrap_or_else(|| order == CustomOrder::default()),
            min_doc_count: req.min_doc_count.unwrap_or(1),
            order,
            missing: req.missing.clone(),
        }
    }
}

/// Threshold for using dense `Vec` storage ([`VecTermBuckets`] or
/// [`VecTermBucketsWithLanes`]) for term buckets. Below this many term ordinals the `Vec`
/// (direct-indexed, no hashing/paging) beats the paged/hashed storages. It preallocates
/// `num_terms` slots, so the ceiling also bounds its memory.
///
/// TODO: Benchmark to validate the threshold
pub const MAX_NUM_TERMS_FOR_VEC: u64 = 20_000;

/// Maximum number of logical counters for which replicating count lanes is worthwhile.
const MAX_NUM_BUCKETS_FOR_COUNT_LANES: usize = 100;

/// Threshold below which a terms agg without sub-aggregations uses
/// [`VecTermBucketsWithLanes`], whose independent count lanes improve throughput when many
/// consecutive values address the same few counters. With sub-aggregations, this threshold selects
/// [`LowCardSubAggBuffer`] (which buffers docs in a per-bucket `Vec`) while retaining scalar term
/// counters. Both specialized layouts only pay off for a handful of buckets, so this is far lower
/// than [`MAX_NUM_TERMS_FOR_VEC`]. This threshold is tuned independently from
/// [`MAX_NUM_BUCKETS_FOR_COUNT_LANES`].
pub const MAX_NUM_TERMS_FOR_LOWCARD_SUBAGG: u64 = 100;

/// Threshold for using [`PagedTermMap`] storage; larger term-id spaces use
/// [`HashMapTermBuckets`] instead.
pub const MAX_NUM_TERMS_FOR_PAGED_MAP: u64 = 8_000_000;

/// Above this term count, generate sub-aggregation bucket IDs on first use to avoid IDs for unseen
/// terms.
///
/// TODO: Benchmark this threshold.
pub(crate) const LAZY_BUCKET_ID_GENERATION_THRESHOLD: u64 = 4_096;

/// Average docs-per-bucket below which term counts cluster too tightly (mostly 1s and 2s) for
/// `select_nth_unstable` to beat `sort_unstable`'s adaptive paths, so we fall back to a full sort.
/// This is very low on purpose, and meant to catch unique or mostly unique terms.
const DOCS_PER_BUCKET_QUICKSELECT_THRESHOLD: u64 = 2;

/// Charge a `Vec`-backed term storage's eager, up-front allocation against the memory limit.
///
/// The paged/hashed storages grow lazily during `collect` and are charged there via deltas, but
/// the dense term maps preallocate all `num_terms` slots at construction, so their memory would
/// otherwise escape the limit entirely (relevant now that the `Vec` threshold reaches
/// [`MAX_NUM_TERMS_FOR_VEC`]).
fn add_memory_consumption<M: TermAggregationMap>(
    term_buckets: &M,
    req_data: &mut AggregationsSegmentCtx,
) -> crate::Result<()> {
    req_data
        .context
        .limits
        .add_memory_consumed(term_buckets.get_memory_consumption() as u64)
}

/// Build a concrete `SegmentTermCollector` with either a Vec- or HashMap-backed
/// bucket storage, depending on the column type and aggregation level.
pub(crate) fn build_segment_term_collector(
    req_data: &mut AggregationsSegmentCtx,
    node: &AggRefNode,
) -> crate::Result<Box<dyn SegmentAggregationCollector>> {
    let terms_req_data = req_data.get_term_req_data(node.idx_in_req_data).clone();
    let column_type = terms_req_data.column_type;

    if column_type == ColumnType::Bytes {
        return Err(TantivyError::InvalidArgument(format!(
            "terms aggregation is not supported for column type {column_type:?}"
        )));
    }

    // Validate that the referenced sub-aggregation exists when ordering by one.
    if let OrderTarget::SubAggregation(sub_agg_name) = &terms_req_data.req.order.target {
        let (agg_name, _agg_property) = get_agg_name_and_property(sub_agg_name);
        node.get_sub_agg(agg_name, &req_data.per_request)
            .ok_or_else(|| {
                TantivyError::InvalidArgument(format!(
                    "could not find aggregation with name {agg_name} in metric sub_aggregations"
                ))
            })?;
    }

    // Build sub-aggregation blueprint if there are children.
    let has_sub_aggregations = !node.children.is_empty();

    // TODO: A better metric instead of is_top_level would be the number of buckets expected.
    // E.g. If term agg is not top level, but the parent is a bucket agg with less than 10 buckets,
    // we can still use Vec.
    let is_top_level = terms_req_data.is_top_level;

    // Let's see if we can use a vec to aggregate our data
    // instead of a hashmap.
    let col_max_value = terms_req_data.accessor.max_value();
    let max_column_val: u64 =
        col_max_value.max(terms_req_data.missing_value_for_accessor.unwrap_or(0u64));

    // Flattened fast path: low-cardinality terms × a single `histogram`/`date_histogram` leaf over
    // full columns with a small enough bucket grid. Anything else falls through to the general
    // path.
    if let Some(collector) = flattened_term_histogram::maybe_build_flattened_collector(
        req_data,
        node,
        &terms_req_data,
        max_column_val,
        is_top_level,
    )? {
        return Ok(collector);
    }

    let sub_agg_collector = if has_sub_aggregations {
        Some(build_segment_agg_collectors(req_data, &node.children)?)
    } else {
        None
    };

    let mut bucket_id_provider = BucketIdProvider::default();
    // Decide which bucket storage is best suited for this aggregation.
    //
    // Every storage is generic over its `Bucket` id slot (see `BucketIdSlot`): with sub
    // aggregations it stores a real `BucketId` (to key the buffered sub-aggs), without them the
    // zero-sized `()`, which shrinks each bucket and turns id assignment into a no-op.
    //
    // Only the dense Vec/Paged storages below (all gated to `max_column_val <
    // MAX_NUM_TERMS_FOR_PAGED_MAP`) use
    // `num_terms`. `saturating_add` guards the HashMap fallback, where `max_column_val` is a raw
    // numeric column value that can reach `u64::MAX`; term ordinals never come close.
    let num_terms = max_column_val.saturating_add(1);

    // Very low cardinality without sub aggregations: cycle writes through independent count lanes,
    // avoiding a serial read/modify/write dependency when consecutive docs repeatedly hit the same
    // few terms. With sub aggregations, the per-doc buffer push already breaks that dependency;
    // lanes only add indexing and a wider bucket layout, so retain one scalar counter and bucket id
    // per term while pairing it with the `LowCard` doc buffer.
    if is_top_level && max_column_val < MAX_NUM_TERMS_FOR_LOWCARD_SUBAGG {
        if has_sub_aggregations {
            let term_buckets = VecTermBuckets::<BucketId>::new(num_terms, &mut bucket_id_provider);
            add_memory_consumption(&term_buckets, req_data)?;
            let collector: SegmentTermCollector<_, LowCardSubAggBuffer> = SegmentTermCollector {
                parent_buckets: vec![term_buckets],
                sub_agg: sub_agg_collector.map(LowCardBufferedSubAggs::new),
                bucket_id_provider,
                max_term_id: max_column_val,
                terms_req_data,
            };
            return Ok(Box::new(collector));
        }

        let term_buckets = VecTermBucketsWithLanes::<()>::new(num_terms, &mut bucket_id_provider);
        add_memory_consumption(&term_buckets, req_data)?;
        return Ok(boxed_high_card_collector(
            term_buckets,
            None,
            bucket_id_provider,
            max_column_val,
            terms_req_data,
        ));
    }

    // Everything below uses the partitioned `HighCard` sub-agg buffer, so it is built once here.
    let sub_agg = sub_agg_collector.map(BufferedSubAggs::new);
    if is_top_level && max_column_val < MAX_NUM_TERMS_FOR_VEC {
        // Low/moderate cardinality: dense `Vec` storage, direct-indexed by term ordinal — no
        // hashing or page indirection. Used both with and without sub aggregations.
        if has_sub_aggregations {
            // Eager id assignment (branchless `term_entry`) while the bucket count is small;
            // switch to lazy above the threshold to keep the sub-agg bucket range compact for
            // large/sparse ordinal spaces. See `LAZY_BUCKET_ID_GENERATION_THRESHOLD`.
            if num_terms > LAZY_BUCKET_ID_GENERATION_THRESHOLD {
                let term_buckets =
                    VecTermBuckets::<BucketId, true>::new(num_terms, &mut bucket_id_provider);
                add_memory_consumption(&term_buckets, req_data)?;
                Ok(boxed_high_card_collector(
                    term_buckets,
                    sub_agg,
                    bucket_id_provider,
                    max_column_val,
                    terms_req_data,
                ))
            } else {
                let term_buckets =
                    VecTermBuckets::<BucketId, false>::new(num_terms, &mut bucket_id_provider);
                add_memory_consumption(&term_buckets, req_data)?;
                Ok(boxed_high_card_collector(
                    term_buckets,
                    sub_agg,
                    bucket_id_provider,
                    max_column_val,
                    terms_req_data,
                ))
            }
        } else {
            // No sub aggregations: the `()` slot carries no id, so eager vs lazy is moot and
            // `term_entry` is branchless either way.
            let term_buckets = VecTermBuckets::<()>::new(num_terms, &mut bucket_id_provider);
            add_memory_consumption(&term_buckets, req_data)?;
            Ok(boxed_high_card_collector(
                term_buckets,
                sub_agg,
                bucket_id_provider,
                max_column_val,
                terms_req_data,
            ))
        }
    } else if is_top_level && max_column_val < MAX_NUM_TERMS_FOR_PAGED_MAP {
        if has_sub_aggregations {
            let term_buckets = PagedTermMap::<BucketId>::new(num_terms, &mut bucket_id_provider);
            Ok(boxed_high_card_collector(
                term_buckets,
                sub_agg,
                bucket_id_provider,
                max_column_val,
                terms_req_data,
            ))
        } else {
            let term_buckets = PagedTermMap::<()>::new(num_terms, &mut bucket_id_provider);
            Ok(boxed_high_card_collector(
                term_buckets,
                sub_agg,
                bucket_id_provider,
                max_column_val,
                terms_req_data,
            ))
        }
    } else if has_sub_aggregations {
        let term_buckets = HashMapTermBuckets::<BucketId>::default();
        Ok(boxed_high_card_collector(
            term_buckets,
            sub_agg,
            bucket_id_provider,
            max_column_val,
            terms_req_data,
        ))
    } else {
        let term_buckets = HashMapTermBuckets::<()>::default();
        Ok(boxed_high_card_collector(
            term_buckets,
            sub_agg,
            bucket_id_provider,
            max_column_val,
            terms_req_data,
        ))
    }
}

/// Boxes a term collector backed by the high-cardinality sub-agg buffer. Lets the storage branches
/// above pick the `Bucket` id slot (`BucketId` vs `()`) without repeating the collector literal.
fn boxed_high_card_collector<M: TermAggregationMap>(
    term_buckets: M,
    sub_agg: Option<HighCardBufferedSubAggs>,
    bucket_id_provider: BucketIdProvider,
    max_term_id: u64,
    terms_req_data: TermsAggReqData,
) -> Box<dyn SegmentAggregationCollector> {
    Box::new(SegmentTermCollector::<M, HighCardSubAggBuffer> {
        parent_buckets: vec![term_buckets],
        sub_agg,
        bucket_id_provider,
        max_term_id,
        terms_req_data,
    })
}

/// A term bucket: its doc count plus a [`BucketIdSlot`] identifying it for sub-aggregations.
///
/// `B` is [`BucketId`] when the terms agg has sub aggregations and the zero-sized `()` when it does
/// not, so `Bucket<()>` is just the count (see [`BucketIdSlot`]).
#[derive(Debug, Clone, Copy, Default)]
pub(crate) struct Bucket<B = BucketId> {
    pub count: u32,
    pub bucket_id: B,
}

impl<B: BucketIdSlot> Bucket<B> {
    /// Creates an empty bucket, assigning it the next id from `bucket_id_provider` (a no-op for the
    /// `()` slot, which leaves the provider untouched).
    #[inline]
    fn new(bucket_id_provider: &mut BucketIdProvider) -> Self {
        Self {
            count: 0,
            bucket_id: B::assign(bucket_id_provider),
        }
    }
}

/// A key accepted by a [`TermAggregationMap`].
///
/// The map allocation already includes the inline key object. Implementations report only heap
/// allocations owned indirectly by the key, such as a spilled `SmallVec`.
pub(crate) trait AggregationMapKey: Clone + Debug + Eq + Hash + 'static {
    fn heap_memory_usage(&self) -> usize {
        0
    }
}

impl AggregationMapKey for u64 {}

/// Abstraction over the storage used for aggregation buckets (counts plus a [`BucketIdSlot`]).
///
/// Terms aggregations use the default `u64` key. Multi-terms reuses the same abstraction with
/// either a packed `u64` or a composite key.
pub(crate) trait TermAggregationMap<K: AggregationMapKey = u64>:
    Clone + Debug + 'static
{
    /// The per-bucket id slot: [`BucketId`] with sub aggregations, `()` without (see
    /// [`BucketIdSlot`]).
    type Slot: BucketIdSlot;

    /// Whether `into_vec` returns entries already sorted by key, ascending.
    const SORTED_BY_KEY: bool;

    /// Create a new instance. Dense and paged maps interpret `map_init_value` as their key-domain
    /// bound; hash maps ignore it.
    fn new(map_init_value: u64, bucket_id_provider: &mut BucketIdProvider) -> Self;

    /// Estimate the memory consumption of this struct in bytes.
    fn get_memory_consumption(&self) -> usize;

    /// Increments the count and returns the bucket id slot associated with `key`.
    fn term_entry(&mut self, key: K, bucket_id_provider: &mut BucketIdProvider) -> Self::Slot;

    /// Returns the aggregation as a vector of `(key, bucket)` pairs, in any order.
    fn into_vec(self) -> Vec<(K, Bucket<Self::Slot>)>;
}

#[derive(Clone, Debug)]
pub(crate) struct HashMapTermBuckets<B = BucketId, K = u64> {
    bucket_map: FxHashMap<K, Bucket<B>>,
    key_heap_memory: usize,
}

impl<B, K> Default for HashMapTermBuckets<B, K> {
    #[inline]
    fn default() -> Self {
        Self {
            bucket_map: FxHashMap::default(),
            key_heap_memory: 0,
        }
    }
}

const PAGE_SHIFT: usize = 10;
const PAGE_SIZE: usize = 1 << PAGE_SHIFT; // 1024
const PAGE_MASK: usize = PAGE_SIZE - 1;
const BITMASK_LEN: usize = PAGE_SIZE / 64;

#[derive(Clone, Debug)]
struct Page<B> {
    /// Bitmask indicating which offsets are present.
    /// It is chunked into TinySet words.
    presence: [TinySet; BITMASK_LEN],
    data: [Bucket<B>; PAGE_SIZE],
}

impl<B: BucketIdSlot> Page<B> {
    fn new() -> Self {
        Self {
            presence: [TinySet::empty(); BITMASK_LEN],
            data: [Bucket::default(); PAGE_SIZE],
        }
    }

    #[inline]
    fn is_set(&self, offset: usize) -> bool {
        let bucket_idx = offset / 64;
        let bit_idx = offset % 64;
        self.presence[bucket_idx].contains(bit_idx as u32)
    }

    #[inline]
    fn set_present(&mut self, offset: usize) {
        let bucket_idx = offset / 64;
        let bit_idx = offset % 64;
        self.presence[bucket_idx].insert_mut(bit_idx as u32);
    }

    // Flattened iteration logic
    fn collect_items(&self, base_term_id: u64, result: &mut Vec<(u64, Bucket<B>)>) {
        for (bucket_pos, &tiny_set) in self.presence.iter().enumerate() {
            let base_offset = bucket_pos * 64;

            for bit in tiny_set.into_iter() {
                let offset = base_offset + bit as usize;
                result.push((base_term_id + offset as u64, self.data[offset]));
            }
        }
    }
}

/// A paged term map implementation for moderate sized term id sets.
/// Uses a fixed size vector of pages, each page containing a fixed size array of buckets.
///
/// Each page covers a range of term ids. Pages are allocated on demand.
/// This implementation is more memory efficient than a full Vec for high cardinality term id sets,
///
/// It has a fixed cost of `num_pages * 8 bytes` for the page directory.
/// For 1 million terms, this is 8 * 1024 = 8KB.
///
/// Note that for nested aggregations we create one TermAggregationMap per parent bucket.
/// For example, with 100 parent buckets and 1 million terms, this is 800KB overhead for the page
/// directories only. Therefore, this implementation is only enabled for top-level aggregations
/// TODO: pass expected number of buckets from parent instead of strict is_top_level flag.
#[derive(Clone, Debug, Default)]
pub(crate) struct PagedTermMap<B = BucketId> {
    // Fixed size vector based on max_term_id
    pages: Vec<Option<Box<Page<B>>>>,
    mem_usage: usize,
}

impl<B: BucketIdSlot> TermAggregationMap for PagedTermMap<B> {
    type Slot = B;

    const SORTED_BY_KEY: bool = true;

    #[inline]
    fn get_memory_consumption(&self) -> usize {
        self.mem_usage + std::mem::size_of::<Self>()
    }

    #[inline]
    fn term_entry(&mut self, term_id: u64, bucket_id_provider: &mut BucketIdProvider) -> B {
        let term_id = term_id as usize;
        let page_idx = term_id >> PAGE_SHIFT;
        let offset = term_id & PAGE_MASK;

        // This panics if term_id > max_term_id
        let page = match &mut self.pages[page_idx] {
            Some(p) => p,
            None => {
                let new_page = Box::new(Page::new());
                self.mem_usage += std::mem::size_of::<Page<B>>();
                self.pages[page_idx] = Some(new_page);
                self.pages[page_idx].as_mut().unwrap()
            }
        };

        if page.is_set(offset) {
            let bucket = &mut page.data[offset];
            bucket.count += 1;
            bucket.bucket_id
        } else {
            let mut bucket = Bucket::new(bucket_id_provider);
            bucket.count = 1;
            page.data[offset] = bucket;
            page.set_present(offset);
            bucket.bucket_id
        }
    }

    fn into_vec(self) -> Vec<(u64, Bucket<B>)> {
        // estimate 16 entries per non-empty page
        let estimated_count = self.pages.iter().filter(|p| p.is_some()).count() * 16;
        let mut result = Vec::with_capacity(estimated_count);

        for (i, page_opt) in self.pages.into_iter().enumerate() {
            if let Some(page) = page_opt {
                let base_term_id = (i << PAGE_SHIFT) as u64;
                page.collect_items(base_term_id, &mut result);
            }
        }
        result
    }

    /// Initialize with a strict upper bound.
    /// Panics if you try to insert a term_id > max_term_id.
    fn new(max_term_id: u64, _bucket_id_provider: &mut BucketIdProvider) -> Self {
        let max_page_idx = (max_term_id as usize) >> PAGE_SHIFT;
        let num_pages = max_page_idx + 1;

        // Pre-allocate the directory (pointers only, not the heavy pages)
        // Memory cost: num_pages * 8 bytes
        let pages = vec![None; num_pages];

        let mem_usage = pages.capacity() * std::mem::size_of::<Option<Box<Page<B>>>>();

        Self { pages, mem_usage }
    }
}

impl<K: AggregationMapKey, B: BucketIdSlot> TermAggregationMap<K> for HashMapTermBuckets<B, K> {
    type Slot = B;

    const SORTED_BY_KEY: bool = false;

    #[inline]
    fn get_memory_consumption(&self) -> usize {
        self.bucket_map.memory_consumption() + self.key_heap_memory
    }

    #[inline]
    fn term_entry(&mut self, key: K, bucket_id_provider: &mut BucketIdProvider) -> B {
        let bucket = match self.bucket_map.entry(key) {
            std::collections::hash_map::Entry::Occupied(entry) => entry.into_mut(),
            std::collections::hash_map::Entry::Vacant(entry) => {
                self.key_heap_memory += entry.key().heap_memory_usage();
                entry.insert(Bucket::new(bucket_id_provider))
            }
        };
        bucket.count += 1;
        bucket.bucket_id
    }

    fn into_vec(self) -> Vec<(K, Bucket<B>)> {
        self.bucket_map.into_iter().collect()
    }

    #[inline]
    fn new(_map_init_value: u64, _bucket_id_provider: &mut BucketIdProvider) -> Self {
        Self::default()
    }
}

/// Number of independent counters maintained per logical very-low-cardinality term bucket.
///
/// Cycling writes across eight counters covers the read/modify/write latency of a counter update
/// while keeping the entire map small at [`MAX_NUM_TERMS_FOR_LOWCARD_SUBAGG`].
const NUM_LOW_CARD_COUNT_LANES: usize = 8;

/// A very-low-cardinality term bucket with split count storage and one shared sub-aggregation id.
/// Only the counters are replicated: `bucket_id` remains unique per logical term.
#[derive(Clone, Copy, Debug)]
struct TermBucketWithLanes<B, const LANES: usize> {
    count_lanes: [u32; LANES],
    bucket_id: B,
}

impl<B: BucketIdSlot, const LANES: usize> TermBucketWithLanes<B, LANES> {
    #[inline(always)]
    fn new(bucket_id_provider: &mut BucketIdProvider) -> Self {
        const { assert!(LANES > 0, "a term bucket needs at least one count lane") };
        Self {
            count_lanes: [0; LANES],
            bucket_id: B::assign(bucket_id_provider),
        }
    }

    #[inline]
    fn into_bucket(self) -> Bucket<B> {
        Bucket {
            count: self.count_lanes.into_iter().sum(),
            bucket_id: self.bucket_id,
        }
    }
}

/// A dense term map for very low cardinality. Each logical bucket cycles writes over independent
/// count lanes, which are consolidated when the map is converted into its result representation.
#[derive(Clone, Debug)]
struct VecTermBucketsWithLanes<B, const LANES: usize = NUM_LOW_CARD_COUNT_LANES> {
    buckets: Vec<TermBucketWithLanes<B, LANES>>,
    next_count_lane: usize,
}

impl<B: BucketIdSlot, const LANES: usize> TermAggregationMap for VecTermBucketsWithLanes<B, LANES> {
    type Slot = B;

    const SORTED_BY_KEY: bool = true;

    fn get_memory_consumption(&self) -> usize {
        self.buckets.capacity() * std::mem::size_of::<TermBucketWithLanes<B, LANES>>()
    }

    #[inline(always)]
    fn term_entry(&mut self, term_id: u64, _bucket_id_provider: &mut BucketIdProvider) -> B {
        let term_id_usize = term_id as usize;
        debug_assert!(
            term_id_usize < self.buckets.len(),
            "term_id {} out of bounds for VecTermBucketsWithLanes (len={})",
            term_id,
            self.buckets.len()
        );

        self.next_count_lane = (self.next_count_lane + 1) % LANES;
        let bucket = unsafe { self.buckets.get_unchecked_mut(term_id_usize) };
        bucket.count_lanes[self.next_count_lane] += 1;
        bucket.bucket_id
    }

    fn into_vec(self) -> Vec<(u64, Bucket<B>)> {
        self.buckets
            .into_iter()
            .enumerate()
            .filter_map(|(term_id, low_card_bucket)| {
                let bucket = low_card_bucket.into_bucket();
                (bucket.count > 0).then_some((term_id as u64, bucket))
            })
            .collect()
    }

    fn new(num_terms: u64, bucket_id_provider: &mut BucketIdProvider) -> Self {
        const { assert!(LANES > 0, "a term map needs at least one count lane") };
        let buckets =
            std::iter::repeat_with(|| TermBucketWithLanes::<B, LANES>::new(bucket_id_provider))
                .take(num_terms as usize)
                .collect();
        Self {
            buckets,
            next_count_lane: 0,
        }
    }
}

/// A term map backed by a `Vec`, indexed directly by term ordinal.
///
/// `LAZY_BUCKET_ID_GENERATION` defers sub-aggregation bucket ID generation until first use.
#[derive(Clone, Debug)]
pub(crate) struct VecTermBuckets<B = BucketId, const LAZY_BUCKET_ID_GENERATION: bool = false> {
    buckets: Vec<Bucket<B>>,
}

impl<B: BucketIdSlot, const LAZY_BUCKET_ID_GENERATION: bool> TermAggregationMap
    for VecTermBuckets<B, LAZY_BUCKET_ID_GENERATION>
{
    type Slot = B;

    const SORTED_BY_KEY: bool = true;

    /// Estimate the memory consumption of this struct in bytes.
    fn get_memory_consumption(&self) -> usize {
        // We do not include `std::mem::size_of::<Self>()`
        // It is already measure by the parent aggregation.
        //
        // The root aggregation mem size is not measure but we do not care.
        self.buckets.capacity() * std::mem::size_of::<Bucket<B>>()
    }

    /// Add an occurrence of the given term id.
    #[inline]
    fn term_entry(&mut self, term_id: u64, bucket_id_provider: &mut BucketIdProvider) -> B {
        let term_id_usize = term_id as usize;
        debug_assert!(
            term_id_usize < self.buckets.len(),
            "term_id {} out of bounds for VecTermBuckets (len={})",
            term_id,
            self.buckets.len()
        );
        let bucket = unsafe { self.buckets.get_unchecked_mut(term_id_usize) };
        // Lazy mode: assign the id the first time a term is seen (`count == 0`). Both
        // `LAZY_BUCKET_ID_GENERATION` and `B::ASSIGNS_ID` are consts, so in eager mode (or for the
        // `()` slot) the whole branch is gated out at monomorphization, leaving just the `count`
        // bump.
        if LAZY_BUCKET_ID_GENERATION && B::ASSIGNS_ID && bucket.count == 0 {
            bucket.bucket_id = B::assign(bucket_id_provider);
        }
        bucket.count += 1;
        bucket.bucket_id
    }

    fn into_vec(self) -> Vec<(u64, Bucket<B>)> {
        self.buckets
            .into_iter()
            .enumerate()
            .filter(|(_, bucket)| bucket.count > 0)
            .map(|(term_id, bucket)| (term_id as u64, bucket))
            .collect()
    }

    fn new(num_terms: u64, bucket_id_provider: &mut BucketIdProvider) -> Self {
        let num_terms = num_terms as usize;
        let buckets = if LAZY_BUCKET_ID_GENERATION {
            // Empty buckets; ids are assigned lazily in `term_entry`, so the provider is untouched.
            vec![Bucket::default(); num_terms]
        } else {
            // Eager: assign an id to every ordinal up front (a no-op for the `()` slot).
            std::iter::repeat_with(|| Bucket::new(bucket_id_provider))
                .take(num_terms)
                .collect()
        };
        VecTermBuckets { buckets }
    }
}

/// The collector puts values from the fast field into the correct buckets and does a conversion to
/// the correct datatype.
#[derive(Debug)]
struct SegmentTermCollector<TermMap: TermAggregationMap, B: SubAggBuffer> {
    /// The buckets containing the aggregation data.
    parent_buckets: Vec<TermMap>,
    sub_agg: Option<BufferedSubAggs<B>>,
    bucket_id_provider: BucketIdProvider,
    max_term_id: u64,
    terms_req_data: TermsAggReqData,
}

pub(crate) fn get_agg_name_and_property(name: &str) -> (&str, &str) {
    let (agg_name, agg_property) = name.split_once('.').unwrap_or((name, ""));
    (agg_name, agg_property)
}

impl<TermMap: TermAggregationMap, B: SubAggBuffer> SegmentAggregationCollector
    for SegmentTermCollector<TermMap, B>
{
    fn add_intermediate_aggregation_result(
        &mut self,
        agg_data: &AggregationsSegmentCtx,
        results: &mut IntermediateAggregationResults,
        bucket: BucketId,
    ) -> crate::Result<()> {
        // TODO: avoid prepare_max_bucket here and handle empty buckets.
        self.prepare_max_bucket(bucket, agg_data)?;
        let bucket = std::mem::replace(
            &mut self.parent_buckets[bucket as usize],
            TermMap::new(0, &mut self.bucket_id_provider),
        );
        let term_req = &self.terms_req_data;
        let name = term_req.name.clone();

        let bucket = Self::into_intermediate_bucket_result(
            term_req,
            self.sub_agg
                .as_mut()
                .map(BufferedSubAggs::get_sub_agg_collector),
            bucket,
            agg_data,
        )?;
        results.push(name, IntermediateAggregationResult::Bucket(bucket))?;
        Ok(())
    }

    #[inline]
    fn collect(
        &mut self,
        parent_bucket_id: BucketId,
        docs: &[crate::DocId],
        agg_data: &mut AggregationsSegmentCtx,
    ) -> crate::Result<()> {
        let mem_pre = self.get_memory_consumption(parent_bucket_id);

        let req_data = &mut self.terms_req_data;

        agg_data
            .column_block_accessor
            .fetch_block_with_missing_unique_per_doc(
                docs,
                &req_data.accessor,
                req_data.missing_value_for_accessor,
                false,
            );

        if let Some(sub_agg) = &mut self.sub_agg {
            let term_buckets = &mut self.parent_buckets[parent_bucket_id as usize];
            let it = agg_data.column_block_accessor.iter_docid_vals(docs);
            if let Some(allowed_bs) = req_data.allowed_term_ids.as_ref() {
                let it = it.filter(move |&(_doc, term_id)| allowed_bs.contains(term_id as u32));
                Self::collect_terms_with_docs(
                    it,
                    term_buckets,
                    &mut self.bucket_id_provider,
                    sub_agg,
                );
            } else {
                Self::collect_terms_with_docs(
                    it,
                    term_buckets,
                    &mut self.bucket_id_provider,
                    sub_agg,
                );
            }
        } else {
            let term_buckets = &mut self.parent_buckets[parent_bucket_id as usize];
            let it = agg_data.column_block_accessor.iter_vals();
            if let Some(allowed_bs) = req_data.allowed_term_ids.as_ref() {
                let it = it.filter(move |&term_id| allowed_bs.contains(term_id as u32));
                Self::collect_terms(it, term_buckets, &mut self.bucket_id_provider);
            } else {
                Self::collect_terms(it, term_buckets, &mut self.bucket_id_provider);
            }
        }

        let mem_delta = self.get_memory_consumption(parent_bucket_id) - mem_pre;
        if mem_delta > 0 {
            agg_data
                .context
                .limits
                .add_memory_consumed(mem_delta as u64)?;
        }
        if let Some(sub_agg) = &mut self.sub_agg {
            sub_agg.check_flush_local(agg_data)?;
        }

        Ok(())
    }

    #[inline]
    fn flush(&mut self, agg_data: &mut AggregationsSegmentCtx) -> crate::Result<()> {
        if let Some(sub_agg) = &mut self.sub_agg {
            sub_agg.flush(agg_data)?;
        }
        Ok(())
    }

    fn prepare_max_bucket(
        &mut self,
        max_bucket: BucketId,
        _agg_data: &AggregationsSegmentCtx,
    ) -> crate::Result<()> {
        while self.parent_buckets.len() <= max_bucket as usize {
            let term_buckets: TermMap =
                TermMap::new(self.max_term_id, &mut self.bucket_id_provider);
            self.parent_buckets.push(term_buckets);
        }
        Ok(())
    }

    fn compute_metric_value(
        &self,
        _bucket_id: BucketId,
        _sub_agg_name: &str,
        _sub_agg_property: &str,
        _agg_data: &AggregationsSegmentCtx,
    ) -> Option<f64> {
        // Terms is a multi-bucket agg with no single value to extract.
        None
    }
}

/// Missing value are represented as a sentinel value in the column.
///
/// This function extracts the missing value from the entries vector,
/// computes the intermediate key, and returns it the key and the bucket
/// in an Option.
fn extract_missing_value<T>(
    entries: &mut Vec<(u64, T)>,
    term_req: &TermsAggReqData,
) -> Option<(IntermediateKey, T)> {
    let missing_sentinel = term_req.missing_value_for_accessor?;
    let missing_value_entry_pos = entries
        .iter()
        .position(|(term_id, _)| *term_id == missing_sentinel)?;
    let (_term_id, bucket) = entries.swap_remove(missing_value_entry_pos);
    let missing_key = term_req.req.missing.as_ref()?;
    let key = match missing_key {
        Key::Str(missing) => IntermediateKey::Str(missing.clone()),
        Key::F64(val) => IntermediateKey::F64(*val),
        Key::U64(val) => IntermediateKey::U64(*val),
        Key::I64(val) => IntermediateKey::I64(*val),
    };
    Some((key, bucket))
}

fn reborrow_opt_collector<'a>(
    opt: &'a mut Option<&mut dyn SegmentAggregationCollector>,
) -> Option<&'a mut dyn SegmentAggregationCollector> {
    match opt {
        Some(inner) => Some(*inner),
        None => None,
    }
}

fn into_intermediate_bucket_entry<B: BucketIdSlot>(
    bucket: Bucket<B>,
    sub_agg_collector: Option<&mut dyn SegmentAggregationCollector>,
    agg_data: &AggregationsSegmentCtx,
) -> crate::Result<IntermediateTermBucketEntry> {
    let mut sub_aggregation_res = IntermediateAggregationResults::default();
    if let Some(sub_agg_collector) = sub_agg_collector {
        // The `bucket_id` is only read here, when a sub-agg collector is present — which is exactly
        // when the slot is a real `BucketId` (never `()`), so `to_bucket_id` never hits its
        // `unreachable!`.
        sub_agg_collector.add_intermediate_aggregation_result(
            agg_data,
            &mut sub_aggregation_res,
            bucket.bucket_id.to_bucket_id(),
        )?;
    }
    Ok(IntermediateTermBucketEntry {
        doc_count: bucket.count as u64,
        sub_aggregation: sub_aggregation_res,
    })
}

impl<TermMap, B> SegmentTermCollector<TermMap, B>
where
    TermMap: TermAggregationMap,
    B: SubAggBuffer,
{
    #[inline]
    fn get_memory_consumption(&self, parent_bucket_id: BucketId) -> usize {
        self.parent_buckets[parent_bucket_id as usize].get_memory_consumption()
    }

    #[inline]
    pub(crate) fn into_intermediate_bucket_result(
        term_req: &TermsAggReqData,
        mut sub_agg_collector: Option<&mut dyn SegmentAggregationCollector>,
        term_buckets: TermMap,
        agg_data: &AggregationsSegmentCtx,
    ) -> crate::Result<IntermediateBucketResult> {
        let mut entries: Vec<(u64, Bucket<TermMap::Slot>)> = term_buckets.into_vec();

        let segment_size = term_req.req.segment_size as usize;

        // Total doc count over all buckets, computed is some case, and which can be reused by
        // `cut_off_buckets` to derive `sum_other_doc_count` without a second pass.
        let mut total_doc_count: Option<u64> = None;

        // select_nth_unstable_by_key(segment_size, ...) places the (k+1)-th element at
        // entries[segment_size] and guarantees entries[0..segment_size] are the top-k,
        // unordered. We need this to properly compute term_doc_count_before_cutoff.
        // In some cases (already sorted entries), we are faster sorting everything and
        // going through sort_unstable's fast path.
        match &term_req.req.order.target {
            OrderTarget::Key => {
                // We rely on the fact, that term ordinals match the order of the strings
                // TODO: We could have a special collector, that keeps only TOP n results at any
                // time.
                if TermMap::SORTED_BY_KEY {
                    // `into_vec` already returned entries sorted by ord ascending, we can just
                    // revert if we want descending.
                    if term_req.req.order.order == Order::Desc {
                        entries.reverse();
                    }
                } else if entries.len() > segment_size {
                    // Unsorted source: use select_nth
                    if term_req.req.order.order == Order::Desc {
                        entries
                            .select_nth_unstable_by_key(segment_size, |b| std::cmp::Reverse(b.0));
                    } else {
                        entries.select_nth_unstable_by_key(segment_size, |b| b.0);
                    }
                }
            }
            OrderTarget::SubAggregation(sub_agg_path) => {
                // Peek segment-level metric values, select top-k, then fall through to
                // `cut_off_buckets`. Like Elasticsearch, we always cut off when ordering
                // by a sub-agg: top-K results are approximate and may differ from the
                // global ordering, especially for non-monotonic metrics like avg/min.
                let coll = sub_agg_collector.as_deref().ok_or_else(|| {
                    TantivyError::InvalidArgument(format!(
                        "Could not find sub-aggregation collector for path {sub_agg_path}"
                    ))
                })?;
                let (agg_name, agg_prop) = get_agg_name_and_property(sub_agg_path);
                // Fetch values up-front; otherwise sort would re-compute per call
                let mut keyed: Vec<_> = entries
                    .into_iter()
                    .map(|bucket| {
                        // Reached only when ordering by a sub-agg, i.e. sub aggregations exist and
                        // the slot is a real `BucketId`, so `to_bucket_id` never hits
                        // `unreachable!`.
                        let metric_value = coll
                            .compute_metric_value(
                                bucket.1.bucket_id.to_bucket_id(),
                                agg_name,
                                agg_prop,
                                agg_data,
                            )
                            .unwrap_or(0.0);
                        (metric_value, bucket)
                    })
                    .collect();
                if keyed.len() > segment_size {
                    // there are situations where sort_unstable might be advantageous, but
                    // detecting them isn't trivial, and these situation should be rare.
                    if term_req.req.order.order == Order::Desc {
                        keyed.select_nth_unstable_by(segment_size, |a, b| {
                            b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal)
                        });
                    } else {
                        keyed.select_nth_unstable_by(segment_size, |a, b| {
                            a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal)
                        });
                    }
                }
                entries = keyed.into_iter().map(|(_, e)| e).collect();
            }
            OrderTarget::Count => {
                if entries.len() > segment_size {
                    // unique or near-unique fields create big runs of sorted values (ones),
                    // which is defavorable to quickselect. use the then faster sort_unstable.
                    let num_buckets = entries.len() as u64;
                    let num_docs = entries.iter().map(|(_, b)| b.count as u64).sum();
                    total_doc_count = Some(num_docs);
                    let many_buckets_with_same_count =
                        num_docs < num_buckets * DOCS_PER_BUCKET_QUICKSELECT_THRESHOLD;
                    if term_req.req.order.order == Order::Desc {
                        if many_buckets_with_same_count {
                            entries.sort_unstable_by_key(|b| std::cmp::Reverse(b.1.count));
                        } else {
                            entries.select_nth_unstable_by_key(segment_size, |b| {
                                std::cmp::Reverse(b.1.count)
                            });
                        }
                    } else if many_buckets_with_same_count {
                        entries.sort_unstable_by_key(|b| b.1.count);
                    } else {
                        entries.select_nth_unstable_by_key(segment_size, |b| b.1.count);
                    }
                }
            }
        }

        let (term_doc_count_before_cutoff, sum_other_doc_count) =
            cut_off_buckets(&mut entries, segment_size, total_doc_count);

        // Collected entries, in unspecified order. The cross-segment merge keys entries by their
        // own dictionary and the final result is sorted by the requested order, so segment-side
        // order does not matter here.
        let mut out: Vec<(IntermediateKey, IntermediateTermBucketEntry)> =
            Vec::with_capacity(entries.len());

        if term_req.column_type == ColumnType::Str {
            let fallback_dict = Dictionary::empty();
            let term_dict = term_req
                .str_dict_column
                .as_ref()
                .map(|el| el.dictionary())
                .unwrap_or_else(|| &fallback_dict);

            // Collect into a map to dedup by key, then flush into `out`. Two cases need it: a real
            // term may equal the `missing` placeholder, and the min_doc_count==0 fill must skip
            // already-collected terms. A single-segment query returns this result directly (the
            // cross-segment merge that would otherwise dedup never runs), so duplicate keys here
            // would reach the final result unmerged.
            let mut dict: FxHashMap<IntermediateKey, IntermediateTermBucketEntry> =
                FxHashMap::with_capacity_and_hasher(entries.len(), Default::default());

            if let Some((intermediate_key, bucket)) = extract_missing_value(&mut entries, term_req)
            {
                let intermediate_entry = into_intermediate_bucket_entry(
                    bucket,
                    reborrow_opt_collector(&mut sub_agg_collector),
                    agg_data,
                )?;
                dict.insert(intermediate_key, intermediate_entry);
            }

            // Sort by term ord
            entries.sort_unstable_by_key(|bucket| bucket.0);

            let (term_ids, buckets): (Vec<u64>, Vec<Bucket<TermMap::Slot>>) =
                entries.into_iter().unzip();

            let intermediate_entries: Vec<IntermediateTermBucketEntry> = buckets
                .into_iter()
                .map(|bucket| {
                    into_intermediate_bucket_entry(
                        bucket,
                        reborrow_opt_collector(&mut sub_agg_collector),
                        agg_data,
                    )
                })
                .collect::<crate::Result<_>>()?;

            let mut intermediate_entry_it = intermediate_entries.into_iter();

            term_dict.sorted_ords_to_term_cb(&term_ids[..], |term| {
                let intermediate_entry = intermediate_entry_it.next().unwrap();
                dict.insert(
                    IntermediateKey::Str(
                        String::from_utf8(term.to_vec()).expect("could not convert to String"),
                    ),
                    intermediate_entry,
                );
            })?;

            if term_req.req.min_doc_count == 0 {
                // TODO: Handle rev streaming for descending sorting by keys
                let mut stream = term_dict.stream()?;
                let empty_sub_aggregation =
                    IntermediateAggregationResults::empty_from_req(&term_req.sug_aggregations);
                while stream.advance() {
                    if dict.len() >= term_req.req.segment_size as usize {
                        break;
                    }

                    // Respect allowed filters if present
                    if let Some(allowed_bs) = term_req.allowed_term_ids.as_ref() {
                        if !allowed_bs.contains(stream.term_ord() as u32) {
                            continue;
                        }
                    }

                    let key = IntermediateKey::Str(
                        std::str::from_utf8(stream.key())
                            .map_err(|utf8_err| DataCorruption::comment_only(utf8_err.to_string()))?
                            .to_string(),
                    );

                    dict.entry(key.clone())
                        .or_insert_with(|| IntermediateTermBucketEntry {
                            doc_count: 0,
                            sub_aggregation: empty_sub_aggregation.clone(),
                        });
                }
            }

            out.extend(dict);
        } else if term_req.column_type == ColumnType::DateTime {
            for (val, doc_count) in entries {
                let intermediate_entry = into_intermediate_bucket_entry(
                    doc_count,
                    reborrow_opt_collector(&mut sub_agg_collector),
                    agg_data,
                )?;
                let val = i64::from_u64(val);
                let date = format_date(val)?;
                out.push((IntermediateKey::Str(date), intermediate_entry));
            }
        } else if term_req.column_type == ColumnType::Bool {
            for (val, doc_count) in entries {
                let intermediate_entry = into_intermediate_bucket_entry(
                    doc_count,
                    reborrow_opt_collector(&mut sub_agg_collector),
                    agg_data,
                )?;
                let val = bool::from_u64(val);
                out.push((IntermediateKey::Bool(val), intermediate_entry));
            }
        } else if term_req.column_type == ColumnType::IpAddr {
            let compact_space_accessor = term_req
                .accessor
                .values
                .clone()
                .downcast_arc::<CompactSpaceU64Accessor>()
                .map_err(|_| {
                    TantivyError::AggregationError(
                        crate::aggregation::AggregationError::InternalError(
                            "Type mismatch: Could not downcast to CompactSpaceU64Accessor"
                                .to_string(),
                        ),
                    )
                })?;

            for (val, doc_count) in entries {
                let intermediate_entry = into_intermediate_bucket_entry(
                    doc_count,
                    reborrow_opt_collector(&mut sub_agg_collector),
                    agg_data,
                )?;
                let val: u128 = compact_space_accessor.compact_to_u128(val as u32);
                let val = Ipv6Addr::from_u128(val);
                out.push((IntermediateKey::IpAddr(val), intermediate_entry));
            }
        } else if term_req.column_type == ColumnType::F64 {
            // -0.0 and +0.0 both normalize to I64(0). Sort by normalized key to merge their
            // buckets below. Other distinct f64 encodings, including NaNs, remain distinct:
            // NaNs are not normalized and IntermediateKey compares them using total_cmp.
            let normalized_key = |val: u64| -> IntermediateKey {
                NumericalValue::from(f64::from_u64(val)).normalize().into()
            };
            entries.sort_unstable_by_key(|(val, _)| normalized_key(*val));

            for (val, bucket) in entries {
                let key = normalized_key(val);
                let intermediate_entry = into_intermediate_bucket_entry(
                    bucket,
                    reborrow_opt_collector(&mut sub_agg_collector),
                    agg_data,
                )?;
                match out.last_mut() {
                    Some((previous_key, existing)) if previous_key == &key => {
                        existing.doc_count += intermediate_entry.doc_count;
                        existing
                            .sub_aggregation
                            .merge_fruits(intermediate_entry.sub_aggregation)?;
                    }
                    _ => out.push((key, intermediate_entry)),
                }
            }
        } else {
            for (val, bucket) in entries {
                let intermediate_entry = into_intermediate_bucket_entry(
                    bucket,
                    reborrow_opt_collector(&mut sub_agg_collector),
                    agg_data,
                )?;
                let key_val: NumericalValue = match term_req.column_type {
                    ColumnType::U64 => val.into(),
                    ColumnType::I64 => i64::from_u64(val).into(),
                    _ => {
                        return Err(TantivyError::SchemaError(format!(
                            "unknown key type: {}",
                            term_req.column_type
                        )))
                    }
                };
                out.push((key_val.normalize().into(), intermediate_entry));
            }
        };

        Ok(IntermediateBucketResult::Terms {
            buckets: IntermediateTermBucketResult {
                entries: out,
                sum_other_doc_count,
                doc_count_error_upper_bound: term_doc_count_before_cutoff,
                ..Default::default()
            },
        })
    }
}

impl<TermMap: TermAggregationMap, B: SubAggBuffer> SegmentTermCollector<TermMap, B> {
    #[inline]
    fn collect_terms_with_docs(
        iter: impl Iterator<Item = (crate::DocId, u64)>,
        term_buckets: &mut TermMap,
        bucket_id_provider: &mut BucketIdProvider,
        sub_agg: &mut BufferedSubAggs<B>,
    ) {
        for (doc, term_id) in iter {
            // This path only runs when a sub-agg buffer is present, so the slot is a real
            // `BucketId` and `to_bucket_id` never hits `unreachable!`.
            let bucket_id = term_buckets.term_entry(term_id, bucket_id_provider);
            sub_agg.push(bucket_id.to_bucket_id(), doc);
        }
    }

    #[inline]
    fn collect_terms(
        iter: impl Iterator<Item = u64>,
        term_buckets: &mut TermMap,
        bucket_id_provider: &mut BucketIdProvider,
    ) {
        for term_id in iter {
            term_buckets.term_entry(term_id, bucket_id_provider);
        }
    }
}

pub(crate) trait GetDocCount {
    fn doc_count(&self) -> u64;
}

impl GetDocCount for (String, IntermediateTermBucketEntry) {
    fn doc_count(&self) -> u64 {
        self.1.doc_count
    }
}

impl<B: BucketIdSlot> GetDocCount for (u64, Bucket<B>) {
    fn doc_count(&self) -> u64 {
        self.1.count as u64
    }
}

/// Truncates `entries` to the top `num_elem` and returns
/// `(term_doc_count_before_cutoff, sum_other_doc_count)`.
///
/// When `total_doc_count` is `Some`, `sum_other_doc_count` is derived as `total - sum(kept)`, which
/// only sums the `num_elem` kept entries instead of the (potentially far larger) cut-off tail.
pub(crate) fn cut_off_buckets<T: GetDocCount + Debug>(
    entries: &mut Vec<T>,
    num_elem: usize,
    total_doc_count: Option<u64>,
) -> (u64, u64) {
    let term_doc_count_before_cutoff = entries
        .get(num_elem)
        .map(|entry| entry.doc_count())
        .unwrap_or(0);

    let sum_other_doc_count = match total_doc_count {
        // Reuse the precomputed total: sum_other = total - sum(kept top-k), summing only the
        // (small) kept slice. Fewer than `num_elem` buckets means nothing is cut off, so 0.
        Some(total) => entries
            .get(..num_elem)
            .map(|kept| total - kept.iter().map(|entry| entry.doc_count()).sum::<u64>())
            .unwrap_or(0),
        None => entries
            .get(num_elem..)
            .map(|cut_off_range| cut_off_range.iter().map(|entry| entry.doc_count()).sum())
            .unwrap_or(0),
    };

    entries.truncate(num_elem);
    (term_doc_count_before_cutoff, sum_other_doc_count)
}

#[cfg(test)]
mod tests {
    use std::net::IpAddr;
    use std::str::FromStr;

    use common::DateTime;
    use time::{Date, Month};

    use super::{PagedTermMap, TermAggregationMap, VecTermBucketsWithLanes, PAGE_SIZE};
    use crate::aggregation::agg_req::Aggregations;
    use crate::aggregation::intermediate_agg_result::IntermediateAggregationResults;
    use crate::aggregation::segment_agg_result::BucketIdProvider;
    use crate::aggregation::tests::{
        exec_request, exec_request_with_query, exec_request_with_query_and_memory_limit,
        get_test_index_from_terms, get_test_index_from_values_and_terms,
    };
    use crate::aggregation::{AggregationLimitsGuard, BucketId, DistributedAggregationCollector};
    use crate::indexer::NoMergePolicy;
    use crate::query::AllQuery;
    use crate::schema::{IntoIpv6Addr, Schema, FAST, INDEXED, STRING, TEXT};
    use crate::{Index, IndexWriter};

    #[test]
    fn low_card_term_map_consolidates_count_lanes_and_shares_bucket_ids() {
        let mut bucket_id_provider = BucketIdProvider::default();
        let mut map = VecTermBucketsWithLanes::<BucketId>::new(3, &mut bucket_id_provider);
        let mut expected_counts = [0u32; 3];

        // Exercise every lane with a deliberately skewed distribution.
        for i in 0..10_003usize {
            let term_id = if i % 101 == 0 {
                2
            } else if i % 11 == 0 {
                1
            } else {
                0
            };
            let bucket_id = map.term_entry(term_id as u64, &mut bucket_id_provider);
            assert_eq!(bucket_id, term_id as BucketId);
            expected_counts[term_id] += 1;
        }

        // The count lanes do not expand the sub-aggregation bucket-id space.
        assert_eq!(bucket_id_provider.next_bucket_id(), 3);

        let entries = map.into_vec();
        assert_eq!(entries.len(), expected_counts.len());
        for (term_id, bucket) in entries {
            assert_eq!(bucket.count, expected_counts[term_id as usize]);
            assert_eq!(bucket.bucket_id, term_id as BucketId);
        }
    }

    #[test]
    fn paged_term_map_reuses_buckets_and_counts() {
        let mut bucket_id_provider = BucketIdProvider::default();
        let mut map =
            PagedTermMap::<BucketId>::new((PAGE_SIZE * 2) as u64, &mut bucket_id_provider);

        let bucket_first = map.term_entry(5, &mut bucket_id_provider);
        let bucket_second_page = map.term_entry((PAGE_SIZE + 7) as u64, &mut bucket_id_provider);

        // Reinsertions should increment counts and reuse bucket ids
        assert_eq!(map.term_entry(5, &mut bucket_id_provider), bucket_first);
        assert_eq!(
            map.term_entry((PAGE_SIZE + 7) as u64, &mut bucket_id_provider),
            bucket_second_page
        );

        // High offset exercises the TinySet presence word boundaries.
        let bucket_high_bit = map.term_entry(63, &mut bucket_id_provider);

        let mut entries = map.into_vec();
        entries.sort_by_key(|(term_id, _)| *term_id);

        let expected = vec![
            (5u64, bucket_first, 2u32),
            (63u64, bucket_high_bit, 1u32),
            ((PAGE_SIZE + 7) as u64, bucket_second_page, 2u32),
        ];

        assert_eq!(entries.len(), expected.len());
        for ((term_id, bucket), (expected_term, expected_bucket_id, expected_count)) in
            entries.into_iter().zip(expected)
        {
            assert_eq!(term_id, expected_term);
            assert_eq!(bucket.bucket_id, expected_bucket_id);
            assert_eq!(bucket.count, expected_count);
        }
    }

    #[test]
    fn terms_aggregation_u64_max_value_does_not_overflow() -> crate::Result<()> {
        // Regression: a numeric fast field whose max value is `u64::MAX` must reach the HashMap
        // storage without panicking on `max_column_val + 1` (the dense-storage term count), which
        // overflows in debug builds before that fallback is chosen.
        let mut schema_builder = Schema::builder();
        let score_fieldtype = crate::schema::NumericOptions::default().set_fast();
        let score_field = schema_builder.add_u64_field("score", score_fieldtype);
        let index = Index::create_in_ram(schema_builder.build());
        {
            let mut index_writer = index.writer_with_num_threads(1, 20_000_000)?;
            index_writer.set_merge_policy(Box::new(NoMergePolicy));
            index_writer.add_document(doc!(score_field => u64::MAX))?;
            index_writer.add_document(doc!(score_field => u64::MAX))?;
            index_writer.add_document(doc!(score_field => 0u64))?;
            index_writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_scores": {
                "terms": { "field": "score" },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_scores"]["buckets"][0]["key"], u64::MAX as f64);
        assert_eq!(res["my_scores"]["buckets"][0]["doc_count"], 2);
        assert_eq!(res["my_scores"]["buckets"][1]["key"], 0.0);
        assert_eq!(res["my_scores"]["buckets"][1]["doc_count"], 1);
        assert_eq!(res["my_scores"]["sum_other_doc_count"], 0);
        Ok(())
    }

    #[test]
    fn terms_aggregation_normalizes_u64_keys_across_segments() {
        let mut schema_builder = Schema::builder();
        let json_field = schema_builder.add_json_field("json", FAST);
        let index = Index::create_in_ram(schema_builder.build());
        {
            let mut index_writer = index.writer_for_tests().unwrap();
            index_writer.set_merge_policy(Box::new(NoMergePolicy));

            // The presence of `u64::MAX` makes this segment's numeric column a `u64` column.
            index_writer
                .add_document(doc!(json_field => json!({"number": 1u64})))
                .unwrap();
            index_writer
                .add_document(doc!(json_field => json!({"number": u64::MAX})))
                .unwrap();
            index_writer.commit().unwrap();

            // The negative value makes this segment's numeric column an `i64` column.
            index_writer
                .add_document(doc!(json_field => json!({"number": 1i64})))
                .unwrap();
            index_writer
                .add_document(doc!(json_field => json!({"number": -1i64})))
                .unwrap();
            index_writer.commit().unwrap();
        }
        assert_eq!(index.searchable_segments().unwrap().len(), 2);

        let agg_req: Aggregations = serde_json::from_value(json!({
            "numbers": {
                "terms": { "field": "json.number" },
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index).unwrap();
        let mut buckets: Vec<serde_json::Value> =
            res["numbers"]["buckets"].as_array().unwrap().clone();
        // a lot of effort to get a stable order.
        buckets.sort_by_key(|json_val| {
            json_val
                .as_object()
                .unwrap()
                .get("key")
                .unwrap()
                .as_number()
                .map(|number| (number.as_i64(), number.as_u64()))
                .unwrap()
        });
        assert_eq!(
            buckets,
            &[
                json!({"key": u64::MAX, "doc_count": 1}),
                json!({"key": -1, "doc_count": 1}),
                json!({"key": 1, "doc_count": 2}),
            ]
        );
    }

    #[test]
    fn terms_aggregation_merges_normalized_f64_buckets_with_sub_aggregations() -> crate::Result<()>
    {
        let index = get_test_index_from_values_and_terms(
            true,
            &[vec![
                (-0.0, "negative_zero".to_string()),
                (0.0, "positive_zero".to_string()),
            ]],
        )?;
        let agg_req: Aggregations = serde_json::from_value(json!({
            "zeros": {
                "terms": { "field": "score_f64" },
                "aggs": {
                    "signs": { "terms": { "field": "string_id" } }
                }
            }
        }))?;

        let result = exec_request(agg_req, &index)?;
        let zero_buckets = result["zeros"]["buckets"].as_array().unwrap();
        assert_eq!(zero_buckets.len(), 1, "unexpected result: {result}");
        assert_eq!(zero_buckets[0]["key"], 0);
        assert_eq!(zero_buckets[0]["doc_count"], 2);

        let sign_buckets = zero_buckets[0]["signs"]["buckets"].as_array().unwrap();
        assert_eq!(sign_buckets.len(), 2, "unexpected result: {result}");
        for sign in ["negative_zero", "positive_zero"] {
            let bucket = sign_buckets
                .iter()
                .find(|bucket| bucket["key"] == sign)
                .unwrap_or_else(|| panic!("missing {sign:?} bucket in {result}"));
            assert_eq!(bucket["doc_count"], 1);
        }
        Ok(())
    }

    #[test]
    fn terms_aggregation_test_single_segment() -> crate::Result<()> {
        terms_aggregation_test_merge_segment(true)
    }
    #[test]
    fn terms_aggregation_test() -> crate::Result<()> {
        terms_aggregation_test_merge_segment(false)
    }
    fn terms_aggregation_test_merge_segment(merge_segments: bool) -> crate::Result<()> {
        let segment_and_terms = vec![
            vec!["terma"],
            vec!["termb"],
            vec!["termc"],
            vec!["terma"],
            vec!["terma"],
            vec!["terma"],
            vec!["termb"],
            vec!["terma"],
        ];
        let index = get_test_index_from_terms(merge_segments, &segment_and_terms)?;

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][2]["doc_count"], 1);
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "size": 2,
                    "segment_size": 2
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(
            res["my_texts"]["buckets"][2]["key"],
            serde_json::Value::Null
        );
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 1);

        // include filter: only terma and termc
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "include": ["terma", "termc"],
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 1);
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // exclude filter: remove termc
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "exclude": ["termc"],
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // include regex (single string): only termb
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "include": "termb",
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 2);
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // include regex (term.*) with exclude regex (termc): expect terma and termb
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "include": "term.*",
                    "exclude": "termc",
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // test min_doc_count
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "size": 2,
                    "min_doc_count": 3,
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 5);
        assert_eq!(
            res["my_texts"]["buckets"][1]["key"],
            serde_json::Value::Null
        );
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0); // TODO sum_other_doc_count with
                                                               // min_doc_count
        Ok(())
    }

    #[test]
    fn terms_aggregation_test_order_count_single_segment() -> crate::Result<()> {
        terms_aggregation_test_order_count_merge_segment(true)
    }
    #[test]
    fn terms_aggregation_test_count_order() -> crate::Result<()> {
        terms_aggregation_test_order_count_merge_segment(false)
    }
    fn terms_aggregation_test_order_count_merge_segment(merge_segments: bool) -> crate::Result<()> {
        let segment_and_terms = vec![
            vec![(5.0, "terma".to_string())],
            vec![(2.0, "termb".to_string())],
            vec![(2.0, "terma".to_string())],
            vec![(1.0, "termc".to_string())],
            vec![(1.0, "termc".to_string())],
            vec![(1.0, "termc".to_string())],
            vec![(5.0, "terma".to_string())],
            vec![(5.0, "terma".to_string())],
            vec![(5.0, "terma".to_string())],
            vec![(8.0, "termb".to_string())],
            vec![(5.0, "terma".to_string())],
        ];
        let index = get_test_index_from_values_and_terms(merge_segments, &segment_and_terms)?;

        let sub_agg: Aggregations = serde_json::from_value(json!({
            "avg_score": {
                "avg": {
                    "field": "score",
                }
            },
            "stats_score": {
                "stats": {
                    "field": "score",
                }
            }
        }))
        .unwrap();

        // sub agg desc
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "_count": "asc",
                    },
                },
                "aggs": sub_agg,
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 2);
        assert_eq!(res["my_texts"]["buckets"][0]["avg_score"]["value"], 5.0);

        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 3);
        assert_eq!(res["my_texts"]["buckets"][1]["avg_score"]["value"], 1.0);

        assert_eq!(res["my_texts"]["buckets"][2]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][2]["doc_count"], 6);
        assert_eq!(res["my_texts"]["buckets"][2]["avg_score"]["value"], 4.5);

        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // Agg on non string
        //
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_scores1": {
                "terms": {
                    "field": "score",
                    "order": {
                        "_count": "asc",
                    },
                },
                "aggs": sub_agg,
            },
            "my_scores2": {
                "terms": {
                    "field": "score_f64",
                    "order": {
                        "_count": "asc",
                    },
                },
                "aggs": sub_agg,
            },
            "my_scores3": {
                "terms": {
                    "field": "score_i64",
                    "order": {
                        "_count": "asc",
                    },
                },
                "aggs": sub_agg,
            }

        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_scores1"]["buckets"][0]["key"], 8.0);
        assert_eq!(res["my_scores1"]["buckets"][0]["doc_count"], 1);
        assert_eq!(res["my_scores1"]["buckets"][0]["avg_score"]["value"], 8.0);

        assert_eq!(res["my_scores1"]["buckets"][1]["key"], 2.0);
        assert_eq!(res["my_scores1"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_scores1"]["buckets"][1]["avg_score"]["value"], 2.0);

        assert_eq!(res["my_scores1"]["buckets"][2]["key"], 1.0);
        assert_eq!(res["my_scores1"]["buckets"][2]["doc_count"], 3);
        assert_eq!(res["my_scores1"]["buckets"][2]["avg_score"]["value"], 1.0);

        assert_eq!(res["my_scores1"]["buckets"][3]["key"], 5.0);
        assert_eq!(res["my_scores1"]["buckets"][3]["doc_count"], 5);
        assert_eq!(res["my_scores1"]["buckets"][3]["avg_score"]["value"], 5.0);

        assert_eq!(res["my_scores1"]["sum_other_doc_count"], 0);

        assert_eq!(res["my_scores2"]["buckets"][0]["key"], 8.0);
        assert_eq!(res["my_scores2"]["buckets"][0]["doc_count"], 1);
        assert_eq!(res["my_scores2"]["buckets"][0]["avg_score"]["value"], 8.0);

        assert_eq!(res["my_scores2"]["buckets"][1]["key"], 2.0);
        assert_eq!(res["my_scores2"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_scores2"]["buckets"][1]["avg_score"]["value"], 2.0);

        assert_eq!(res["my_scores2"]["buckets"][2]["key"], 1.0);
        assert_eq!(res["my_scores2"]["buckets"][2]["doc_count"], 3);
        assert_eq!(res["my_scores2"]["buckets"][2]["avg_score"]["value"], 1.0);

        assert_eq!(res["my_scores2"]["sum_other_doc_count"], 0);

        assert_eq!(res["my_scores3"]["buckets"][0]["key"], 8.0);
        assert_eq!(res["my_scores3"]["buckets"][0]["doc_count"], 1);
        assert_eq!(res["my_scores3"]["buckets"][0]["avg_score"]["value"], 8.0);

        assert_eq!(res["my_scores3"]["buckets"][1]["key"], 2.0);
        assert_eq!(res["my_scores3"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_scores3"]["buckets"][1]["avg_score"]["value"], 2.0);

        assert_eq!(res["my_scores3"]["buckets"][2]["key"], 1.0);
        assert_eq!(res["my_scores3"]["buckets"][2]["doc_count"], 3);
        assert_eq!(res["my_scores3"]["buckets"][2]["avg_score"]["value"], 1.0);

        assert_eq!(res["my_scores3"]["sum_other_doc_count"], 0);

        Ok(())
    }

    #[test]
    fn test_simple_agg() {
        let segment_and_terms = vec![vec![(5.0, "terma".to_string())]];
        let index = get_test_index_from_values_and_terms(true, &segment_and_terms).unwrap();

        let sub_agg: Aggregations = serde_json::from_value(json!({
            "avg_score": {
                "avg": {
                    "field": "score",
                }
            }
        }))
        .unwrap();

        // sub agg desc
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "_count": "asc",
                    },
                        },
                        "aggs": sub_agg,
                    }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index).unwrap();
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 1);
        assert_eq!(res["my_texts"]["buckets"][0]["avg_score"]["value"], 5.0);
    }

    #[test]
    fn terms_aggregation_test_order_sub_agg_single_segment() -> crate::Result<()> {
        terms_aggregation_test_order_sub_agg_merge_segment(true)
    }
    #[test]
    fn terms_aggregation_test_sub_agg_order() -> crate::Result<()> {
        terms_aggregation_test_order_sub_agg_merge_segment(false)
    }
    fn terms_aggregation_test_order_sub_agg_merge_segment(
        merge_segments: bool,
    ) -> crate::Result<()> {
        let segment_and_terms = vec![
            vec![(5.0, "terma".to_string())],
            vec![(4.0, "termb".to_string())],
            vec![(1.0, "termc".to_string())],
            vec![(1.0, "termc".to_string())],
            vec![(1.0, "termc".to_string())],
            vec![(5.0, "terma".to_string())],
            vec![(5.0, "terma".to_string())],
            vec![(5.0, "terma".to_string())],
            vec![(8.0, "termb".to_string())],
            vec![(5.0, "terma".to_string())],
        ];
        let index = get_test_index_from_values_and_terms(merge_segments, &segment_and_terms)?;

        let sub_agg: Aggregations = serde_json::from_value(json!({
            "avg_score": {
                "avg": {
                    "field": "score",
                }
            },
            "stats_score": {
                "stats": {
                    "field": "score",
                }
            }
        }))
        .unwrap();

        // sub agg desc
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "avg_score": "desc"
                    }
                },
                "aggs": sub_agg,
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 2);
        assert_eq!(res["my_texts"]["buckets"][0]["avg_score"]["value"], 6.0);

        assert_eq!(res["my_texts"]["buckets"][1]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["avg_score"]["value"], 5.0);

        assert_eq!(res["my_texts"]["buckets"][2]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][2]["doc_count"], 3);
        assert_eq!(res["my_texts"]["buckets"][2]["avg_score"]["value"], 1.0);

        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // sub agg asc
        //
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "avg_score": "asc"
                    }
                },
                "aggs": sub_agg,
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;

        assert_eq!(res["my_texts"]["buckets"][0]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 3);
        assert_eq!(res["my_texts"]["buckets"][0]["avg_score"]["value"], 1.0);

        assert_eq!(res["my_texts"]["buckets"][1]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["avg_score"]["value"], 5.0);

        assert_eq!(res["my_texts"]["buckets"][2]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][2]["doc_count"], 2);
        assert_eq!(res["my_texts"]["buckets"][2]["avg_score"]["value"], 6.0);

        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // sub agg multi value asc
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "stats_score.avg": "asc"
                    }
                },
                "aggs": sub_agg,
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;

        assert_eq!(res["my_texts"]["buckets"][0]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 3);
        assert_eq!(res["my_texts"]["buckets"][0]["avg_score"]["value"], 1.0);

        assert_eq!(res["my_texts"]["buckets"][1]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["avg_score"]["value"], 5.0);

        assert_eq!(res["my_texts"]["buckets"][2]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][2]["doc_count"], 2);
        assert_eq!(res["my_texts"]["buckets"][2]["avg_score"]["value"], 6.0);

        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // sub agg invalid request
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "doesnotexist": "asc"
                    }
                },
                "aggs": sub_agg,
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index);
        assert!(res.is_err());

        Ok(())
    }

    #[test]
    fn terms_aggregation_order_by_cardinality_desc_single_segment() -> crate::Result<()> {
        terms_aggregation_order_by_cardinality_desc(true)
    }
    #[test]
    fn terms_aggregation_order_by_cardinality_desc_multi_segment() -> crate::Result<()> {
        terms_aggregation_order_by_cardinality_desc(false)
    }
    fn terms_aggregation_order_by_cardinality_desc(merge_segments: bool) -> crate::Result<()> {
        // Distinct score values per bucket key: A→5, B→1, C→3.
        // Order by cardinality desc must yield A, C, B.
        let segment_and_terms = vec![vec![
            (1.0, "A".to_string()),
            (2.0, "A".to_string()),
            (3.0, "A".to_string()),
            (4.0, "A".to_string()),
            (5.0, "A".to_string()),
            (1.0, "B".to_string()),
            (1.0, "B".to_string()),
            (1.0, "B".to_string()),
            (1.0, "C".to_string()),
            (2.0, "C".to_string()),
            (3.0, "C".to_string()),
        ]];
        let index = get_test_index_from_values_and_terms(merge_segments, &segment_and_terms)?;

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": { "card": "desc" }
                },
                "aggs": {
                    "card": { "cardinality": { "field": "score" } }
                }
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "A");
        assert_eq!(res["my_texts"]["buckets"][0]["card"]["value"], 5.0);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"][1]["card"]["value"], 3.0);
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "B");
        assert_eq!(res["my_texts"]["buckets"][2]["card"]["value"], 1.0);

        // Asc engages the segment-cutoff path too (monotonic-safe: discarded buckets had
        // local card >= cutoff, so merged card >= cutoff and they cannot be globally smallest).
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": { "card": "asc" }
                },
                "aggs": {
                    "card": { "cardinality": { "field": "score" } }
                }
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "B");
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "A");

        // size=2 with desc engages the segment cutoff: must keep top-2 by cardinality (A, C),
        // and `sum_other_doc_count` reflects the dropped B (3 docs).
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "size": 2,
                    "order": { "card": "desc" }
                },
                "aggs": {
                    "card": { "cardinality": { "field": "score" } }
                }
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "A");
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"].as_array().unwrap().len(), 2);

        // size=2 with asc engages the segment cutoff: must keep bottom-2 by cardinality (B, C).
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "size": 2,
                    "order": { "card": "asc" }
                },
                "aggs": {
                    "card": { "cardinality": { "field": "score" } }
                }
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "B");
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"].as_array().unwrap().len(), 2);

        Ok(())
    }

    #[test]
    fn terms_aggregation_order_by_sum_single_segment() -> crate::Result<()> {
        terms_aggregation_order_by_sum(true)
    }
    #[test]
    fn terms_aggregation_order_by_sum_multi_segment() -> crate::Result<()> {
        terms_aggregation_order_by_sum(false)
    }
    fn terms_aggregation_order_by_sum(merge_segments: bool) -> crate::Result<()> {
        // Per-bucket sums on the U64 `score` column (non-negative => sum is monotonic):
        //   A → 1+2+3+4+5 = 15, B → 1+1+1 = 3, C → 1+2+3 = 6.
        let segment_and_terms = vec![
            vec![
                (1.0, "A".to_string()),
                (2.0, "A".to_string()),
                (3.0, "A".to_string()),
                (1.0, "B".to_string()),
                (1.0, "C".to_string()),
            ],
            vec![
                (4.0, "A".to_string()),
                (5.0, "A".to_string()),
                (1.0, "B".to_string()),
                (1.0, "B".to_string()),
                (2.0, "C".to_string()),
                (3.0, "C".to_string()),
            ],
        ];
        let index = get_test_index_from_values_and_terms(merge_segments, &segment_and_terms)?;

        // Desc on a Sum metric engages the fast path (column is U64).
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": { "total": "desc" }
                },
                "aggs": {
                    "total": { "sum": { "field": "score" } }
                }
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "A");
        assert_eq!(res["my_texts"]["buckets"][0]["total"]["value"], 15.0);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"][1]["total"]["value"], 6.0);
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "B");
        assert_eq!(res["my_texts"]["buckets"][2]["total"]["value"], 3.0);

        // Asc engages the fast path too — discarded buckets had local sum >= cutoff,
        // and merged sum >= local (non-negative addends), so they cannot be globally smallest.
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": { "total": "asc" }
                },
                "aggs": {
                    "total": { "sum": { "field": "score" } }
                }
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "B");
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "A");

        // size=2 desc with cutoff: top-2 by sum (A, C).
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "size": 2,
                    "order": { "total": "desc" }
                },
                "aggs": {
                    "total": { "sum": { "field": "score" } }
                }
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "A");
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"].as_array().unwrap().len(), 2);

        // Stats sub-property: ordering by `mystats.sum` on a U64 column also engages.
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": { "mystats.sum": "desc" }
                },
                "aggs": {
                    "mystats": { "stats": { "field": "score" } }
                }
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "A");
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "B");

        // Sum on a signed column (I64) takes the same cutoff path. Results may be
        // approximate near the boundary on adversarial data, but for this dataset the
        // top-K is unambiguous.
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": { "total": "desc" }
                },
                "aggs": {
                    "total": { "sum": { "field": "score_i64" } }
                }
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "A");
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "B");

        // Order by extended_stats sub-property exercises compute_metric_value on the
        // ExtendedStats collector. A→max=5, B→max=1, C→max=3, so desc by max → A, C, B.
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": { "ext.max": "desc" }
                },
                "aggs": {
                    "ext": { "extended_stats": { "field": "score" } }
                }
            }
        }))
        .unwrap();
        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "A");
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "C");
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "B");

        Ok(())
    }

    #[test]
    fn terms_aggregation_test_order_key_single_segment() -> crate::Result<()> {
        terms_aggregation_test_order_key_merge_segment(true)
    }
    #[test]
    fn terms_aggregation_test_key_order() -> crate::Result<()> {
        terms_aggregation_test_order_key_merge_segment(false)
    }
    fn terms_aggregation_test_order_key_merge_segment(merge_segments: bool) -> crate::Result<()> {
        let segment_and_terms = vec![
            vec![(5.0, "terma".to_string())],
            vec![(4.0, "termb".to_string())],
            vec![(1.0, "termc".to_string())],
            vec![(1.0, "termc".to_string())],
            vec![(1.0, "termc".to_string())],
            vec![(5.0, "terma".to_string())],
            vec![(5.0, "terma".to_string())],
            vec![(5.0, "terma".to_string())],
            vec![(8.0, "termb".to_string())],
            vec![(5.0, "terma".to_string())],
        ];
        let index = get_test_index_from_values_and_terms(merge_segments, &segment_and_terms)?;

        // key asc
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "_key": "asc"
                    }
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][2]["doc_count"], 3);
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // key desc and size cut_off
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "_key": "asc"
                    },
                    "size": 2
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(
            res["my_texts"]["buckets"][2]["doc_count"],
            serde_json::Value::Null
        );

        assert_eq!(res["my_texts"]["sum_other_doc_count"], 3);

        // key asc and segment_size cut_off
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "_key": "asc"
                    },
                    "size": 2,
                    "segment_size": 2
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 5);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(
            res["my_texts"]["buckets"][2]["doc_count"],
            serde_json::Value::Null
        );

        // key desc
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "_key": "desc"
                    },
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 3);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_texts"]["buckets"][2]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][2]["doc_count"], 5);
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        // key desc, size cut_off
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "_key": "desc"
                    },
                    "size": 2
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 3);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(
            res["my_texts"]["buckets"][2]["doc_count"],
            serde_json::Value::Null
        );
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 5);

        // key desc, segment_size cut_off
        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "order": {
                        "_key": "desc"
                    },
                    "size": 2,
                    "segment_size": 2
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "termc");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 3);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(
            res["my_texts"]["buckets"][2]["doc_count"],
            serde_json::Value::Null
        );

        Ok(())
    }

    #[test]
    fn terms_aggregation_min_doc_count_special_case() -> crate::Result<()> {
        let terms_per_segment = vec![
            vec!["terma", "terma", "termb", "termb", "termb"],
            vec!["terma", "terma", "termb"],
        ];

        let index = get_test_index_from_terms(false, &terms_per_segment)?;

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "min_doc_count": 0,
                },
            }
        }))
        .unwrap();

        // searching for terma, but min_doc_count will return all terms
        let res = exec_request_with_query(agg_req, &index, Some(("string_id", "terma")))?;

        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 4);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 0);
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);
        assert_eq!(res["my_texts"]["doc_count_error_upper_bound"], 0);

        Ok(())
    }

    #[test]
    fn terms_aggregation_min_doc_count_special_case_with_sub_agg_empty_merge() -> crate::Result<()>
    {
        let mut schema_builder = Schema::builder();
        let string_field_1 = schema_builder.add_text_field("string1", STRING | FAST);
        let string_field_2 = schema_builder.add_text_field("string2", STRING | FAST);
        let score_fieldtype = crate::schema::NumericOptions::default().set_fast();
        let score_field = schema_builder.add_u64_field("score", score_fieldtype);
        let index = Index::create_in_ram(schema_builder.build());
        {
            let mut index_writer = index.writer_with_num_threads(1, 20_000_000)?;
            index_writer.set_merge_policy(Box::new(NoMergePolicy));
            // writing the segment
            index_writer.add_document(doc!(
                string_field_1 => "A".to_string(),
                string_field_2 => "hit".to_string(),
                score_field => 1u64,
            ))?;
            index_writer.add_document(doc!(
                string_field_1 => "B".to_string(),
                string_field_2 => "nohit".to_string(), // this doc gets filtered in this segment,
                                                       // but the term will still be loaded because
                                                       // min_doc_count == 0
                score_field => 2u64,
            ))?;
            index_writer.commit()?;

            index_writer.add_document(doc!(
                string_field_1 => "A".to_string(),
                string_field_2 => "hit".to_string(),
                score_field => 2u64,
            ))?;
            index_writer.add_document(doc!(
                string_field_1 => "B".to_string(),
                string_field_2 => "hit".to_string(),
                score_field => 4u64,
            ))?;
            index_writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string1",
                    "min_doc_count": 0,
                },
                "aggs":{
                    "elhistogram": {
                        "histogram": {
                            "field": "score",
                            "interval": 1
                        }
                    }
                }
            }
        }))
        .unwrap();

        // searching for terma, but min_doc_count will return all terms
        let res = exec_request_with_query(agg_req, &index, Some(("string2", "hit")))?;

        assert_eq!(res["my_texts"]["buckets"][0]["key"], "A");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 2);
        assert_eq!(
            res["my_texts"]["buckets"][0]["elhistogram"]["buckets"],
            json!([{ "doc_count": 1, "key": 1.0 }, { "doc_count": 1, "key": 2.0 } ])
        );
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "B");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 1);
        assert_eq!(
            res["my_texts"]["buckets"][1]["elhistogram"]["buckets"],
            json!([ { "doc_count": 1, "key": 4.0 } ])
        );
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);
        assert_eq!(res["my_texts"]["doc_count_error_upper_bound"], 0);

        Ok(())
    }

    #[test]
    fn terms_aggregation_error_count_test() -> crate::Result<()> {
        let terms_per_segment = vec![
            vec!["terma", "terma", "termb", "termb", "termb", "termc"], /* termc doesn't make it
                                                                         * from this segment */
            vec!["terma", "terma", "termb", "termc", "termc"], /* termb doesn't make it from
                                                                * this segment */
        ];

        let index = get_test_index_from_terms(false, &terms_per_segment)?;
        assert_eq!(index.searchable_segments().unwrap().len(), 2);

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "size": 2,
                    "segment_size": 2
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;

        assert_eq!(res["my_texts"]["buckets"][0]["key"], "terma");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 4);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "termb");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 3);
        assert_eq!(
            res["my_texts"]["buckets"][2]["doc_count"],
            serde_json::Value::Null
        );
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 4);
        assert_eq!(res["my_texts"]["doc_count_error_upper_bound"], 2);

        // disable doc_count_error_upper_bound

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "size": 2,
                    "segment_size": 2,
                    "show_term_doc_count_error": false
                },
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;

        assert_eq!(res["my_texts"]["sum_other_doc_count"], 4);
        assert_eq!(
            res["my_texts"]["doc_count_error_upper_bound"],
            serde_json::Value::Null
        );

        Ok(())
    }

    #[test]
    fn terms_aggregation_term_bucket_limit() -> crate::Result<()> {
        let terms: Vec<String> = (0..20_000).map(|el| el.to_string()).collect();
        let terms_per_segment = vec![terms.iter().map(|el| el.as_str()).collect()];

        let index = get_test_index_from_terms(true, &terms_per_segment)?;

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "min_doc_count": 0,
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query_and_memory_limit(
            agg_req,
            &index,
            None,
            AggregationLimitsGuard::new(Some(50_000), None),
        )
        .unwrap_err();
        assert!(res
            .to_string()
            .contains("Aborting aggregation because memory limit was exceeded. Limit: 50.00 KB"));

        Ok(())
    }

    // Eager bucket ids: below LAZY_BUCKET_ID_GENERATION_THRESHOLD but above
    // MAX_NUM_TERMS_FOR_LOWCARD_SUBAGG, so the `Vec` + `HighCard` buffer path assigns ids eagerly.
    #[test]
    fn terms_aggregation_sub_agg_vec_highcard_eager_ids() -> crate::Result<()> {
        terms_agg_sub_agg_bucket_id_linkage(500)
    }

    // Lazy bucket ids: above LAZY_BUCKET_ID_GENERATION_THRESHOLD (4096), still below
    // MAX_NUM_TERMS_FOR_VEC, so the `Vec` + `HighCard` path assigns ids lazily on first occurrence.
    #[test]
    fn terms_aggregation_sub_agg_vec_highcard_lazy_ids() -> crate::Result<()> {
        terms_agg_sub_agg_bucket_id_linkage(5000)
    }

    /// Builds `num_terms` distinct terms (each with a known score and a varying doc count),
    /// inserted in reverse term order so any lazily-assigned bucket ids (first-seen order) are
    /// fully de-correlated from the term ordinals (sorted order). Verifies per-term doc counts
    /// and metric sub-agg values, guarding the bucket-id -> sub-agg linkage on the `Vec` +
    /// `HighCard` path.
    fn terms_agg_sub_agg_bucket_id_linkage(num_terms: u64) -> crate::Result<()> {
        let mut docs: Vec<(f64, String)> = Vec::new();
        for k in (0..num_terms).rev() {
            let count = (k % 3) + 1;
            for _ in 0..count {
                docs.push((k as f64, format!("term_{k:06}")));
            }
        }
        let index = get_test_index_from_values_and_terms(false, &[docs])?;

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "string_id",
                    "size": num_terms,
                    "order": { "_key": "asc" }
                },
                "aggs": {
                    "sum_score": { "sum": { "field": "score" } },
                    "avg_score": { "avg": { "field": "score" } }
                }
            }
        }))
        .unwrap();

        let res = exec_request(agg_req, &index)?;
        let buckets = &res["my_texts"]["buckets"];
        for k in 0..num_terms {
            let count = (k % 3) + 1;
            let bucket = &buckets[k as usize];
            assert_eq!(bucket["key"], format!("term_{k:06}"), "key at {k}");
            assert_eq!(bucket["doc_count"], count, "doc_count at {k}");
            assert_eq!(
                bucket["sum_score"]["value"],
                (k * count) as f64,
                "sum at {k}"
            );
            assert_eq!(bucket["avg_score"]["value"], k as f64, "avg at {k}");
        }
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);

        Ok(())
    }

    #[test]
    fn terms_aggregation_different_tokenizer_on_ff_test() -> crate::Result<()> {
        let terms = vec!["Hello Hello", "Hallo Hallo", "Hallo Hallo"];

        let index = get_test_index_from_terms(true, &[terms])?;

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "text_id",
                    "min_doc_count": 0,
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None).unwrap();
        println!("{}", serde_json::to_string_pretty(&res).unwrap());

        assert_eq!(res["my_texts"]["buckets"][0]["key"], "Hallo Hallo");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 2);

        assert_eq!(res["my_texts"]["buckets"][1]["key"], "Hello Hello");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 1);

        Ok(())
    }

    #[test]
    fn test_json_format() -> crate::Result<()> {
        let agg_req: Aggregations = serde_json::from_value(json!({
            "term_agg_test": {
                "terms": {
                    "field": "string_id",
                    "size": 2,
                    "segment_size": 2,
                    "order": {
                        "_key": "desc"
                    }
                },
            }
        }))
        .unwrap();

        let elasticsearch_compatible_json = json!(
        {
        "term_agg_test":{
            "terms": {
                "field": "string_id",
                "size": 2u64,
                "segment_size": 2u64,
                "order": {"_key": "desc"}
            }
        }
        });

        let agg_req_deser: Aggregations =
            serde_json::from_str(&serde_json::to_string(&elasticsearch_compatible_json).unwrap())
                .unwrap();
        assert_eq!(agg_req, agg_req_deser);

        let elasticsearch_compatible_json = json!(
        {
        "term_agg_test":{
            "terms": {
                "field": "string_id",
                "split_size": 2u64,
            }
        }
        });

        // test alias shard_size, split_size
        let agg_req: Aggregations = serde_json::from_value(json!({
            "term_agg_test": {
                "terms": {
                    "field": "string_id",
                    "split_size": 2,
                },
            }
        }))
        .unwrap();

        let agg_req_deser: Aggregations =
            serde_json::from_str(&serde_json::to_string(&elasticsearch_compatible_json).unwrap())
                .unwrap();
        assert_eq!(agg_req, agg_req_deser);

        let elasticsearch_compatible_json = json!(
        {
        "term_agg_test":{
            "terms": {
                "field": "string_id",
                "shard_size": 2u64,
            }
        }
        });

        let agg_req_deser: Aggregations =
            serde_json::from_str(&serde_json::to_string(&elasticsearch_compatible_json).unwrap())
                .unwrap();
        assert_eq!(agg_req, agg_req_deser);

        Ok(())
    }
    #[test]
    fn terms_empty_json() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        let json = schema_builder.add_json_field("json", FAST);
        let schema = schema_builder.build();
        let index = Index::create_in_ram(schema);
        let mut index_writer: IndexWriter = index.writer_for_tests().unwrap();
        // => Segment with empty json
        index_writer.add_document(doc!()).unwrap();
        index_writer.commit().unwrap();
        // => Segment with json, but no field partially_empty
        index_writer
            .add_document(doc!(json => json!({"different_field": "blue"})))
            .unwrap();
        index_writer.commit().unwrap();
        //// => Segment with field partially_empty
        index_writer
            .add_document(doc!(json => json!({"partially_empty": "blue"})))
            .unwrap();
        index_writer.add_document(doc!())?;
        index_writer.commit().unwrap();

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "json.partially_empty"
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;

        assert_eq!(res["my_texts"]["buckets"][0]["key"], "blue");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 1);
        assert_eq!(res["my_texts"]["buckets"][1], serde_json::Value::Null);
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);
        assert_eq!(res["my_texts"]["doc_count_error_upper_bound"], 0);

        Ok(())
    }

    #[test]
    fn terms_aggregation_bytes() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        let bytes_field = schema_builder.add_bytes_field("bytes", FAST);
        let index = Index::create_in_ram(schema_builder.build());
        {
            let mut index_writer = index.writer_with_num_threads(1, 20_000_000)?;
            index_writer.set_merge_policy(Box::new(NoMergePolicy));
            index_writer.add_document(doc!(
                bytes_field => vec![1,2,3],
            ))?;
            index_writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "bytes"
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None);
        assert!(res.is_err(), "expected error for Bytes field, got {res:?}");

        Ok(())
    }

    #[test]
    fn terms_aggregation_missing_multi_value() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        let text_field = schema_builder.add_text_field("text", FAST);
        let id_field = schema_builder.add_u64_field("id", FAST);
        let index = Index::create_in_ram(schema_builder.build());
        {
            let mut index_writer = index.writer_with_num_threads(1, 20_000_000)?;
            index_writer.set_merge_policy(Box::new(NoMergePolicy));
            index_writer.add_document(doc!(
                text_field => "Hello Hello",
                text_field => "Hello Hello",
                id_field => 1u64,
                id_field => 1u64,
            ))?;
            // Missing
            index_writer.add_document(doc!())?;
            index_writer.add_document(doc!(
                text_field => "Hello Hello",
            ))?;
            index_writer.add_document(doc!(
                text_field => "Hello Hello",
            ))?;
            index_writer.commit()?;
            // Empty segment special case
            index_writer.add_document(doc!())?;
            index_writer.commit()?;
            // Full segment special case
            index_writer.add_document(doc!(
                text_field => "Hello Hello",
                id_field => 1u64,
            ))?;
            index_writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "text",
                    "missing": "Empty"
                },
            },
            "my_texts2": {
                "terms": {
                    "field": "text",
                    "missing": 1337
                },
            },
            "my_ids": {
                "terms": {
                    "field": "id",
                    "missing": 1337
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;

        // text field
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "Hello Hello");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 4);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "Empty");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(
            res["my_texts"]["buckets"][2]["key"],
            serde_json::Value::Null
        );
        // text field with number as missing fallback
        assert_eq!(res["my_texts2"]["buckets"][0]["key"], "Hello Hello");
        assert_eq!(res["my_texts2"]["buckets"][0]["doc_count"], 4);
        assert_eq!(res["my_texts2"]["buckets"][1]["key"], 1337.0);
        assert_eq!(res["my_texts2"]["buckets"][1]["doc_count"], 2);
        assert_eq!(
            res["my_texts2"]["buckets"][2]["key"],
            serde_json::Value::Null
        );
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);
        assert_eq!(res["my_texts"]["doc_count_error_upper_bound"], 0);

        // id field
        assert_eq!(res["my_ids"]["buckets"][0]["key"], 1337.0);
        assert_eq!(res["my_ids"]["buckets"][0]["doc_count"], 4);
        assert_eq!(res["my_ids"]["buckets"][1]["key"], 1.0);
        assert_eq!(res["my_ids"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_ids"]["buckets"][2]["key"], serde_json::Value::Null);

        Ok(())
    }
    #[test]
    fn terms_aggregation_missing_simple_id() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        let id_field = schema_builder.add_u64_field("id", FAST);
        let index = Index::create_in_ram(schema_builder.build());
        {
            let mut index_writer = index.writer_with_num_threads(1, 20_000_000)?;
            index_writer.set_merge_policy(Box::new(NoMergePolicy));
            index_writer.add_document(doc!(
                id_field => 1u64,
            ))?;
            // Missing
            index_writer.add_document(doc!())?;
            index_writer.add_document(doc!())?;
            index_writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_ids": {
                "terms": {
                    "field": "id",
                    "missing": 1337
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;

        // id field
        assert_eq!(res["my_ids"]["buckets"][0]["key"], 1337.0);
        assert_eq!(res["my_ids"]["buckets"][0]["doc_count"], 2);
        assert_eq!(res["my_ids"]["buckets"][1]["key"], 1.0);
        assert_eq!(res["my_ids"]["buckets"][1]["doc_count"], 1);
        assert_eq!(res["my_ids"]["buckets"][2]["key"], serde_json::Value::Null);

        Ok(())
    }

    #[test]
    fn terms_aggregation_u64_value() -> crate::Result<()> {
        // Make sure that large u64 are not truncated
        let mut schema_builder = Schema::builder();
        let id_field = schema_builder.add_u64_field("id", FAST);
        let index = Index::create_in_ram(schema_builder.build());
        {
            let mut index_writer = index.writer_with_num_threads(1, 20_000_000)?;
            index_writer.set_merge_policy(Box::new(NoMergePolicy));
            index_writer.add_document(doc!(
                id_field => 9_223_372_036_854_775_807u64,
            ))?;
            index_writer.add_document(doc!(
                id_field => 1_769_070_189_829_214_202u64,
            ))?;
            index_writer.add_document(doc!(
                id_field => 1_769_070_189_829_214_202u64,
            ))?;
            index_writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_ids": {
                "terms": {
                    "field": "id"
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;

        // id field
        assert_eq!(
            res["my_ids"]["buckets"][0]["key"],
            1_769_070_189_829_214_202u64
        );
        assert_eq!(res["my_ids"]["buckets"][0]["doc_count"], 2);
        assert_eq!(
            res["my_ids"]["buckets"][1]["key"],
            9_223_372_036_854_775_807u64
        );
        assert_eq!(res["my_ids"]["buckets"][1]["doc_count"], 1);
        assert_eq!(res["my_ids"]["buckets"][2]["key"], serde_json::Value::Null);

        Ok(())
    }

    #[test]
    fn terms_aggregation_missing1() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        let text_field = schema_builder.add_text_field("text", FAST);
        let id_field = schema_builder.add_u64_field("id", FAST);
        let index = Index::create_in_ram(schema_builder.build());
        {
            let mut index_writer = index.writer_with_num_threads(1, 20_000_000)?;
            index_writer.set_merge_policy(Box::new(NoMergePolicy));
            index_writer.add_document(doc!(
                text_field => "Hello Hello",
                id_field => 1u64,
            ))?;
            // Missing
            index_writer.add_document(doc!())?;
            index_writer.add_document(doc!(
                text_field => "Hello Hello",
            ))?;
            index_writer.add_document(doc!(
                text_field => "Hello Hello",
            ))?;
            index_writer.commit()?;
            // Empty segment special case
            index_writer.add_document(doc!())?;
            index_writer.commit()?;
            // Full segment special case
            index_writer.add_document(doc!(
                text_field => "Hello Hello",
                id_field => 1u64,
            ))?;
            index_writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "text",
                    "missing": "Empty"
                },
            },
            "my_texts2": {
                "terms": {
                    "field": "text",
                    "missing": 1337
                },
            },
            "my_ids": {
                "terms": {
                    "field": "id",
                    "missing": 1337
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;

        // text field
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "Hello Hello");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 4);
        assert_eq!(res["my_texts"]["buckets"][1]["key"], "Empty");
        assert_eq!(res["my_texts"]["buckets"][1]["doc_count"], 2);
        assert_eq!(
            res["my_texts"]["buckets"][2]["key"],
            serde_json::Value::Null
        );
        // text field with number as missing fallback
        assert_eq!(res["my_texts2"]["buckets"][0]["key"], "Hello Hello");
        assert_eq!(res["my_texts2"]["buckets"][0]["doc_count"], 4);
        assert_eq!(res["my_texts2"]["buckets"][1]["key"], 1337.0);
        assert_eq!(res["my_texts2"]["buckets"][1]["doc_count"], 2);
        assert_eq!(
            res["my_texts2"]["buckets"][2]["key"],
            serde_json::Value::Null
        );
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);
        assert_eq!(res["my_texts"]["doc_count_error_upper_bound"], 0);

        // id field
        assert_eq!(res["my_ids"]["buckets"][0]["key"], 1337.0);
        assert_eq!(res["my_ids"]["buckets"][0]["doc_count"], 4);
        assert_eq!(res["my_ids"]["buckets"][1]["key"], 1.0);
        assert_eq!(res["my_ids"]["buckets"][1]["doc_count"], 2);
        assert_eq!(res["my_ids"]["buckets"][2]["key"], serde_json::Value::Null);

        Ok(())
    }
    #[test]
    fn terms_aggregation_missing_empty() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        schema_builder.add_text_field("text", FAST);
        schema_builder.add_u64_field("id", FAST);
        let index = Index::create_in_ram(schema_builder.build());
        {
            let mut index_writer = index.writer_with_num_threads(1, 20_000_000)?;
            index_writer.set_merge_policy(Box::new(NoMergePolicy));
            // Empty segment special case
            index_writer.add_document(doc!())?;
            index_writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_texts": {
                "terms": {
                    "field": "text",
                    "missing": "Empty"
                },
            },
            "my_texts2": {
                "terms": {
                    "field": "text",
                    "missing": 1337
                },
            },
            "my_ids": {
                "terms": {
                    "field": "id",
                    "missing": 1337
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;

        // text field
        assert_eq!(res["my_texts"]["buckets"][0]["key"], "Empty");
        assert_eq!(res["my_texts"]["buckets"][0]["doc_count"], 1);
        assert_eq!(
            res["my_texts"]["buckets"][1]["key"],
            serde_json::Value::Null
        );
        // text field with number as missing fallback
        assert_eq!(res["my_texts2"]["buckets"][0]["key"], 1337.0);
        assert_eq!(res["my_texts2"]["buckets"][0]["doc_count"], 1);
        assert_eq!(
            res["my_texts2"]["buckets"][1]["key"],
            serde_json::Value::Null
        );
        assert_eq!(res["my_texts"]["sum_other_doc_count"], 0);
        assert_eq!(res["my_texts"]["doc_count_error_upper_bound"], 0);

        // id field
        assert_eq!(res["my_ids"]["buckets"][0]["key"], 1337.0);
        assert_eq!(res["my_ids"]["buckets"][0]["doc_count"], 1);
        assert_eq!(res["my_ids"]["buckets"][1]["key"], serde_json::Value::Null);

        Ok(())
    }

    #[test]
    fn terms_aggregation_date() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        let date_field = schema_builder.add_date_field("date_field", FAST);
        let schema = schema_builder.build();
        let index = Index::create_in_ram(schema);
        {
            let mut writer = index.writer_with_num_threads(1, 15_000_000)?;
            writer.add_document(doc!(date_field=>DateTime::from_primitive(Date::from_calendar_date(1982, Month::September, 17)?.with_hms(0, 0, 0)?)))?;
            writer.add_document(doc!(date_field=>DateTime::from_primitive(Date::from_calendar_date(1982, Month::September, 17)?.with_hms(0, 0, 0)?)))?;
            writer.add_document(doc!(date_field=>DateTime::from_primitive(Date::from_calendar_date(1983, Month::September, 27)?.with_hms(0, 0, 0)?)))?;
            writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_date": {
                "terms": {
                    "field": "date_field"
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;

        // date_field field
        assert_eq!(res["my_date"]["buckets"][0]["key"], "1982-09-17T00:00:00Z");
        assert_eq!(res["my_date"]["buckets"][0]["doc_count"], 2);
        assert_eq!(res["my_date"]["buckets"][1]["key"], "1983-09-27T00:00:00Z");
        assert_eq!(res["my_date"]["buckets"][1]["doc_count"], 1);
        assert_eq!(res["my_date"]["buckets"][2]["key"], serde_json::Value::Null);

        Ok(())
    }
    #[test]
    fn terms_aggregation_date_missing() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        let date_field = schema_builder.add_date_field("date_field", FAST);
        let schema = schema_builder.build();
        let index = Index::create_in_ram(schema);
        {
            let mut writer = index.writer_with_num_threads(1, 15_000_000)?;
            writer.add_document(doc!(date_field=>DateTime::from_primitive(Date::from_calendar_date(1982, Month::September, 17)?.with_hms(0, 0, 0)?)))?;
            writer.add_document(doc!(date_field=>DateTime::from_primitive(Date::from_calendar_date(1982, Month::September, 17)?.with_hms(0, 0, 0)?)))?;
            writer.add_document(doc!(date_field=>DateTime::from_primitive(Date::from_calendar_date(1983, Month::September, 27)?.with_hms(0, 0, 0)?)))?;
            writer.add_document(doc!())?;
            writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_date": {
                "terms": {
                    "field": "date_field",
                    "missing": "1982-09-17T00:00:00Z"
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;

        // date_field field
        assert_eq!(res["my_date"]["buckets"][0]["key"], "1982-09-17T00:00:00Z");
        assert_eq!(res["my_date"]["buckets"][0]["doc_count"], 3);
        assert_eq!(res["my_date"]["buckets"][1]["key"], "1983-09-27T00:00:00Z");
        assert_eq!(res["my_date"]["buckets"][1]["doc_count"], 1);
        assert_eq!(res["my_date"]["buckets"][2]["key"], serde_json::Value::Null);

        Ok(())
    }

    #[test]
    fn terms_aggregation_bool() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        let field = schema_builder.add_bool_field("bool_field", FAST);
        let schema = schema_builder.build();
        let index = Index::create_in_ram(schema);
        {
            let mut writer = index.writer_with_num_threads(1, 15_000_000)?;
            writer.add_document(doc!(field=>true))?;
            writer.add_document(doc!(field=>false))?;
            writer.add_document(doc!(field=>true))?;
            writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_bool": {
                "terms": {
                    "field": "bool_field"
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;

        assert_eq!(res["my_bool"]["buckets"][0]["key"], 1.0);
        assert_eq!(res["my_bool"]["buckets"][0]["key_as_string"], "true");
        assert_eq!(res["my_bool"]["buckets"][0]["doc_count"], 2);
        assert_eq!(res["my_bool"]["buckets"][1]["key"], 0.0);
        assert_eq!(res["my_bool"]["buckets"][1]["key_as_string"], "false");
        assert_eq!(res["my_bool"]["buckets"][1]["doc_count"], 1);
        assert_eq!(res["my_bool"]["buckets"][2]["key"], serde_json::Value::Null);

        Ok(())
    }

    #[test]
    fn terms_aggregation_ip_addr() -> crate::Result<()> {
        let mut schema_builder = Schema::builder();
        let field = schema_builder.add_ip_addr_field("ip_field", FAST);
        let schema = schema_builder.build();
        let index = Index::create_in_ram(schema);
        {
            let mut writer = index.writer_with_num_threads(1, 15_000_000)?;
            // IpV6 loopback
            writer.add_document(doc!(field=>IpAddr::from_str("::1").unwrap().into_ipv6_addr()))?;
            writer.add_document(doc!(field=>IpAddr::from_str("::1").unwrap().into_ipv6_addr()))?;
            // IpV4
            writer.add_document(
                doc!(field=>IpAddr::from_str("127.0.0.1").unwrap().into_ipv6_addr()),
            )?;
            writer.commit()?;
        }

        let agg_req: Aggregations = serde_json::from_value(json!({
            "my_bool": {
                "terms": {
                    "field": "ip_field"
                },
            }
        }))
        .unwrap();

        let res = exec_request_with_query(agg_req, &index, None)?;
        // print as json
        // println!("{}", serde_json::to_string_pretty(&res).unwrap());

        assert_eq!(res["my_bool"]["buckets"][0]["key"], "::1");
        assert_eq!(res["my_bool"]["buckets"][0]["doc_count"], 2);
        assert_eq!(res["my_bool"]["buckets"][1]["key"], "127.0.0.1");
        assert_eq!(res["my_bool"]["buckets"][1]["doc_count"], 1);
        assert_eq!(res["my_bool"]["buckets"][2]["key"], serde_json::Value::Null);

        Ok(())
    }

    #[test]
    fn terms_aggs_hosts_and_tags_merge_on_mixed_order_request() -> crate::Result<()> {
        // This test ensures that merging of aggregation results works correctly
        // even if the order of the aggregation requests is different and
        // running on different indexes with the same data.
        let build_index = || -> crate::Result<Index> {
            let mut schema_builder = Schema::builder();
            let fielda = schema_builder.add_text_field("fielda", FAST);
            let fieldb = schema_builder.add_text_field("fieldb", FAST);
            let host = schema_builder.add_text_field("host", FAST);
            let tags = schema_builder.add_text_field("tags", FAST);
            let schema = schema_builder.build();

            let index = Index::create_in_ram(schema.clone());
            let mut writer = index.writer(50_000_000).unwrap();

            // --- Ingest documents (batch #1) ---
            writer.add_document(doc!(
                host => "192.168.0.10",
                tags => "nice",
                fielda => "a",
                fieldb => "b",
            ))?;
            writer.add_document(doc!(
                host => "192.168.0.1",
                tags => "nice",
            ))?;
            writer.add_document(doc!(
                host => "192.168.0.11",
                tags => "nice",
            ))?;
            writer.add_document(doc!(
                host => "192.168.0.10",
                tags => "nice",
                tags => "cool",
            ))?;
            writer.add_document(doc!(
                host => "192.168.0.1",
                tags => "nice",
                tags => "cool",
            ))?;

            writer.commit()?;

            // --- Ingest documents (batch #2) ---
            writer.add_document(doc!())?;
            writer.add_document(doc!())?;
            writer.add_document(doc!(
                host => "192.168.0.10",
            ))?;
            writer.add_document(doc!(
                host => "192.168.0.10",
            ))?;
            writer.add_document(doc!())?;

            writer.commit()?;
            Ok(index)
        };
        let index = build_index()?;
        let index2 = build_index()?;

        let search = |idx: &Index,
                      agg_req: &Aggregations|
         -> crate::Result<IntermediateAggregationResults> {
            let collector =
                DistributedAggregationCollector::from_aggs(agg_req.clone(), Default::default());
            let reader = idx.reader()?;
            let searcher = reader.searcher();
            let agg_res = searcher.search(&AllQuery, &collector)?;
            Ok(agg_res)
        };

        // --- Aggregations: terms on host and tags ---
        let agg_req: Aggregations = serde_json::from_value(json!({
            "hosts": { "terms": { "field": "host" } },
            "tags":  { "terms": { "field": "tags" } },
            "fielda":  { "terms": { "field": "fielda" } },
            "fieldb":  { "terms": { "field": "fieldb" } },
        }))
        .unwrap();

        let mut agg_res = search(&index, &agg_req)?;

        // --- Aggregations: terms on host and tags ---
        let mut agg_req2: Aggregations =
            Aggregations::with_capacity_and_hasher(20, Default::default());
        agg_req2.insert(
            "tags".to_string(),
            serde_json::from_value(json!({ "terms": { "field": "tags" } }))?,
        );
        agg_req2.insert(
            "fielda".to_string(),
            serde_json::from_value(json!({ "terms": { "field": "fielda" } }))?,
        );
        agg_req2.insert(
            "hosts".to_string(),
            serde_json::from_value(json!({ "terms": { "field": "host" } }))?,
        );
        agg_req2.insert(
            "fieldb".to_string(),
            serde_json::from_value(json!({ "terms": { "field": "fieldb" } }))?,
        );
        // make sure the order of the aggregation request is different
        // disabled to avoid flaky test with hashmap changes
        // assert_ne!(agg_req.keys().next(), agg_req2.keys().next());

        let agg_res2 = search(&index2, &agg_req2)?;

        agg_res.merge_fruits(agg_res2).unwrap();
        let agg_json =
            serde_json::to_value(&agg_res.into_final_result(agg_req2, Default::default())?)?;

        // hosts:
        let hosts = &agg_json["hosts"]["buckets"];
        assert_eq!(hosts[0]["key"], "192.168.0.10");
        assert_eq!(hosts[0]["doc_count"], 8);
        assert_eq!(hosts[1]["key"], "192.168.0.1");
        assert_eq!(hosts[1]["doc_count"], 4);
        assert_eq!(hosts[2]["key"], "192.168.0.11");
        assert_eq!(hosts[2]["doc_count"], 2);
        // Implementation currently reports error bounds/other count; ensure zero.
        assert_eq!(agg_json["hosts"]["doc_count_error_upper_bound"], 0);
        assert_eq!(agg_json["hosts"]["sum_other_doc_count"], 0);

        // tags:
        let tags_buckets = &agg_json["tags"]["buckets"];
        assert_eq!(tags_buckets[0]["key"], "nice");
        assert_eq!(tags_buckets[0]["doc_count"], 10);
        assert_eq!(tags_buckets[1]["key"], "cool");
        assert_eq!(tags_buckets[1]["doc_count"], 4);
        assert_eq!(agg_json["tags"]["doc_count_error_upper_bound"], 0);
        assert_eq!(agg_json["tags"]["sum_other_doc_count"], 0);

        Ok(())
    }

    fn prep_index_with_n_unique_terms_plus_one_null(n: u64) -> crate::Result<Index> {
        let mut schema_builder = Schema::builder();
        let id_field = schema_builder.add_u64_field("id", INDEXED);
        let title_field = schema_builder.add_text_field("title", TEXT | FAST);
        let schema = schema_builder.build();
        let index = Index::create_in_ram(schema.clone());
        // set to one thread to guarantee all docs end up in the same segment
        let mut writer = index.writer_with_num_threads(1, 50_000_000)?;

        writer.add_document(doc!(
            id_field => 0u64,
        ))?;
        for i in 1u64..=n {
            let title = format!("foo{i}");
            writer.add_document(doc!(
                id_field => i,
                title_field => title,
            ))?;
        }

        writer.commit()?;

        Ok(index)
    }

    #[test]
    fn null_bitset_bounds_check_regression() -> crate::Result<()> {
        // include cases
        for i in 0..=4 {
            let index = prep_index_with_n_unique_terms_plus_one_null(i * 64)?;
            let normal_req: Aggregations = serde_json::from_value(json!({
                "my_bool": {
                    "terms": {
                        "field": "title",
                        "missing": "__NULL__",
                        "size": 1000,
                    }
                }
            }))?;
            let include_req: Aggregations = serde_json::from_value(json!({
                "my_bool": {
                    "terms": {
                        "field": "title",
                        "include": "foo(.*)",
                        "missing": "__NULL__",
                        "size": 1000,
                    }
                }
            }))?;
            let exclude_req: Aggregations = serde_json::from_value(json!({
                "my_bool": {
                    "terms": {
                        "field": "title",
                        "exclude": "foo(.*)",
                        "missing": "__NULL__",
                        "size": 1000,
                    }
                }
            }))?;

            let normal_res = exec_request(normal_req, &index)?;
            let normal_buckets = normal_res["my_bool"]["buckets"].as_array().unwrap();
            assert_eq!(
                normal_buckets.len(),
                (i * 64) as usize + 1,
                "The normal request should return all 'foo' buckets, plus the missing term bucket",
            );

            let include_res = exec_request(include_req, &index)?;
            eprintln!("include_res: {include_res:?}");
            let include_buckets = include_res["my_bool"]["buckets"].as_array().unwrap();
            assert_eq!(
                include_buckets.len(),
                (i * 64) as usize,
                "The include request should return all 'foo' buckets, and not the missing term \
                 bucket",
            );
            assert!(include_buckets
                .iter()
                .all(|b| b["key"].as_str().unwrap().starts_with("foo")));

            let exclude_res = exec_request(exclude_req, &index)?;
            let exclude_buckets = exclude_res["my_bool"]["buckets"].as_array().unwrap();
            if i != 0 {
                // TODO: Remove this if after fixing exclude + missing bug
                assert_eq!(
                    exclude_buckets.len(),
                    1,
                    "The exclude request should exclude all 'foo' buckets, and only the missing \
                     term bucket",
                );
                assert_eq!(exclude_buckets[0]["key"], "__NULL__");
            }
        }
        Ok(())
    }
}
