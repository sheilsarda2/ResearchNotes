use std::fmt;

mod family;
mod histogram;
mod keys;
mod labels;
mod link;
mod registry;
mod stats;
mod transport;

pub use crate::{
    keys::{StatsKeyCache, StatsKeys, StatsKeysTree},
    labels::{LocalityLabel, MessageLabel, ReasonLabel, ResourceLabel, SpaceLabel},
    link::LinkStats,
    registry::StatsRegistry,
    transport::{DropStats, TransportStats},
    StatsDirection::*,
};

#[derive(Debug, Clone, Copy)]
pub enum StatsDirection {
    Tx,
    Rx,
}

impl StatsDirection {
    const NUM: usize = 2;

    fn from_index(index: usize) -> Self {
        match index {
            i if i == Tx as usize => Tx,
            i if i == Rx as usize => Rx,
            _ => unreachable!(),
        }
    }
}

impl fmt::Display for StatsDirection {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Tx => write!(f, "tx"),
            Self::Rx => write!(f, "rx"),
        }
    }
}
